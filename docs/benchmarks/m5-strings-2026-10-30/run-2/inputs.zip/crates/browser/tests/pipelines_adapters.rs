#[path = "../../../tests/support/process.rs"]
mod test_process;

use std::{path::PathBuf, process::Command, time::Duration};
use was_compiler::{
    CompileError, Compiler, ExportOptions, OptimizationLevel, Type, diagnostic,
    semantic::SemanticError, tokens::Span,
};

use wasmparser::Validator;

const LEVELS: [(&str, OptimizationLevel); 4] = [
    ("-O0", OptimizationLevel::None),
    ("-O1", OptimizationLevel::Basic),
    ("-O2", OptimizationLevel::Standard),
    ("-O3", OptimizationLevel::Aggressive),
];
const SOURCE: &str = r#"
fn digits(a: number, b: number, c: number) -> number requires a > 0 {
    mark(90); return a * 100 + b * 10 + c;
}
fn identity(x: number) -> number { return x; }
fn progression(start: number, end: number) -> range { return start..=end by 2; }
fn total(xs: range) -> number { let n = 0; for x in xs { n += x; } return n; }
fn main() -> number { return mark(1) |> digits(mark(2), mark(3)) |> identity(); }
fn local_pipeline() -> number { let add = (a: number, b: number) => a + b; return 1 |> add(2); }
fn bare() -> number { return 5 |> identity; }
fn empty() -> number { return 5 |> identity(); }
fn ranges() -> number { return 1 |> progression(end: 5) |> total; }
fn defaults(a: number = 9, b: number = a + 1, c: number = b + 1) -> number
    requires a > 0 requires b > a requires c > b {
    return a * 100 + b * 10 + c;
}
fn named() -> number { return mark(1) |> digits(c: mark(3), b: mark(2)) |> identity; }
fn mixed() -> number { return mark(1) |> digits(mark(2), c: mark(3)); }
fn default_bare() -> number { return 2 |> defaults; }
fn default_empty() -> number { return 2 |> defaults(); }
fn default_named() -> number { return 2 |> defaults(c: 8); }
fn default_mixed() -> number { return 2 |> defaults(4, c: 8); }
fn default_chain() { return 2 |> defaults |> identity(); }
fn array_default(xs: number[], n: number = len(xs)) -> number { return n; }
fn arrays() -> number { return [1, 2, 3] |> array_default; }
fn text_default(s: string, same: string = s) -> bool { return s == same; }
fn strings() -> bool { return "é🦀" |> text_default; }
fn ordinary(a: number = 2, b: number = a + 1) -> number { return a * 10 + b; }
fn ordinary_calls() -> number { return ordinary() + ordinary(b: 4, a: 3); }
fn sink(a: number, b: number = a + 1) -> void
    requires a > 0 requires b > a { mark(a); mark(b); }
fn sink_wrapper() { 4 |> sink; }
fn sink_trap_wrapper() { mark(1) |> sink(b: mark(0)); mark(99); }
fn discarded(flag: bool) -> number {
    mark(1) /* é🦀 */ |> identity |> /* λ */ sink(
        b: mark(2)
    );
    (3 |> sink());
    { /* é🦀: discarded tail */ (4 |> sink) };
    if flag { 6 |> sink } else { 8 |> sink() }
    (if flag { 10 |> sink } else { 12 |> sink });
    match flag { true => 14 |> sink, false => 16 |> sink(), }
    { if flag { { (18 |> sink) } } else { 20 |> sink } };
    return 65;
}
fn discarded_never() -> number { (loop {}) |> sink; }
fn immediate() -> number {
    let factor = 2;
    let add = (x: number) => { factor += 1; x + factor };
    return { factor = 3; mark(2) }
        |> (_ * factor)
        |> ((x: number) => { let twice = _ * 2; twice(x) |> (_ |> add) })
        |> defaults(c: 18);
}
fn immediate_void() { 4 |> ((x: number) => { mark(x); }); }
fn immediate_trap() -> number {
    let n = 7;
    return mark(1) |> ((x: number) => { mark(x + n); let xs = [0]; xs[1] })
        |> (_ + mark(99));
}
"#;
const SELECTED: &[&str] = &[
    "main",
    "local_pipeline",
    "bare",
    "empty",
    "ranges",
    "ordinary_calls",
    "named",
    "mixed",
    "defaults",
    "default_bare",
    "default_empty",
    "default_named",
    "default_mixed",
    "default_chain",
    "arrays",
    "strings",
    "sink",
    "sink_wrapper",
    "sink_trap_wrapper",
    "discarded",
    "discarded_never",
    "immediate",
    "immediate_void",
    "immediate_trap",
];

const ERRORS: &[(&str, &str)] = &[
    ("// é🦀\r\n\tfn f() { return 10 |> (_ + _); }", "(_ + _)"),
    (
        "// é🦀\r\n\tfn f() { return 10 |> (() => 42); }",
        "(() => 42)",
    ),
    ("// é🦀\r\n\tfn f() { return 10 |> (42); }", "(42)"),
    ("// é🦀\r\n\tfn f() { return 1 |> mark; }\r\n", "mark"),
    ("// é🦀\r\n\tfn f() { return [1] |> len(); }\r\n", "len()"),
    (
        "// é🦀\r\n\tfn f() { return 1 |> zero(); }\r\nfn zero() -> number { return 0; }",
        "zero()",
    ),
    (
        "// é🦀\r\n\tfn f() { return 1 |> pair; }\r\nfn pair(a: number, b: number) -> number { return a + b; }",
        "pair",
    ),
    (
        "// é🦀\r\n\tfn f() { return (\"é🦀\") |> numeric; }\r\nfn numeric(a: number) -> number { return a; }",
        "(\"é🦀\")",
    ),
    (
        "// é🦀\r\n\tfn f() { return 1 |> pair(\"é🦀\"); }\r\nfn pair(a: number, b: number) -> number { return a + b; }",
        "\"é🦀\"",
    ),
    (
        "// é🦀\r\n\tfn f() { return 1 |> text |> numeric; }\r\nfn text(a: number) -> string { return \"é\"; }\r\nfn numeric(a: number) -> number { return a; }",
        "1 |> text",
    ),
    (
        "// é🦀\r\n\tfn f() { return (\"é🦀\" /* λ */\r\n\t) |> numeric; }\r\nfn numeric(a: number) -> number { return a; }",
        "(\"é🦀\" /* λ */\r\n\t)",
    ),
    (
        "// é🦀\r\n\tfn f() { return 1 /* λ */ |> text(\r\n\t) /* 🦀 */ |> numeric; }\r\nfn text(a: number) -> string { return \"é\"; }\r\nfn numeric(a: number) -> number { return a; }",
        "1 /* λ */ |> text(\r\n\t)",
    ),
    (
        "// é🦀\r\n\tfn f() { 1 |> discard; }\r\nfn discard(a: number, b: number = /* λ */ \"é🦀\") {}",
        "\"é🦀\"",
    ),
];
const FINAL_VOID: &str = "a final void stage requires a discarded result";
const NONFINAL_VOID: &str = "a nonfinal stage cannot return void";
const VOID_ERRORS: &[(&str, &str, &str)] = &[
    (
        "// é🦀\r\n\tfn f() { return 1 |> ((x: number) => {}); }",
        "((x: number) => {})",
        FINAL_VOID,
    ),
    (
        "// é🦀\r\n\tfn f() { (loop {}) |> ((x: number) => {}) |> (_ + 1); }",
        "((x: number) => {})",
        NONFINAL_VOID,
    ),
    (
        "fn f() { return 1 |> discard; } fn discard(a: number) {}",
        "discard",
        FINAL_VOID,
    ),
    (
        "fn f() { let x = 1 |> discard(); } fn discard(a: number) {}",
        "discard()",
        FINAL_VOID,
    ),
    (
        "fn f() { consume(1 |> discard); } fn discard(a: number) {} fn consume(a: number) {}",
        "discard",
        FINAL_VOID,
    ),
    (
        "fn f() { (1 |> discard) + 2; } fn discard(a: number) {}",
        "discard",
        FINAL_VOID,
    ),
    (
        "fn f() { if (1 |> discard) {} } fn discard(a: number) {}",
        "discard",
        FINAL_VOID,
    ),
    (
        "fn f() { [1 |> discard]; } fn discard(a: number) {}",
        "discard",
        FINAL_VOID,
    ),
    (
        "fn f() { let xs = [1]; xs[1 |> discard]; } fn discard(a: number) {}",
        "discard",
        FINAL_VOID,
    ),
    (
        "fn f() { let x = { 1 |> discard }; } fn discard(a: number) {}",
        "discard",
        FINAL_VOID,
    ),
    (
        "fn f() { let x = if true { 1 |> discard } else { 2 |> discard }; } fn discard(a: number) {}",
        "discard",
        FINAL_VOID,
    ),
    (
        "fn f() { let x = match true { true => 1 |> discard, false => 2 |> discard, }; } fn discard(a: number) {}",
        "discard",
        FINAL_VOID,
    ),
    (
        "fn f() -> number { return (loop {}) |> discard; } fn discard(a: number) {}",
        "discard",
        FINAL_VOID,
    ),
    (
        "fn f() { 1 |> discard |> identity; } fn discard(a: number) {} fn identity(a: number) -> number { return a; }",
        "discard",
        NONFINAL_VOID,
    ),
    (
        "fn f() -> number { (loop {}) |> discard() |> identity; } fn discard(a: number) {} fn identity(a: number) -> number { return a; }",
        "discard()",
        NONFINAL_VOID,
    ),
    (
        "// é🦀\r\n\tfn f() { return 1 /* λ */ |> discard(\r\n\t    b: 2 /* 🦀 */\r\n\t); }\r\nfn discard(a: number, b: number = a + 1) {}",
        "discard(\r\n\t    b: 2 /* 🦀 */\r\n\t)",
        FINAL_VOID,
    ),
    (
        "// é🦀\r\n\tfn f() { 1 /* λ */ |> discard(\r\n\t    b: 2 /* 🦀 */\r\n\t) |> identity; }\r\nfn discard(a: number, b: number = a + 1) {}\r\nfn identity(a: number) -> number { return a; }",
        "discard(\r\n\t    b: 2 /* 🦀 */\r\n\t)",
        NONFINAL_VOID,
    ),
];

#[derive(Clone, Copy, Debug)]
enum BindingError {
    Duplicate(&'static str),
    Unknown,
    Missing,
    PositionalAfterNamed,
    TooManyPositional,
    TypeMismatch,
}

const BINDING_ERRORS: &[(&str, &str, BindingError)] = &[
    (
        "// é🦀\r\n\tfn f() { return 1 |> pair(a: missing, b: 3); }\r\nfn pair(a: number = 9, b: number = a + 1) -> number { return a + b; }",
        "a: missing",
        BindingError::Duplicate("a"),
    ),
    (
        "// é🦀\r\n\tfn f() { return 1 |> pair(2, b: missing); }\r\nfn pair(a: number, b: number) -> number { return a + b; }",
        "b: missing",
        BindingError::Duplicate("b"),
    ),
    (
        "// é🦀\r\n\tfn f() { return 1 |> pair(b: 2, b: missing); }\r\nfn pair(a: number, b: number) -> number { return a + b; }",
        "b: missing",
        BindingError::Duplicate("b"),
    ),
    (
        "// é🦀\r\n\tfn f() { return 1 |> pair(unknown: missing); }\r\nfn pair(a: number, b: number) -> number { return a + b; }",
        "unknown: missing",
        BindingError::Unknown,
    ),
    (
        "// é🦀\r\n\tfn f() { return 1 |> pair(); }\r\nfn pair(a: number, b: number, c: number = b + 1) -> number { return a + b + c; }",
        "pair()",
        BindingError::Missing,
    ),
    (
        "// é🦀\r\n\tfn f() { return 1 |> pair; }\r\nfn pair(a: number, b: number) -> number { return a + b; }",
        "pair",
        BindingError::Missing,
    ),
    (
        "// é🦀\r\n\tfn f() { return 1 |> pair(c: missing); }\r\nfn pair(a: number, b: number, c: number = b + 1) -> number { return a + b + c; }",
        "pair(c: missing)",
        BindingError::Missing,
    ),
    (
        "// é🦀\r\n\tfn f() { return 1 |> pair(b: missing, 3); }\r\nfn pair(a: number, b: number, c: number) -> number { return a + b + c; }",
        "3",
        BindingError::PositionalAfterNamed,
    ),
    (
        "// é🦀\r\n\tfn f() { return 1 |> pair(2, missing); }\r\nfn pair(a: number, b: number) -> number { return a + b; }",
        "missing",
        BindingError::TooManyPositional,
    ),
    (
        "// é🦀\r\n\tfn f() { return 1 |> pair(b: \"é🦀\"); }\r\nfn pair(a: number, b: number) -> number { return a + b; }",
        "b: \"é🦀\"",
        BindingError::TypeMismatch,
    ),
    (
        "// é🦀\r\n\tfn f() -> number { return (loop {}) |> pair(a: 2); }\r\nfn pair(a: number, b: number = a + 1) -> number { return a + b; }",
        "a: 2",
        BindingError::Duplicate("a"),
    ),
    (
        "// é🦀\r\n\tfn f() { 1 |> pair(a: missing); }\r\nfn pair(a: number, b: number = a + 1) {}",
        "a: missing",
        BindingError::Duplicate("a"),
    ),
    (
        "// é🦀\r\n\tfn f() { 1 |> pair(b: \"é🦀\"); }\r\nfn pair(a: number, b: number = a + 1) {}",
        "b: \"é🦀\"",
        BindingError::TypeMismatch,
    ),
];

fn compiler() -> Compiler {
    let mut compiler = Compiler::new();
    compiler
        .register_host_function("mark", "env", "mark", vec![Type::Number], Type::Number)
        .unwrap();
    compiler.set_exports(ExportOptions::Only(
        SELECTED.iter().map(|name| (*name).into()).collect(),
    ));
    compiler
}

fn expected_diagnostic(path: &str, source: &str, origin: &str) -> String {
    let error = compiler().compile_source(source).unwrap_err();
    assert!(matches!(error, CompileError::Semantic(_)), "{error:?}");
    let start = source.find(origin).unwrap();
    assert_eq!(
        error.span(),
        Some(Span::new(start, start + origin.len())),
        "{error}"
    );
    let line_start = source[..start].rfind('\n').map_or(0, |i| i + 1);
    let line_end = source[start..]
        .find('\n')
        .map_or(source.len(), |i| start + i);
    let line = source[..start]
        .bytes()
        .filter(|byte| *byte == b'\n')
        .count()
        + 1;
    let column = source[line_start..start].chars().count() + 1;
    let padding = source[line_start..start]
        .replace('\t', "    ")
        .chars()
        .count();
    let excerpt = source[line_start..line_end]
        .trim_end_matches('\r')
        .replace('\t', "    ");
    let visible_end = (start + origin.len()).min(line_end);
    let width = source[start..visible_end]
        .trim_end_matches('\r')
        .replace('\t', "    ")
        .chars()
        .count()
        .max(1);
    let expected = format!(
        "{path}:{line}:{column}: semantic error: {error}\n  |\n{line} | {excerpt}\n  | {}{}",
        " ".repeat(padding),
        "^".repeat(width)
    );
    assert_eq!(diagnostic::render(path, source, &error), expected);
    expected
}

fn diagnostic_cases(path: &str) -> Vec<(&'static str, String)> {
    let mut cases: Vec<_> = ERRORS
        .iter()
        .map(|(source, origin)| (*source, expected_diagnostic(path, source, origin)))
        .collect();
    for (source, origin, message) in VOID_ERRORS {
        let error = compiler().compile_source(source).unwrap_err();
        assert!(
            matches!(&error, CompileError::Semantic(SemanticError::InvalidPipeline { message: actual, .. }) if actual == message),
            "expected {message:?}, got {error:?}"
        );
        let start = source.find(origin).unwrap();
        let span = Span::new(start, start + origin.len());
        assert_eq!(
            error.to_string(),
            format!("Invalid pipeline: {message} at {span:?}")
        );
        cases.push((*source, expected_diagnostic(path, source, origin)));
    }
    for (source, origin, kind) in BINDING_ERRORS {
        let error = compiler().compile_source(source).unwrap_err();
        let CompileError::Semantic(semantic) = &error else {
            panic!("expected {kind:?}, got {error:?}");
        };
        let matches = match (kind, semantic) {
            (
                BindingError::Duplicate(formal),
                SemanticError::DuplicateArgument { name, argument, .. },
            ) => name == "pair" && argument == formal,
            (BindingError::Unknown, SemanticError::UnknownArgument { name, argument, .. }) => {
                name == "pair" && argument == "unknown"
            }
            (BindingError::Missing, SemanticError::MissingArgument { name, argument, .. }) => {
                name == "pair" && argument == "b"
            }
            (
                BindingError::PositionalAfterNamed,
                SemanticError::PositionalAfterNamed { name, .. },
            )
            | (
                BindingError::TooManyPositional,
                SemanticError::TooManyPositionalArguments { name, .. },
            ) => name == "pair",
            (BindingError::TypeMismatch, SemanticError::TypeMismatch { .. }) => true,
            _ => false,
        };
        assert!(matches, "expected {kind:?}, got {error:?}");
        cases.push((*source, expected_diagnostic(path, source, origin)));
    }
    cases
}

const VOID_ASSERTIONS: &str = r#"
    function assertDiscardedVoid(assert, e, events) {
        for (const [flag, expected] of [
            [1, [1,2,1,2,3,4,4,5,6,7,10,11,14,15,18,19]],
            [0, [1,2,1,2,3,4,4,5,8,9,12,13,16,17,20,21]]
        ]) {
            events.length = 0;
            assert.equal(e.discarded(flag), 65);
            assert.deepEqual(events, expected);
        }
        events.length = 0;
        assert.equal(e.sink.length, 2);
        assert.equal(e.sink(4, 5), undefined);
        assert.equal(e.sink_wrapper.length, 0);
        assert.equal(e.sink_wrapper(), undefined);
        assert.deepEqual(events, [4,5,4,5]);
        events.length = 0;
        assert.throws(() => e.sink(4), WebAssembly.RuntimeError);
        assert.throws(() => e.sink(0, 1), WebAssembly.RuntimeError);
        assert.throws(() => e.sink(2, 1), WebAssembly.RuntimeError);
        assert.deepEqual(events, []);
        assert.throws(() => e.sink_trap_wrapper(), WebAssembly.RuntimeError);
        assert.deepEqual(events, [1,0]);
        // Validate the divergent export, but never run it without guest fuel.
        assert.equal(typeof e.discarded_never, 'function');
    }
"#;

fn field(input: &mut Vec<u8>, bytes: &[u8]) {
    input.extend_from_slice(&u32::try_from(bytes.len()).unwrap().to_le_bytes());
    input.extend_from_slice(bytes);
}

#[test]
#[ignore = "requires Node.js and pkg freshly rebuilt from the integrated pipeline source"]
fn rebuilt_browser_pipeline_bytes_wat_execution_and_diagnostics_match_native() {
    let package = PathBuf::from(concat!(env!("CARGO_MANIFEST_DIR"), "/../..")).join("pkg");
    for name in ["was_compiler.js", "was_compiler_bg.wasm"] {
        assert!(
            package.join(name).is_file(),
            "rebuild pkg before running pipeline browser tests"
        );
    }
    let mut input = Vec::new();
    field(&mut input, SOURCE.as_bytes());
    field(&mut input, SELECTED.join(",").as_bytes());
    let mut native = compiler();
    let mut enabled_bytes = None;
    for (_, level) in LEVELS {
        native.set_optimization_level(level);
        for names in [SELECTED, &["main"][..], &[][..]] {
            native.set_exports(ExportOptions::Only(
                names.iter().map(|name| (*name).into()).collect(),
            ));
            let bytes = native.compile_source(SOURCE).unwrap();
            Validator::new().validate_all(&bytes).unwrap();
            if names == SELECTED && level != OptimizationLevel::None {
                if let Some(expected) = &enabled_bytes {
                    assert_eq!(&bytes, expected, "{level:?}");
                } else {
                    enabled_bytes = Some(bytes.clone());
                }
            }
            field(&mut input, &bytes);
            field(
                &mut input,
                wasmprinter::print_bytes(&bytes).unwrap().as_bytes(),
            );
        }
    }
    let diagnostics = diagnostic_cases("<browser>");
    field(
        &mut input,
        &u32::try_from(diagnostics.len()).unwrap().to_le_bytes(),
    );
    for (source, expected) in diagnostics {
        field(&mut input, source.as_bytes());
        field(&mut input, expected.as_bytes());
    }
    let script = r#"
        const assert = require('node:assert/strict');
        const fs = require('node:fs');
        const path = require('node:path');
        const {pathToFileURL} = require('node:url');
        async function main() {
            const input = fs.readFileSync(0); let offset = 0;
            function field() {
                assert.ok(offset + 4 <= input.length);
                const length = input.readUInt32LE(offset); offset += 4;
                assert.ok(offset + length <= input.length);
                const bytes = input.subarray(offset, offset + length); offset += length; return bytes;
            }
            const source = field().toString('utf8'), selected = field().toString('utf8').split(',');
            const native = Array.from({length: 4}, () => Array.from({length: 3},
                () => ({bytes: field(), wat: field().toString('utf8')})));
            const count = field().readUInt32LE(0);
            const diagnostics = Array.from({length: count},
                () => ({source: field().toString('utf8'), message: field().toString('utf8')}));
            assert.equal(offset, input.length);
            const directory = process.argv[1];
            const {default: init, Compiler} = await import(pathToFileURL(path.join(directory, 'was_compiler.js')).href);
            await init({module_or_path: fs.readFileSync(path.join(directory, 'was_compiler_bg.wasm'))});
            const compiler = new Compiler();
            try {
                compiler.registerHostFunction('mark', 'env', 'mark', ['number'], 'number');
                function same(expected) {
                    const bytes = compiler.compile(source);
                    assert.ok(WebAssembly.validate(bytes));
                    assert.deepEqual(Buffer.from(bytes), expected.bytes);
                    assert.equal(compiler.compileWat(source), expected.wat);
                    return bytes;
                }
                for (let level = 0; level < 4; level++) {
                    compiler.setOptimizationLevel(level);
                    for (const [index, names] of [selected, ['main'], []].entries()) {
                        compiler.setExports(names); same(native[level][index]);
                    }
                    compiler.setExports(selected);
                    for (const diagnostic of diagnostics) {
                        for (const method of ['compile', 'compileWat']) {
                            assert.throws(() => compiler[method](diagnostic.source), error => {
                                assert.ok(error instanceof Error); assert.equal(error.name, 'Error');
                                assert.equal(error.message, diagnostic.message); return true;
                            });
                            same(native[level][0]);
                        }
                    }
                    const events = [];
                    const e = new WebAssembly.Instance(new WebAssembly.Module(same(native[level][0])), {
                        env: {mark(n) {events.push(n); return n;}}
                    }).exports;
                    assert.equal(e.main(), 123); assert.deepEqual(events, [1,2,3,90]);
                    assert.equal(e.bare(), 5); assert.equal(e.empty(), 5);
                    assert.equal(e.ranges(), 9); assert.equal(e.ordinary_calls(), 57);
                    events.length = 0;
                    assert.equal(e.named(), 123); assert.deepEqual(events, [1,3,2,90]);
                    events.length = 0;
                    assert.equal(e.mixed(), 123); assert.deepEqual(events, [1,2,3,90]);
                    assert.equal(e.default_bare(), 234); assert.equal(e.default_empty(), 234);
                    assert.equal(e.default_named(), 238); assert.equal(e.default_mixed(), 248);
                    assert.equal(e.default_chain(), 234);
                    assert.equal(e.arrays(), 3); assert.equal(e.strings(), 1);
                    // Raw exports remain full-arity: declaration defaults are source-call sugar only.
                    assert.equal(e.defaults.length, 3); assert.equal(e.defaults(4, 5, 6), 456);
                    assert.throws(() => e.defaults(4), WebAssembly.RuntimeError);
                    assert.ok(!('progression' in e)); assert.ok(!('total' in e));
                    assertDiscardedVoid(assert, e, events);
                    events.length = 0;
                    assert.equal(e.immediate(), 1788); assert.deepEqual(events.splice(0), [2]);
                    assert.equal(e.immediate_void(), undefined); assert.deepEqual(events.splice(0), [4]);
                    assert.throws(() => e.immediate_trap(), WebAssembly.RuntimeError);
                    assert.deepEqual(events.splice(0), [1,8]);
                    assert.equal(e.immediate(), 1788); assert.deepEqual(events.splice(0), [2]);
                }
            } finally {compiler.free();}
        }
        main().catch(error => {console.error(error); process.exitCode = 1;});
    "#;
    let script = [VOID_ASSERTIONS, script].concat();
    let output = test_process::output(
        Command::new("node").args(["-e", &script]).arg(package),
        Some(&input),
        Duration::from_secs(30),
    );
    assert!(
        output.status.success(),
        "{}\n{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(output.stdout.is_empty());
    assert!(output.stderr.is_empty());
}
