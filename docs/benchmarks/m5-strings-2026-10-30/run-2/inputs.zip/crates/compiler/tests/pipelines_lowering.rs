use was_compiler::{
    CodegenError, Compiler, ExportOptions, OptimizationLevel, Type, codegen,
    semantic::SemanticError,
    typed_ast::{
        CallBindingOrigin, TypedExpr, TypedExprKind, TypedNormalizedCall, TypedProgram,
        TypedStatementKind,
    },
};
use wasmparser::{Operator, Parser, Payload, ValType, Validator};

const LEVELS: [OptimizationLevel; 4] = [
    OptimizationLevel::None,
    OptimizationLevel::Basic,
    OptimizationLevel::Standard,
    OptimizationLevel::Aggressive,
];

fn immediate_fixture(input: &str, stage: &str) -> TypedProgram {
    let mut program = Compiler::new()
        .analyze(&format!(
            "fn input() -> number {{ return 2; }}
             fn main() -> number {{ let total = 0; let stage = (x: number) => {stage}; return {input} |> stage; }}"
        ))
        .unwrap();
    let TypedStatementKind::Closure(mut closure) = program.functions[1].body.remove(1).kind else {
        panic!("stage declaration");
    };
    closure.name = "<pipeline stage>".into();
    let TypedStatementKind::Return(Some(value)) = &mut program.functions[1].body[1].kind else {
        panic!("pipeline return");
    };
    normalized(value).immediate_closure = Some(closure);
    program
}

#[test]
fn immediate_stage_creates_environment_after_input_and_keeps_eager_promotion() {
    let program = immediate_fixture("input()", "{ total += x; total }");
    let mut enabled = None;
    for level in LEVELS {
        let bytes = compiler_at(level).compile(&program).unwrap();
        Validator::new().validate_all(&bytes).unwrap();
        let bodies = Parser::new(0)
            .parse_all(&bytes)
            .filter_map(|payload| match payload.unwrap() {
                Payload::CodeSectionEntry(body) => Some(
                    body.get_operators_reader()
                        .unwrap()
                        .into_iter()
                        .map(Result::unwrap)
                        .collect::<Vec<_>>(),
                ),
                _ => None,
            })
            .collect::<Vec<_>>();
        let calls = bodies[1]
            .iter()
            .filter_map(|op| match op {
                Operator::Call { function_index } => Some(*function_index),
                Operator::CallIndirect { .. } => panic!("immediate stages must call directly"),
                _ => None,
            })
            .collect::<Vec<_>>();
        // Two user functions, seven memory helpers, then the private stage.
        assert_eq!(bodies.len(), 10);
        assert_eq!(
            calls,
            [2, 0, 2, 9],
            "{level:?}: cell, input, environment, stage"
        );
        assert!(
            bodies[9]
                .iter()
                .any(|op| matches!(op, Operator::F64Store { .. }))
        );
        assert_eq!(compiler_at(level).compile(&program).unwrap(), bytes);
        if level != OptimizationLevel::None {
            if let Some(expected) = &enabled {
                assert_eq!(&bytes, expected);
            } else {
                enabled = Some(bytes);
            }
        }
    }
}

fn immediate_sequence(program: &mut TypedProgram) -> &mut TypedNormalizedCall {
    let TypedStatementKind::Return(Some(value)) = &mut program.functions[1].body[1].kind else {
        panic!("pipeline return");
    };
    normalized(value)
}

#[test]
fn immediate_context_free_stage_keeps_numeric_facts_and_storage_owner_local() {
    let program = immediate_fixture("input()", "{ let local = 3; x + local }");
    for level in LEVELS {
        let bytes = compiler_at(level).compile(&program).unwrap();
        Validator::new().validate_all(&bytes).unwrap();
        let mut locals = Vec::new();
        let mut calls = Vec::new();
        for payload in Parser::new(0).parse_all(&bytes) {
            match payload.unwrap() {
                Payload::MemorySection(_) => panic!("context-free numeric stages need no memory"),
                Payload::CodeSectionEntry(body) => {
                    locals.push(
                        body.get_locals_reader()
                            .unwrap()
                            .into_iter()
                            .map(Result::unwrap)
                            .collect::<Vec<_>>(),
                    );
                    calls.push(
                        body.get_operators_reader()
                            .unwrap()
                            .into_iter()
                            .filter_map(|op| match op.unwrap() {
                                Operator::Call { function_index } => Some(function_index),
                                Operator::CallIndirect { .. } => panic!("direct stage call"),
                                _ => None,
                            })
                            .collect::<Vec<_>>(),
                    );
                }
                _ => {}
            }
        }
        let ordinary = if level == OptimizationLevel::None {
            ValType::F64
        } else {
            ValType::I32
        };
        assert_eq!(locals.len(), 3);
        assert_eq!(
            locals[1],
            [(1, ordinary), (1, ValType::F64)],
            "creator and injected slot: {level:?}"
        );
        assert_eq!(locals[2], [(1, ordinary)], "helper-only local: {level:?}");
        assert_eq!(calls[1], [0, 2]);
    }
}

#[test]
fn immediate_helpers_discover_nested_memory_range_remainder_and_temporary_requirements() {
    let program = immediate_fixture(
        "input()",
        "{ let values = [\"stage\"]; let r = 0..2;
           let nested = (n: number) => {
               let scratch = [true];
               if n in r { len(values) + x % 2 } else { 0 }
           }; nested(x) }",
    );
    for level in LEVELS {
        let bytes = compiler_at(level).compile(&program).unwrap();
        Validator::new().validate_all(&bytes).unwrap();
        let mut bodies = Vec::new();
        let mut found_string = false;
        for payload in Parser::new(0).parse_all(&bytes) {
            match payload.unwrap() {
                Payload::DataSection(reader) => {
                    for data in reader {
                        found_string |=
                            data.unwrap().data.windows(5).any(|bytes| bytes == b"stage");
                    }
                }
                Payload::CodeSectionEntry(body) => bodies.push(
                    body.get_operators_reader()
                        .unwrap()
                        .into_iter()
                        .map(Result::unwrap)
                        .collect::<Vec<_>>(),
                ),
                _ => {}
            }
        }
        assert!(found_string);
        let stage_index = u32::try_from(bodies.len() - 2).unwrap();
        let nested_index = stage_index + 1;
        assert!(bodies[1].iter().any(
            |op| matches!(op, Operator::Call { function_index } if *function_index == stage_index)
        ));
        assert!(bodies[bodies.len() - 2].iter().any(
            |op| matches!(op, Operator::Call { function_index } if *function_index == nested_index)
        ));
        assert!(
            bodies
                .last()
                .unwrap()
                .iter()
                .any(|op| matches!(op, Operator::I32Store8 { .. }))
        );
        assert!(
            bodies
                .iter()
                .flatten()
                .any(|op| matches!(op, Operator::I64RemS))
        );
        // Neither helper's declarations or scratch belong to the creator.
        assert_eq!(
            bodies[1]
                .iter()
                .filter(|op| matches!(op, Operator::LocalSet { .. }))
                .count(),
            2
        );
    }
}

#[test]
fn immediate_stage_forwards_earlier_live_callable_context_after_input() {
    let mut program = Compiler::new()
        .analyze(
            "fn input() -> number { return 2; }
             fn main() -> number {
                 let total = 0;
                 let previous = (n: number) => { total += n; total };
                 let stage = (x: number) => previous(x);
                 return input() |> stage;
             }",
        )
        .unwrap();
    let TypedStatementKind::Closure(mut closure) = program.functions[1].body.remove(2).kind else {
        panic!("stage declaration");
    };
    closure.name = "<pipeline stage>".into();
    let TypedStatementKind::Return(Some(value)) = &mut program.functions[1].body[2].kind else {
        panic!("stage return");
    };
    normalized(value).immediate_closure = Some(closure);
    for level in LEVELS {
        let bytes = compiler_at(level).compile(&program).unwrap();
        Validator::new().validate_all(&bytes).unwrap();
        let calls = Parser::new(0)
            .parse_all(&bytes)
            .filter_map(|payload| match payload.unwrap() {
                Payload::CodeSectionEntry(body) => Some(
                    body.get_operators_reader()
                        .unwrap()
                        .into_iter()
                        .filter_map(|op| match op.unwrap() {
                            Operator::Call { function_index } => Some(function_index),
                            _ => None,
                        })
                        .collect::<Vec<_>>(),
                ),
                _ => None,
            })
            .collect::<Vec<_>>();
        assert_eq!(calls.len(), 11);
        assert_eq!(
            calls[1],
            [2, 2, 0, 2, 10],
            "cell, earlier environment, input, stage environment, stage"
        );
        assert_eq!(calls[10], [9], "stage calls the earlier helper directly");
    }
}

#[test]
fn immediate_stage_discovery_visits_input_helpers_before_owned_helper() {
    let mut program = Compiler::new()
        .analyze(
            "fn main() -> number {
             let input = { let before = (n: number) => n + 1; before(2) };
             let stage = (x: number) => x + 3;
             return input |> stage;
         }",
        )
        .unwrap();
    let TypedStatementKind::Let { value: input, .. } = program.functions[0].body.remove(0).kind
    else {
        panic!("input initializer");
    };
    let TypedStatementKind::Closure(mut closure) = program.functions[0].body.remove(0).kind else {
        panic!("stage declaration");
    };
    closure.name = "<pipeline stage>".into();
    let TypedStatementKind::Return(Some(value)) = &mut program.functions[0].body[0].kind else {
        panic!("stage return");
    };
    let sequence = normalized(value);
    sequence.bindings[0].value = input;
    sequence.immediate_closure = Some(closure);
    for level in LEVELS {
        let bytes = compiler_at(level).compile(&program).unwrap();
        Validator::new().validate_all(&bytes).unwrap();
        let calls = Parser::new(0)
            .parse_all(&bytes)
            .filter_map(|payload| match payload.unwrap() {
                Payload::CodeSectionEntry(body) => Some(
                    body.get_operators_reader()
                        .unwrap()
                        .into_iter()
                        .filter_map(|op| match op.unwrap() {
                            Operator::Call { function_index } => Some(function_index),
                            _ => None,
                        })
                        .collect::<Vec<_>>(),
                ),
                _ => None,
            })
            .collect::<Vec<_>>();
        assert_eq!(calls, [vec![1, 2], vec![], vec![]]);
    }
}

#[test]
fn forged_immediate_stage_cannot_capture_its_synthetic_input_binding() {
    let mut program = immediate_fixture("input()", "x + 1");
    let sequence = immediate_sequence(&mut program);
    let closure = sequence.immediate_closure.as_mut().unwrap();
    closure
        .captures
        .push(was_compiler::typed_ast::TypedCapture {
            owner: closure.owner,
            variable: sequence.bindings[0].id,
            ty: Type::Number,
            mutability: was_compiler::typed_ast::CaptureMutability::Mutable,
        });
    let expected = CodegenError::InvalidClosure {
        reason: "invalid capture metadata",
        span: closure.span,
    };
    for level in LEVELS {
        assert_eq!(compiler_at(level).compile(&program).unwrap_err(), expected);
    }
}

#[test]
fn source_immediate_stage_observes_input_capture_write_before_environment_creation() {
    let source = "fn main() -> number {
        let total = 1;
        return { total += 2; total } |> ((x: number) => total + x);
    }";
    for level in LEVELS {
        let compiler = compiler_at(level);
        let program = compiler.analyze(source).unwrap();
        let bytes = compiler.compile(&program).unwrap();
        assert_eq!(compiler.compile_source(source).unwrap(), bytes);
        Validator::new().validate_all(&bytes).unwrap();
        let ops = Parser::new(0)
            .parse_all(&bytes)
            .find_map(|payload| match payload.unwrap() {
                Payload::CodeSectionEntry(body) => Some(
                    body.get_operators_reader()
                        .unwrap()
                        .into_iter()
                        .map(Result::unwrap)
                        .collect::<Vec<_>>(),
                ),
                _ => None,
            })
            .unwrap();
        let allocations = ops
            .iter()
            .enumerate()
            .filter_map(|(index, op)| match op {
                Operator::Call { function_index: 1 } => Some(index),
                _ => None,
            })
            .collect::<Vec<_>>();
        let writes = ops
            .iter()
            .enumerate()
            .filter_map(|(index, op)| match op {
                Operator::F64Store { .. } => Some(index),
                _ => None,
            })
            .collect::<Vec<_>>();
        assert_eq!(allocations.len(), 2, "eager cell and stage environment");
        assert_eq!(
            writes.len(),
            2,
            "initial value and input's shared-cell write"
        );
        assert!(allocations[0] < writes[0]);
        assert!(writes[0] < writes[1]);
        assert!(
            writes[1] < allocations[1],
            "{level:?}: input finishes before environment creation"
        );
        assert!(
            ops[allocations[1] + 1..]
                .iter()
                .any(|op| matches!(op, Operator::Call { function_index: 8 }))
        );
    }
}

#[test]
fn immediate_stage_cannot_capture_input_block_locals_or_depend_on_its_callables() {
    for dependency in [false, true] {
        let source = if dependency {
            "fn main() -> number {
                return { let hidden = (n: number) => n + 1; hidden(1) }
                    |> ((x: number) => x + 1);
            }"
        } else {
            "fn main() -> number {
                return { let hidden = 1; hidden } |> ((x: number) => x + 1);
            }"
        };
        let mut program = Compiler::new().analyze(source).unwrap();
        let TypedStatementKind::Return(Some(value)) = &mut program.functions[0].body[0].kind else {
            panic!("stage return");
        };
        let sequence = normalized(value);
        let TypedExprKind::Block(input) = &sequence.bindings[0].value.kind else {
            panic!("input block");
        };
        let closure = sequence.immediate_closure.as_mut().unwrap();
        let reason = if dependency {
            let TypedStatementKind::Closure(hidden) = &input.statements[0].kind else {
                panic!("input-local callable");
            };
            closure.dependencies.push(hidden.id);
            "invalid callable dependency"
        } else {
            let TypedStatementKind::Let { id, ty, .. } = &input.statements[0].kind else {
                panic!("input-local binding");
            };
            closure
                .captures
                .push(was_compiler::typed_ast::TypedCapture {
                    owner: closure.owner,
                    variable: *id,
                    ty: *ty,
                    mutability: was_compiler::typed_ast::CaptureMutability::Mutable,
                });
            "invalid capture metadata"
        };
        let expected = CodegenError::InvalidClosure {
            reason,
            span: closure.span,
        };
        for level in LEVELS {
            assert_eq!(compiler_at(level).compile(&program).unwrap_err(), expected);
        }
    }
}

#[test]
fn source_nested_immediate_stage_forwards_original_captures_through_its_creator() {
    let source = "fn main(total: number) -> number {
        let outer = (seed: number) => seed |> ((x: number) => { total += x; total });
        return 2 |> outer;
    }";
    let mut enabled = None;
    for level in LEVELS {
        let compiler = compiler_at(level);
        let program = compiler.analyze(source).unwrap();
        let bytes = compiler.compile(&program).unwrap();
        assert_eq!(compiler.compile_source(source).unwrap(), bytes);
        Validator::new().validate_all(&bytes).unwrap();
        let calls = Parser::new(0)
            .parse_all(&bytes)
            .filter_map(|payload| match payload.unwrap() {
                Payload::CodeSectionEntry(body) => Some(
                    body.get_operators_reader()
                        .unwrap()
                        .into_iter()
                        .filter_map(|op| match op.unwrap() {
                            Operator::Call { function_index } => Some(function_index),
                            Operator::CallIndirect { .. } => panic!("direct nested stage call"),
                            _ => None,
                        })
                        .collect::<Vec<_>>(),
                ),
                _ => None,
            })
            .collect::<Vec<_>>();
        assert_eq!(calls.len(), 10);
        assert_eq!(calls[0], [1, 1, 8]);
        assert_eq!(
            calls[8],
            [1, 9],
            "outer creates immediate environment and directly invokes stage"
        );
        assert!(calls[9].is_empty());
        if level != OptimizationLevel::None {
            if let Some(expected) = &enabled {
                assert_eq!(&bytes, expected);
            } else {
                enabled = Some(bytes);
            }
        }
    }
}

#[test]
fn forged_immediate_stage_requires_owned_unary_direct_target_and_exact_injection() {
    for case in 0..8 {
        let mut program = immediate_fixture("input()", "x + 1");
        let sequence = immediate_sequence(&mut program);
        match case {
            0 => sequence.immediate_closure.as_mut().unwrap().name = "stage".into(),
            1 => sequence.immediate_closure.as_mut().unwrap().params.clear(),
            2 => {
                let TypedExprKind::LexicalCall { callable, .. } = &mut sequence.call.kind else {
                    panic!("lexical call")
                };
                callable.0 += 1;
            }
            3 => {
                let mut extra = sequence.bindings[0].clone();
                extra.id.0 += 100;
                sequence.bindings.push(extra);
            }
            4 => sequence.bindings[0].origin = CallBindingOrigin::Explicit { argument: 0 },
            5 => sequence.formal_to_binding[0].0 += 100,
            6 => sequence.bindings[0].ty = Type::Bool,
            7 => sequence.bindings.push(sequence.bindings[0].clone()),
            _ => unreachable!(),
        }
        let expected = codegen::compile(&program).unwrap_err();
        if case == 7 {
            // Local planning rejects colliding IDs before normalized-call checks.
            assert!(matches!(expected, CodegenError::DuplicateVariableId { .. }));
        } else {
            assert!(
                matches!(expected, CodegenError::InvalidNormalizedCall { .. }),
                "case {case}: {expected:?}"
            );
        }
        for level in LEVELS {
            assert_eq!(
                compiler_at(level).compile(&program).unwrap_err(),
                expected,
                "case {case}, {level:?}"
            );
        }
    }
}

#[test]
fn forged_immediate_stage_checks_creator_ownership_and_identity() {
    for identity in [false, true] {
        let mut program = immediate_fixture("input()", "x + 1");
        let closure = immediate_sequence(&mut program)
            .immediate_closure
            .as_mut()
            .unwrap();
        let reason = if identity {
            closure.id.0 += 1;
            "invalid callable identity"
        } else {
            closure.owner = was_compiler::typed_ast::BindingOwner::Function(
                was_compiler::typed_ast::FunctionId(0),
            );
            "invalid closure ownership"
        };
        let expected = CodegenError::InvalidClosure {
            reason,
            span: closure.span,
        };
        for level in LEVELS {
            assert_eq!(compiler_at(level).compile(&program).unwrap_err(), expected);
        }
    }
}

#[test]
fn immediate_never_input_precedes_environment_and_still_checks_unexported_helper() {
    let mut program = immediate_fixture("{ return 7; 0 }", "total + x");
    for level in LEVELS {
        let mut compiler = compiler_at(level);
        compiler.set_exports(ExportOptions::None);
        let bytes = compiler.compile(&program).unwrap();
        Validator::new().validate_all(&bytes).unwrap();
        let ops = Parser::new(0)
            .parse_all(&bytes)
            .filter_map(|payload| match payload.unwrap() {
                Payload::CodeSectionEntry(body) => Some(body),
                _ => None,
            })
            .nth(1)
            .unwrap()
            .get_operators_reader()
            .unwrap()
            .into_iter()
            .map(Result::unwrap)
            .collect::<Vec<_>>();
        let returned = ops
            .iter()
            .position(|op| matches!(op, Operator::Return))
            .unwrap();
        let allocations = ops
            .iter()
            .enumerate()
            .filter_map(|(index, op)| match op {
                Operator::Call { function_index: 2 } => Some(index),
                _ => None,
            })
            .collect::<Vec<_>>();
        assert_eq!(allocations.len(), 2);
        assert!(allocations[0] < returned, "eager capture cell");
        assert!(
            allocations[1] > returned,
            "environment is unreachable after input transfer"
        );
    }
    let closure = immediate_sequence(&mut program)
        .immediate_closure
        .as_mut()
        .unwrap();
    closure.body = was_compiler::typed_ast::TypedClosureBody::Expression(Box::new(TypedExpr {
        kind: TypedExprKind::Number("invalid".into()),
        ty: Type::Number.into(),
    }));
    let expected = codegen::compile(&program).unwrap_err();
    assert!(matches!(
        expected,
        CodegenError::InvalidNumberLiteral { .. }
    ));
    for level in LEVELS {
        let mut compiler = compiler_at(level);
        compiler.set_exports(ExportOptions::None);
        assert_eq!(compiler.compile(&program).unwrap_err(), expected);
    }
}

#[test]
fn immediate_helper_is_unavailable_to_its_input_and_does_not_escape_stage_scope() {
    for in_input in [true, false] {
        let mut program = immediate_fixture("input()", "x + 1");
        let sequence = immediate_sequence(&mut program);
        let callable = sequence.immediate_closure.as_ref().unwrap().id;
        let call = TypedExpr {
            kind: TypedExprKind::LexicalCall {
                callable,
                args: vec![TypedExpr {
                    kind: TypedExprKind::Number("1".into()),
                    ty: Type::Number.into(),
                }],
                span: sequence.bindings[0].span,
            },
            ty: Type::Number.into(),
        };
        if in_input {
            sequence.bindings[0].value = call;
        } else {
            let span = sequence.bindings[0].span;
            program.functions[1]
                .body
                .push(was_compiler::typed_ast::TypedStatement {
                    kind: TypedStatementKind::Expression(call),
                    span,
                });
        }
        let expected = codegen::compile(&program).unwrap_err();
        assert!(matches!(
            expected,
            CodegenError::InvalidClosure {
                reason: "invalid callable call",
                ..
            }
        ));
        for level in LEVELS {
            assert_eq!(compiler_at(level).compile(&program).unwrap_err(), expected);
        }
    }
}

#[test]
fn lexical_pipeline_stage_lowers_to_a_valid_direct_helper_call() {
    let mut compiler = Compiler::new();
    compiler.set_exports(ExportOptions::Only(vec!["main".into()]));
    let program = compiler
        .analyze(
            "fn main() -> number { let total = 0; let add = (a: number, b: number) => { total += a; total + b }; return 1 |> add(2); }",
        )
        .unwrap();
    let bytes = compiler.compile(&program).unwrap();
    Validator::new().validate_all(&bytes).unwrap();

    let mut body_calls = Vec::new();
    let mut signatures = Vec::new();
    let mut function_types = Vec::new();
    let mut function_count = 0;
    for payload in Parser::new(0).parse_all(&bytes) {
        match payload.unwrap() {
            Payload::TypeSection(reader) => {
                signatures.extend(
                    reader
                        .into_iter_err_on_gc_types()
                        .map(|signature| signature.unwrap()),
                );
            }
            Payload::FunctionSection(reader) => {
                function_count = reader.count();
                function_types.extend(reader.into_iter().map(Result::unwrap));
            }
            Payload::CodeSectionEntry(body) => {
                let calls = body
                    .get_operators_reader()
                    .unwrap()
                    .into_iter()
                    .filter_map(|operator| match operator.unwrap() {
                        Operator::Call { function_index } => Some(function_index),
                        Operator::CallIndirect { .. } => panic!("lexical calls are direct"),
                        _ => None,
                    })
                    .collect::<Vec<_>>();
                body_calls.push(calls);
            }
            _ => {}
        }
    }
    assert!(function_count > 2);
    assert_eq!(body_calls.len(), usize::try_from(function_count).unwrap());
    assert_eq!(
        body_calls[0].last(),
        Some(&(function_count - 1)),
        "main must directly call the final private closure helper"
    );
    assert!(body_calls.last().unwrap().is_empty());
    assert_eq!(
        signatures[usize::try_from(*function_types.last().unwrap()).unwrap()].params(),
        [ValType::I32, ValType::F64, ValType::F64]
    );
}

#[test]
fn forged_lexical_stages_require_injection_and_reject_defaults() {
    let source =
        "fn main() -> number { let add = (a: number, b: number) => a + b; return 1 |> add(2); }";
    let mut without_injection = Compiler::new().analyze(source).unwrap();
    let TypedStatementKind::Return(Some(value)) = &mut without_injection.functions[0].body[1].kind
    else {
        panic!("pipeline return");
    };
    let sequence = normalized(value);
    sequence.bindings[0].origin = CallBindingOrigin::Explicit { argument: 0 };
    sequence.bindings[1].origin = CallBindingOrigin::Explicit { argument: 1 };
    assert_invalid_reason_at_every_level(
        &without_injection,
        "lexical stages require a pipeline input binding",
    );

    let mut with_default = Compiler::new().analyze(source).unwrap();
    let TypedStatementKind::Return(Some(value)) = &mut with_default.functions[0].body[1].kind
    else {
        panic!("pipeline return");
    };
    normalized(value).bindings[1].origin = CallBindingOrigin::Default { formal: 1 };
    assert_invalid_reason_at_every_level(
        &with_default,
        "lexical stages cannot contain default bindings",
    );

    let mut duplicate_injection = Compiler::new().analyze(source).unwrap();
    let TypedStatementKind::Return(Some(value)) =
        &mut duplicate_injection.functions[0].body[1].kind
    else {
        panic!("pipeline return");
    };
    normalized(value).bindings[1].origin = CallBindingOrigin::PipelineInput;
    assert_invalid_reason_at_every_level(
        &duplicate_injection,
        "pipeline input must be the first and only injected binding",
    );
}

fn assert_invalid_reason_at_every_level(program: &TypedProgram, reason: &'static str) {
    let expected = codegen::compile(program).unwrap_err();
    let CodegenError::InvalidNormalizedCall {
        reason: actual,
        span,
    } = expected
    else {
        panic!("expected InvalidNormalizedCall, found {expected:?}");
    };
    assert_eq!(actual, reason);
    assert_invalid(program, reason, span);
}

#[test]
fn lexical_pipeline_stage_bytes_match_across_enabled_presets() {
    let source =
        "fn main() -> number { let add = (a: number, b: number) => a + b; return 1 |> add(2); }";
    let mut enabled_bytes = None;
    let mut program_snapshot = None;
    for level in [
        OptimizationLevel::Basic,
        OptimizationLevel::Standard,
        OptimizationLevel::Aggressive,
    ] {
        let mut compiler = Compiler::new();
        compiler.set_optimization_level(level);
        let program = compiler.analyze(source).unwrap();
        if let Some(snapshot) = &program_snapshot {
            assert_eq!(&program, snapshot, "{level:?}");
        } else {
            program_snapshot = Some(program.clone());
        }
        let bytes = compiler.compile(&program).unwrap();
        assert_eq!(compiler.compile(&program).unwrap(), bytes, "{level:?}");
        if let Some(expected) = &enabled_bytes {
            assert_eq!(&bytes, expected, "{level:?}");
        } else {
            enabled_bytes = Some(bytes);
        }
    }
}

fn compiler_at(level: OptimizationLevel) -> Compiler {
    let mut compiler = Compiler::new();
    compiler.set_optimization_level(level);
    compiler
}

fn inject(value: &mut TypedExpr) {
    let sequence = normalized(value);
    sequence.bindings[0].origin = CallBindingOrigin::PipelineInput;
    for binding in &mut sequence.bindings[1..] {
        if let CallBindingOrigin::Explicit { argument } = &mut binding.origin {
            *argument -= 1;
        }
    }
}

fn assert_invalid(program: &TypedProgram, reason: &'static str, span: was_compiler::tokens::Span) {
    let expected = CodegenError::InvalidNormalizedCall { reason, span };
    assert_eq!(codegen::compile(program).unwrap_err(), expected);
    for level in [
        OptimizationLevel::None,
        OptimizationLevel::Basic,
        OptimizationLevel::Standard,
        OptimizationLevel::Aggressive,
    ] {
        let mut compiler = Compiler::new();
        compiler.set_optimization_level(level);
        compiler.set_exports(ExportOptions::None);
        assert_eq!(compiler.compile(program).unwrap_err(), expected);
    }
}

fn nested_fixture() -> TypedProgram {
    let mut program = Compiler::new()
        .analyze(
            "fn target(a: number, b: number, c: number, d: number = a + b) -> number { return d; }
         fn main() -> number { return target(target(5, c: 7, b: 6), c: 33, b: 22); }",
        )
        .unwrap();
    let value = returned(&mut program);
    inject(value);
    inject(&mut normalized(value).bindings[0].value);
    program
}

fn returned(program: &mut TypedProgram) -> &mut TypedExpr {
    let TypedStatementKind::Return(Some(value)) = &mut program.functions[1].body[0].kind else {
        panic!("return")
    };
    value
}

fn normalized(value: &mut TypedExpr) -> &mut TypedNormalizedCall {
    let TypedExprKind::NormalizedCall(sequence) = &mut value.kind else {
        panic!("normalized call")
    };
    sequence
}

fn fixture() -> TypedProgram {
    let mut program = Compiler::new()
        .analyze(
            "fn target(a: number, b: number, c: number, d: number = a + b) -> number { return d; }
             fn main() -> number { return target(11, c: 33, b: 22); }",
        )
        .unwrap();
    let sequence = normalized(returned(&mut program));
    sequence.bindings[0].origin = CallBindingOrigin::PipelineInput;
    sequence.bindings[1].origin = CallBindingOrigin::Explicit { argument: 0 };
    sequence.bindings[2].origin = CallBindingOrigin::Explicit { argument: 1 };
    program
}

fn multiple_default_fixture(call: &str) -> TypedProgram {
    let mut program = Compiler::new()
        .analyze(&format!(
            "fn target(a: number = 7, b: number = a + 1,
                c: number = b + 2, d: number = c + 3,
                e: number = d + 4, f: number = e + 5) -> number {{ return f; }}
             fn main() -> number {{ return {call}; }}"
        ))
        .unwrap();
    inject(returned(&mut program));
    program
}

#[test]
fn named_mixed_and_default_pipeline_sources_match_checked_normalization() {
    for (ordinary, pipeline) in [
        ("target(11, e: 55, b: 22)", "11 |> target(e: 55, b: 22)"),
        ("target(11, 22, e: 55)", "11 |> target(22, e: 55)"),
        ("target(11)", "11 |> target"),
        ("target(11)", "11 |> target()"),
    ] {
        let declarations = "fn target(a: number = 7, b: number = a + 1,
            c: number = b + 2, d: number = c + 3,
            e: number = d + 4, f: number = e + 5) -> number { return f; }";
        let mut expected = Compiler::new()
            .analyze(&format!(
                "{declarations} fn main() -> number {{ return {ordinary}; }}"
            ))
            .unwrap();
        inject(returned(&mut expected));
        let program = Compiler::new()
            .analyze(&format!(
                "{declarations} fn main() -> number {{ return {pipeline}; }}"
            ))
            .unwrap();
        let expected_bytes = Compiler::new().compile(&expected).unwrap();
        for level in [
            OptimizationLevel::None,
            OptimizationLevel::Basic,
            OptimizationLevel::Standard,
            OptimizationLevel::Aggressive,
        ] {
            let mut compiler = Compiler::new();
            compiler.set_optimization_level(level);
            let bytes = compiler.compile(&program).unwrap();
            Validator::new().validate_all(&bytes).unwrap();
            if level == OptimizationLevel::None {
                assert_eq!(bytes, expected_bytes, "{pipeline}, {level:?}");
            }
            assert_eq!(compiler.compile(&expected).unwrap(), bytes);
            assert_eq!(compiler.compile(&program).unwrap(), bytes);
        }
    }
}

#[test]
fn multiple_pipeline_defaults_store_once_in_formal_order_after_written_arguments() {
    for level in LEVELS {
        for (call, b_slot, e_slot) in [
            ("target(11, e: 55, b: 22)", 2, 1),
            ("target(11, 22, e: 55)", 1, 2),
        ] {
            let program = multiple_default_fixture(call);
            let snapshot = program.clone();
            let bytes = compiler_at(level).compile(&program).unwrap();
            Validator::new().validate_all(&bytes).unwrap();
            let body = Parser::new(0)
                .parse_all(&bytes)
                .filter_map(|payload| match payload.unwrap() {
                    Payload::CodeSectionEntry(body) => Some(body),
                    Payload::TableSection(_) | Payload::ElementSection(_) => {
                        panic!("no function table")
                    }
                    _ => None,
                })
                .nth(1)
                .unwrap();
            let locals: Vec<_> = body
                .get_locals_reader()
                .unwrap()
                .into_iter()
                .map(Result::unwrap)
                .collect();
            assert_eq!(locals, [(1, ValType::F64); 6]);
            let ops: Vec<_> = body
                .get_operators_reader()
                .unwrap()
                .into_iter()
                .map(Result::unwrap)
                .collect();
            let written = if b_slot == 2 {
                [55f64, 22f64]
            } else {
                [22f64, 55f64]
            };
            if level == OptimizationLevel::None {
                assert!(
                    matches!(ops.as_slice(), [
            Operator::F64Const { value: input }, Operator::LocalSet { local_index: 0 },
            Operator::F64Const { value: first }, Operator::LocalSet { local_index: 1 },
            Operator::F64Const { value: second }, Operator::LocalSet { local_index: 2 },
            Operator::LocalGet { local_index: c_read }, Operator::F64Const { value: two },
            Operator::F64Add, Operator::LocalSet { local_index: 3 },
            Operator::LocalGet { local_index: 3 }, Operator::F64Const { value: three },
            Operator::F64Add, Operator::LocalSet { local_index: 4 },
            Operator::LocalGet { local_index: f_read }, Operator::F64Const { value: five },
            Operator::F64Add, Operator::LocalSet { local_index: 5 },
            Operator::LocalGet { local_index: 0 }, Operator::LocalGet { local_index: b_arg },
            Operator::LocalGet { local_index: 3 }, Operator::LocalGet { local_index: 4 },
            Operator::LocalGet { local_index: e_arg }, Operator::LocalGet { local_index: 5 },
            Operator::Call { function_index: 0 }, Operator::Return, Operator::End,
        ] if input.bits() == 11f64.to_bits()
            && first.bits() == written[0].to_bits() && second.bits() == written[1].to_bits()
            && two.bits() == 2f64.to_bits() && three.bits() == 3f64.to_bits() && five.bits() == 5f64.to_bits()
            && *c_read == b_slot && *b_arg == b_slot && *f_read == e_slot && *e_arg == e_slot),
                    "{call}: {ops:?}"
                );
            } else {
                assert!(
                    matches!(ops.as_slice(), [
            Operator::I32Const { value: input }, Operator::F64ConvertI32S, Operator::LocalSet { local_index: 0 },
            Operator::I32Const { value: first }, Operator::F64ConvertI32S, Operator::LocalSet { local_index: 1 },
            Operator::I32Const { value: second }, Operator::F64ConvertI32S, Operator::LocalSet { local_index: 2 },
            Operator::LocalGet { local_index: c_read }, Operator::I32Const { value: two }, Operator::F64ConvertI32S,
            Operator::F64Add, Operator::LocalSet { local_index: 3 },
            Operator::LocalGet { local_index: 3 }, Operator::I32Const { value: three }, Operator::F64ConvertI32S,
            Operator::F64Add, Operator::LocalSet { local_index: 4 },
            Operator::LocalGet { local_index: f_read }, Operator::I32Const { value: five }, Operator::F64ConvertI32S,
            Operator::F64Add, Operator::LocalSet { local_index: 5 },
            Operator::LocalGet { local_index: 0 }, Operator::LocalGet { local_index: b_arg },
            Operator::LocalGet { local_index: 3 }, Operator::LocalGet { local_index: 4 },
            Operator::LocalGet { local_index: e_arg }, Operator::LocalGet { local_index: 5 },
            Operator::Call { function_index: 0 }, Operator::Return, Operator::End,
        ] if *input == 11
            && *first == (if b_slot == 2 { 55 } else { 22 }) && *second == (if b_slot == 2 { 22 } else { 55 })
            && *two == 2 && *three == 3 && *five == 5
            && *c_read == b_slot && *b_arg == b_slot && *f_read == e_slot && *e_arg == e_slot),
                    "{call}: {ops:?}"
                );
            }
            assert_eq!(program, snapshot);
            let compiler = compiler_at(level);
            assert_eq!(compiler.compile(&program).unwrap(), bytes);
        }
    }
}

#[test]
fn omitted_pipeline_defaults_capture_injection_then_each_dependent_default_once() {
    for level in LEVELS {
        let program = multiple_default_fixture("target(11)");
        let bytes = compiler_at(level).compile(&program).unwrap();
        Validator::new().validate_all(&bytes).unwrap();
        let body = Parser::new(0)
            .parse_all(&bytes)
            .filter_map(|payload| match payload.unwrap() {
                Payload::CodeSectionEntry(body) => Some(body),
                _ => None,
            })
            .nth(1)
            .unwrap();
        let ops: Vec<_> = body
            .get_operators_reader()
            .unwrap()
            .into_iter()
            .map(Result::unwrap)
            .collect();
        let tail = if level == OptimizationLevel::None {
            assert!(
                matches!(&ops[..2], [Operator::F64Const { value }, Operator::LocalSet { local_index: 0 }] if value.bits() == 11f64.to_bits())
            );
            for (chunk, (read, store, increment)) in ops[2..22].as_chunks::<4>().0.iter().zip([
                (0, 1, 1f64),
                (1, 2, 2f64),
                (2, 3, 3f64),
                (3, 4, 4f64),
                (4, 5, 5f64),
            ]) {
                assert!(matches!(chunk, [
            Operator::LocalGet { local_index: actual_read }, Operator::F64Const { value },
            Operator::F64Add, Operator::LocalSet { local_index: actual_store },
        ] if *actual_read == read && *actual_store == store && value.bits() == increment.to_bits()));
            }
            &ops[22..]
        } else {
            assert!(
                matches!(&ops[..3], [Operator::I32Const { value }, Operator::F64ConvertI32S, Operator::LocalSet { local_index: 0 }] if *value == 11)
            );
            for (chunk, (read, store, increment)) in ops[3..28].as_chunks::<5>().0.iter().zip([
                (0, 1, 1i32),
                (1, 2, 2i32),
                (2, 3, 3i32),
                (3, 4, 4i32),
                (4, 5, 5i32),
            ]) {
                assert!(matches!(chunk, [
            Operator::LocalGet { local_index: actual_read }, Operator::I32Const { value }, Operator::F64ConvertI32S,
            Operator::F64Add, Operator::LocalSet { local_index: actual_store },
        ] if *actual_read == read && *actual_store == store && *value == increment));
            }
            &ops[28..]
        };
        assert!(matches!(
            tail,
            [
                Operator::LocalGet { local_index: 0 },
                Operator::LocalGet { local_index: 1 },
                Operator::LocalGet { local_index: 2 },
                Operator::LocalGet { local_index: 3 },
                Operator::LocalGet { local_index: 4 },
                Operator::LocalGet { local_index: 5 },
                Operator::Call { function_index: 0 },
                Operator::Return,
                Operator::End,
            ]
        ));
    }
}

#[test]
fn pipeline_default_origins_and_named_formal_mappings_remain_checked() {
    for case in 0..7 {
        let mut program = multiple_default_fixture("target(11, e: 55, b: 22)");
        let span = program.functions[1].body[0].span;
        let sequence = normalized(returned(&mut program));
        let (reason, span) = match case {
            0 => {
                sequence.bindings[3].origin = CallBindingOrigin::Default { formal: 4 };
                (
                    "default origin must match its formal mapping",
                    sequence.bindings[3].span,
                )
            }
            1 => {
                sequence.bindings.swap(3, 4);
                (
                    "defaults must follow explicit arguments in increasing formal order",
                    sequence.bindings[4].span,
                )
            }
            2 => {
                sequence.bindings[4].origin = CallBindingOrigin::Explicit { argument: 2 };
                (
                    "bindings must have contiguous written-order explicit origins",
                    sequence.bindings[4].span,
                )
            }
            3 => {
                sequence.bindings[2].origin = CallBindingOrigin::Explicit { argument: 0 };
                (
                    "bindings must have contiguous written-order explicit origins",
                    sequence.bindings[2].span,
                )
            }
            4 => {
                sequence.formal_to_binding[1] = sequence.formal_to_binding[4];
                let TypedExprKind::Call { args, .. } = &mut sequence.call.kind else {
                    panic!("call")
                };
                args[1] = args[4].clone();
                ("formal mapping must be a bijection", span)
            }
            5 => {
                let TypedExprKind::Call { args, .. } = &mut sequence.call.kind else {
                    panic!("call")
                };
                args.swap(1, 4);
                (
                    "final arguments must read owned bindings in formal order",
                    span,
                )
            }
            6 => {
                sequence.bindings[3].origin = CallBindingOrigin::PipelineInput;
                (
                    "pipeline input must be the first and only injected binding",
                    sequence.bindings[3].span,
                )
            }
            _ => unreachable!(),
        };
        assert_invalid(&program, reason, span);
    }
}

#[test]
fn pipeline_defaults_read_only_earlier_formals_not_earlier_storage_slots() {
    for (default, allowed) in [
        (3, &[0, 2][..]),
        (4, &[0, 2, 3][..]),
        (5, &[0, 2, 3, 4, 1][..]),
    ] {
        for owned in 0..7 {
            let mut program = multiple_default_fixture("target(11, e: 55, b: 22)");
            let sequence = normalized(returned(&mut program));
            let id = if owned == 6 {
                was_compiler::typed_ast::VariableId(999)
            } else {
                sequence.bindings[owned].id
            };
            let span = sequence.bindings[default].span;
            sequence.bindings[default].value = TypedExpr {
                kind: TypedExprKind::Identifier {
                    id,
                    name: "forged".into(),
                },
                ty: Type::Number.into(),
            };
            if allowed.contains(&owned) {
                let bytes = Compiler::new().compile(&program).unwrap();
                Validator::new().validate_all(&bytes).unwrap();
            } else {
                assert_invalid(
                    &program,
                    "defaults may only read owned earlier-formal bindings",
                    span,
                );
            }
        }
    }
}

fn multiple_default_chain() -> TypedProgram {
    let mut program = multiple_default_fixture(
        "target(target(target(11, e: 55, b: 22), 22, e: 55), e: 55, b: 22)",
    );
    let middle = &mut normalized(returned(&mut program)).bindings[0].value;
    inject(middle);
    inject(&mut normalized(middle).bindings[0].value);
    program
}

#[test]
fn nested_named_default_stages_have_distinct_once_only_storage_and_direct_calls() {
    for level in LEVELS {
        let program = multiple_default_chain();
        let bytes = compiler_at(level).compile(&program).unwrap();
        Validator::new().validate_all(&bytes).unwrap();
        let body = Parser::new(0)
            .parse_all(&bytes)
            .filter_map(|payload| match payload.unwrap() {
                Payload::CodeSectionEntry(body) => Some(body),
                Payload::TableSection(_) | Payload::ElementSection(_) => {
                    panic!("no function table")
                }
                _ => None,
            })
            .nth(1)
            .unwrap();
        let locals: Vec<_> = body
            .get_locals_reader()
            .unwrap()
            .into_iter()
            .map(Result::unwrap)
            .collect();
        assert_eq!(locals, [(1, ValType::F64); 18]);
        let mut sets = Vec::new();
        let mut gets = Vec::new();
        let mut calls = Vec::new();
        let mut constants = Vec::new();
        let mut integer_constants = Vec::new();
        let mut conversions = 0;
        for op in body.get_operators_reader().unwrap() {
            match op.unwrap() {
                Operator::LocalSet { local_index } => sets.push(local_index),
                Operator::LocalGet { local_index } => gets.push(local_index),
                Operator::Call { function_index } => calls.push(function_index),
                Operator::CallIndirect { .. } => panic!("no indirect call"),
                Operator::F64Const { value } => constants.push(f64::from_bits(value.bits())),
                Operator::I32Const { value } => integer_constants.push(value),
                Operator::F64ConvertI32S => conversions += 1,
                _ => {}
            }
        }
        assert_eq!(
            sets,
            [2, 3, 4, 5, 6, 7, 1, 8, 9, 10, 11, 12, 0, 13, 14, 15, 16, 17]
        );
        assert_eq!(
            gets,
            [
                4, 5, 3, 2, 4, 5, 6, 3, 7, 8, 10, 9, 1, 8, 10, 11, 9, 12, 14, 15, 13, 0, 14, 15,
                16, 13, 17
            ]
        );
        assert_eq!(calls, [0, 0, 0]);
        if level == OptimizationLevel::None {
            assert!(integer_constants.is_empty());
            assert_eq!(conversions, 0);
            assert_eq!(
                constants,
                [
                    11.0, 55.0, 22.0, 2.0, 3.0, 5.0, 22.0, 55.0, 2.0, 3.0, 5.0, 55.0, 22.0, 2.0,
                    3.0, 5.0
                ]
            );
        } else {
            assert!(constants.is_empty());
            assert_eq!(
                integer_constants,
                [11, 55, 22, 2, 3, 5, 22, 55, 2, 3, 5, 55, 22, 2, 3, 5]
            );
            assert_eq!(conversions, 16);
        }
    }
}

#[test]
fn named_pipeline_ownership_checks_include_all_defaults_and_nested_scopes() {
    for initializer in 0..3 {
        for owned in 0..6 {
            let mut program = multiple_default_fixture("target(11, e: 55, b: 22)");
            let sequence = normalized(returned(&mut program));
            sequence.bindings[initializer].value = TypedExpr {
                kind: TypedExprKind::Identifier {
                    id: sequence.bindings[owned].id,
                    name: "owned".into(),
                },
                ty: Type::Number.into(),
            };
            for level in [
                OptimizationLevel::None,
                OptimizationLevel::Basic,
                OptimizationLevel::Standard,
                OptimizationLevel::Aggressive,
            ] {
                let mut compiler = Compiler::new();
                compiler.set_optimization_level(level);
                assert!(
                    matches!(
                        compiler.compile(&program),
                        Err(CodegenError::InvalidNormalizedCall { .. })
                    ),
                    "initializer {initializer}, owned {owned}"
                );
            }
        }
    }
    for escape in [false, true] {
        let mut program = multiple_default_chain();
        let outer = normalized(returned(&mut program));
        let outer_id = outer.bindings[0].id;
        let middle = normalized(&mut outer.bindings[0].value);
        let inner = normalized(&mut middle.bindings[0].value);
        let inner_id = inner.bindings[0].id;
        let binding = if escape {
            &mut outer.bindings[3]
        } else {
            &mut inner.bindings[3]
        };
        let span = binding.span;
        binding.value = TypedExpr {
            kind: TypedExprKind::Identifier {
                id: if escape { inner_id } else { outer_id },
                name: "cross_scope".into(),
            },
            ty: Type::Number.into(),
        };
        assert_invalid(
            &program,
            "defaults may only read owned earlier-formal bindings",
            span,
        );
    }
}

#[test]
fn later_named_stage_defaults_and_children_are_checked_after_never() {
    use was_compiler::typed_ast::{ExprResult, LoopId};

    for divergent in [0, 1] {
        for case in 0..4 {
            let mut program = multiple_default_chain();
            let value = returned(&mut program);
            value.ty = ExprResult::Never;
            let outer = normalized(value);
            outer.bindings[0].value.ty = ExprResult::Never;
            let middle = normalized(&mut outer.bindings[0].value);
            middle.bindings[0].value.ty = ExprResult::Never;
            let inner = normalized(&mut middle.bindings[0].value);
            inner.bindings[divergent].value = TypedExpr {
                kind: TypedExprKind::Loop {
                    id: LoopId(77),
                    body: vec![],
                },
                ty: ExprResult::Never,
            };
            let bytes = Compiler::new().compile(&program).unwrap();
            Validator::new().validate_all(&bytes).unwrap();
            let outer = normalized(returned(&mut program));
            let binding = if case == 3 { 1 } else { 3 };
            let span = outer.bindings[binding].span;
            match case {
                0 | 3 => {
                    outer.bindings[binding].value.kind = TypedExprKind::Number("invalid".into());
                    for level in [
                        OptimizationLevel::None,
                        OptimizationLevel::Basic,
                        OptimizationLevel::Standard,
                        OptimizationLevel::Aggressive,
                    ] {
                        let mut compiler = Compiler::new();
                        compiler.set_optimization_level(level);
                        compiler.set_exports(ExportOptions::None);
                        assert!(
                            matches!(compiler.compile(&program), Err(CodegenError::InvalidNumberLiteral { span: actual, .. }) if actual == span)
                        );
                    }
                }
                1 => {
                    outer.bindings[3].value = TypedExpr {
                        kind: TypedExprKind::Identifier {
                            id: outer.bindings[1].id,
                            name: "later_formal".into(),
                        },
                        ty: Type::Number.into(),
                    };
                    assert_invalid(
                        &program,
                        "defaults may only read owned earlier-formal bindings",
                        span,
                    );
                }
                2 => {
                    outer.bindings[3].origin = CallBindingOrigin::Default { formal: 4 };
                    assert_invalid(
                        &program,
                        "default origin must match its formal mapping",
                        span,
                    );
                }
                _ => unreachable!(),
            }
        }
    }
}

#[test]
fn pipeline_helpers_follow_users_memory_remainder_and_range_order() {
    for level in LEVELS {
        use wasmparser::ExternalKind;

        let mut compiler = compiler_at(level);
        compiler.set_exports(ExportOptions::Only(vec!["main".into()]));
        let program = compiler
            .analyze(
                "fn make(n: number) -> range { return 0..n; }
         fn inspect(r: range) -> number {
             let values = [5, 2];
             if (1 in r) { return values[0] % values[1]; }
             return len(values);
         }
         fn main() -> number { return 4 |> make |> inspect; }",
            )
            .unwrap();
        let bytes = compiler.compile(&program).unwrap();
        Validator::new().validate_all(&bytes).unwrap();

        let mut signatures = Vec::new();
        let mut functions = Vec::new();
        let mut exports = Vec::new();
        let mut calls = Vec::new();
        for payload in Parser::new(0).parse_all(&bytes) {
            match payload.unwrap() {
                Payload::TypeSection(reader) => {
                    for signature in reader.into_iter_err_on_gc_types() {
                        let signature = signature.unwrap();
                        signatures
                            .push((signature.params().to_vec(), signature.results().to_vec()));
                    }
                }
                Payload::FunctionSection(reader) => {
                    functions.extend(reader.into_iter().map(Result::unwrap))
                }
                Payload::ExportSection(reader) => {
                    for export in reader {
                        let export = export.unwrap();
                        exports.push((export.name, export.kind, export.index));
                    }
                }
                Payload::CodeSectionEntry(body) => {
                    let mut direct = Vec::new();
                    for op in body.get_operators_reader().unwrap() {
                        match op.unwrap() {
                            Operator::Call { function_index } => direct.push(function_index),
                            Operator::CallIndirect { .. } => panic!("no indirect call"),
                            _ => {}
                        }
                    }
                    calls.push(direct);
                }
                Payload::ImportSection(reader) => assert_eq!(reader.count(), 0, "no imports"),
                Payload::TableSection(_) | Payload::ElementSection(_) => {
                    panic!("no function table")
                }
                _ => {}
            }
        }

        use ValType::{F64, I32};
        let function_signatures: Vec<_> = functions
            .iter()
            .map(|index| signatures[usize::try_from(*index).unwrap()].clone())
            .collect();
        assert_eq!(
            function_signatures,
            [
                (vec![F64], vec![I32]),                // 0: make
                (vec![I32], vec![F64]),                // 1: inspect
                (vec![], vec![F64]),                   // 2: main
                (vec![I32], vec![I32]),                // 3: Alloc
                (vec![I32], vec![I32]),                // 4: ValidateString
                (vec![I32], vec![I32]),                // 5: ValidateArray
                (vec![I32, F64], vec![I32]),           // 6: ArrayAddress
                (vec![I32], vec![F64]),                // 7: ArrayLen
                (vec![I32, I32], vec![I32]),           // 8: StringEqual
                (vec![I32, I32], vec![I32]),           // 9: ArrayEqual
                (vec![F64, F64], vec![F64]),           // 10: floating remainder
                (vec![F64, F64, F64, I32], vec![I32]), // 11: Construct
                (vec![I32], vec![I32]),                // 12: Validate
                (vec![F64, I32], vec![I32]),           // 13: Contains
            ]
        );
        assert_eq!(
            calls,
            [
                vec![11],                     // make constructs the private range
                vec![12, 3, 13, 6, 6, 10, 7], // inspect validates, allocates, tests, indexes, computes
                vec![0, 1],                   // pipeline stages remain direct user calls
                vec![],
                vec![],
                vec![],
                vec![5],
                vec![5], // array address and length validate arrays
                vec![4, 4],
                vec![5, 5], // equality validates both complete descriptors
                vec![],     // floating remainder needs no helpers
                vec![3],
                vec![],
                vec![12], // range construction allocates; membership validates
            ]
        );
        assert_eq!(exports.len(), 3);
        assert!(exports.contains(&("main", ExternalKind::Func, 2)));
        assert!(exports.contains(&("memory", ExternalKind::Memory, 0)));
        assert!(exports.contains(&("__alloc", ExternalKind::Func, 3)));
    }
}

#[test]
fn injection_precedes_written_arguments_and_defaults_with_direct_formal_order_call() {
    for level in LEVELS {
        let program = fixture();
        let snapshot = program.clone();
        let bytes = compiler_at(level).compile(&program).unwrap();
        Validator::new().validate_all(&bytes).unwrap();
        let mut bodies = Vec::new();
        for payload in Parser::new(0).parse_all(&bytes) {
            match payload.unwrap() {
                Payload::TableSection(_) | Payload::ElementSection(_) => {
                    panic!("no function table")
                }
                Payload::CodeSectionEntry(body) => bodies.push(body),
                _ => {}
            }
        }
        let locals: Vec<_> = bodies[1]
            .get_locals_reader()
            .unwrap()
            .into_iter()
            .map(Result::unwrap)
            .collect();
        assert_eq!(locals, [(1, ValType::F64); 4]);
        let ops: Vec<_> = bodies[1]
            .get_operators_reader()
            .unwrap()
            .into_iter()
            .map(Result::unwrap)
            .collect();
        if level == OptimizationLevel::None {
            assert!(matches!(ops.as_slice(), [
        Operator::F64Const { value: input }, Operator::LocalSet { local_index: 0 },
        Operator::F64Const { value: c }, Operator::LocalSet { local_index: 1 },
        Operator::F64Const { value: b }, Operator::LocalSet { local_index: 2 },
        Operator::LocalGet { local_index: 0 }, Operator::LocalGet { local_index: 2 },
        Operator::F64Add, Operator::LocalSet { local_index: 3 },
        Operator::LocalGet { local_index: 0 }, Operator::LocalGet { local_index: 2 },
        Operator::LocalGet { local_index: 1 }, Operator::LocalGet { local_index: 3 },
        Operator::Call { function_index: 0 }, Operator::Return, Operator::End,
    ] if input.bits() == 11f64.to_bits() && c.bits() == 33f64.to_bits() && b.bits() == 22f64.to_bits()));
        } else {
            assert!(matches!(ops.as_slice(), [
        Operator::I32Const { value: input }, Operator::F64ConvertI32S, Operator::LocalSet { local_index: 0 },
        Operator::I32Const { value: c }, Operator::F64ConvertI32S, Operator::LocalSet { local_index: 1 },
        Operator::I32Const { value: b }, Operator::F64ConvertI32S, Operator::LocalSet { local_index: 2 },
        Operator::LocalGet { local_index: 0 }, Operator::LocalGet { local_index: 2 },
        Operator::F64Add, Operator::LocalSet { local_index: 3 },
        Operator::LocalGet { local_index: 0 }, Operator::LocalGet { local_index: 2 },
        Operator::LocalGet { local_index: 1 }, Operator::LocalGet { local_index: 3 },
        Operator::Call { function_index: 0 }, Operator::Return, Operator::End,
    ] if *input == 11 && *c == 33 && *b == 22));
        }
        assert_eq!(program, snapshot);
        let compiler = compiler_at(level);
        assert_eq!(compiler.compile(&program).unwrap(), bytes);
    }
}

#[test]
fn duplicate_misplaced_and_wrongly_mapped_injections_are_rejected() {
    for case in 0..5 {
        let mut program = fixture();
        let sequence = normalized(returned(&mut program));
        let (reason, span) = match case {
            0 => {
                sequence.bindings[1].origin = CallBindingOrigin::PipelineInput;
                (
                    "pipeline input must be the first and only injected binding",
                    sequence.bindings[1].span,
                )
            }
            1 => {
                sequence.bindings.swap(0, 1);
                sequence.bindings[0].origin = CallBindingOrigin::Explicit { argument: 0 };
                (
                    "pipeline input must be the first and only injected binding",
                    sequence.bindings[1].span,
                )
            }
            2 => {
                sequence.formal_to_binding.swap(0, 1);
                (
                    "pipeline input must map to formal zero",
                    sequence.bindings[0].span,
                )
            }
            3 => {
                sequence.bindings[1].origin = CallBindingOrigin::Explicit { argument: 1 };
                (
                    "bindings must have contiguous written-order explicit origins",
                    sequence.bindings[1].span,
                )
            }
            4 => {
                sequence.bindings[3].origin = CallBindingOrigin::PipelineInput;
                (
                    "pipeline input must be the first and only injected binding",
                    sequence.bindings[3].span,
                )
            }
            _ => unreachable!(),
        };
        assert_invalid(&program, reason, span);
    }
}

#[test]
fn nested_injections_use_distinct_slots_and_only_direct_calls() {
    for level in LEVELS {
        let program = nested_fixture();
        let bytes = compiler_at(level).compile(&program).unwrap();
        Validator::new().validate_all(&bytes).unwrap();
        let mut bodies = Vec::new();
        for payload in Parser::new(0).parse_all(&bytes) {
            match payload.unwrap() {
                Payload::TableSection(_) | Payload::ElementSection(_) => {
                    panic!("no function table")
                }
                Payload::CodeSectionEntry(body) => bodies.push(body),
                _ => {}
            }
        }
        let mut sets = Vec::new();
        let mut gets = Vec::new();
        let mut calls = Vec::new();
        let mut constants = Vec::new();
        let mut integer_constants = Vec::new();
        let mut conversions = 0;
        for op in bodies[1].get_operators_reader().unwrap() {
            match op.unwrap() {
                Operator::LocalSet { local_index } => sets.push(local_index),
                Operator::LocalGet { local_index } => gets.push(local_index),
                Operator::Call { function_index } => calls.push(function_index),
                Operator::CallIndirect { .. } => panic!("no indirect call"),
                Operator::F64Const { value } => constants.push(f64::from_bits(value.bits())),
                Operator::I32Const { value } => integer_constants.push(value),
                Operator::F64ConvertI32S => conversions += 1,
                _ => {}
            }
        }
        assert_eq!(sets, [1, 2, 3, 4, 0, 5, 6, 7]);
        assert_eq!(gets, [1, 3, 1, 3, 2, 4, 0, 6, 0, 6, 5, 7]);
        assert_eq!(calls, [0, 0]);
        if level == OptimizationLevel::None {
            assert!(integer_constants.is_empty());
            assert_eq!(conversions, 0);
            assert_eq!(constants, [5.0, 7.0, 6.0, 33.0, 22.0]);
        } else {
            assert!(constants.is_empty());
            assert_eq!(integer_constants, [5, 7, 6, 33, 22]);
            assert_eq!(conversions, 5);
        }
    }
}

#[test]
fn injection_and_explicit_initializers_cannot_read_owned_bindings_even_when_nested() {
    for nested in [false, true] {
        for initializer in 0..3 {
            for owned in 0..4 {
                let mut program = if nested { nested_fixture() } else { fixture() };
                let sequence = normalized(returned(&mut program));
                let id = sequence.bindings[owned].id;
                let value = &mut sequence.bindings[initializer].value;
                let value = if nested && initializer == 0 {
                    &mut normalized(value).bindings[0].value
                } else {
                    value
                };
                value.kind = TypedExprKind::Identifier {
                    id,
                    name: "forged".into(),
                };
                value.ty = Type::Number.into();
                assert!(
                    matches!(
                        Compiler::new().compile(&program),
                        Err(CodegenError::InvalidNormalizedCall { .. })
                    ),
                    "nested {nested}, initializer {initializer}, owned {owned}"
                );
            }
        }
    }
}

#[test]
fn nested_binding_ids_cannot_collide_or_escape_to_outer_arguments() {
    let mut program = nested_fixture();
    let outer = normalized(returned(&mut program));
    let outer_id = outer.bindings[0].id;
    normalized(&mut outer.bindings[0].value).bindings[0].id = outer_id;
    assert!(matches!(
        Compiler::new().compile(&program),
        Err(CodegenError::DuplicateVariableId { .. })
    ));

    let mut program = nested_fixture();
    let outer = normalized(returned(&mut program));
    let inner_id = normalized(&mut outer.bindings[0].value).bindings[0].id;
    outer.bindings[1].value = TypedExpr {
        kind: TypedExprKind::Identifier {
            id: inner_id,
            name: "escaped".into(),
        },
        ty: Type::Number.into(),
    };
    assert!(matches!(
        Compiler::new().compile(&program),
        Err(CodegenError::InvalidNormalizedCall { .. })
    ));
}

#[test]
fn injections_accept_caller_locals_and_each_concrete_storage_type() {
    for level in LEVELS {
        for (ty, initializer, storage) in [
            ("number", "11", ValType::F64),
            ("bool", "true", ValType::I32),
            ("string", "\"value\"", ValType::I32),
            ("number[]", "[1, 2]", ValType::I32),
            ("range", "1..3", ValType::I32),
        ] {
            let source = format!(
                "fn target(a: {ty}, b: number = 1) -> {ty} {{ return a; }}
             fn main() -> {ty} {{ let input = {initializer}; return target(input); }}"
            );
            let mut program = compiler_at(level).analyze(&source).unwrap();
            let TypedStatementKind::Return(Some(value)) = &mut program.functions[1].body[1].kind
            else {
                panic!("return")
            };
            inject(value);
            let mut compiler = compiler_at(level);
            compiler.set_exports(ExportOptions::None);
            let bytes = compiler.compile(&program).unwrap();
            Validator::new().validate_all(&bytes).unwrap();
            let body = Parser::new(0)
                .parse_all(&bytes)
                .filter_map(|payload| match payload.unwrap() {
                    Payload::CodeSectionEntry(body) => Some(body),
                    Payload::TableSection(_) | Payload::ElementSection(_) => {
                        panic!("no function table")
                    }
                    _ => None,
                })
                .nth(1)
                .unwrap();
            let locals: Vec<_> = body
                .get_locals_reader()
                .unwrap()
                .into_iter()
                .map(Result::unwrap)
                .collect();
            let input_storage = if ty == "number" && level != OptimizationLevel::None {
                ValType::I32
            } else {
                storage
            };
            assert_eq!(
                &locals[..3],
                [(1, input_storage), (1, storage), (1, ValType::F64)],
                "{ty}"
            );
            let mut calls = Vec::new();
            for op in body.get_operators_reader().unwrap() {
                match op.unwrap() {
                    Operator::Call { function_index } => calls.push(function_index),
                    Operator::CallIndirect { .. } => panic!("no indirect call"),
                    _ => {}
                }
            }
            assert_eq!(calls.last(), Some(&0), "{ty}");
        }
    }
}

#[test]
fn injected_transfer_uses_the_caller_context_with_a_live_stack_prefix() {
    use was_compiler::{
        ast::BinaryOp,
        typed_ast::{ExprResult, TypedStatement, TypedValueBlock},
    };

    let mut program = fixture();
    let value = returned(&mut program);
    let sequence = normalized(value);
    let span = sequence.bindings[0].span;
    sequence.bindings[0].value = TypedExpr {
        kind: TypedExprKind::Block(TypedValueBlock {
            statements: vec![TypedStatement {
                kind: TypedStatementKind::Return(Some(TypedExpr {
                    kind: TypedExprKind::Number("5".into()),
                    ty: Type::Number.into(),
                })),
                span,
            }],
            tail: None,
            span,
        }),
        ty: ExprResult::Never,
    };
    value.ty = ExprResult::Never;
    *value = TypedExpr {
        kind: TypedExprKind::Binary {
            left: Box::new(TypedExpr {
                kind: TypedExprKind::Number("99".into()),
                ty: Type::Number.into(),
            }),
            op: BinaryOp::Add,
            right: Box::new(value.clone()),
        },
        ty: ExprResult::Never,
    };
    let bytes = Compiler::new().compile(&program).unwrap();
    Validator::new().validate_all(&bytes).unwrap();
}

#[test]
fn never_injection_preserves_signature_result_and_checks_unreachable_children() {
    use was_compiler::typed_ast::{ExprResult, LoopId};

    let mut program = fixture();
    let value = returned(&mut program);
    value.ty = ExprResult::Never;
    let sequence = normalized(value);
    sequence.bindings[0].value = TypedExpr {
        kind: TypedExprKind::Loop {
            id: LoopId(77),
            body: vec![],
        },
        ty: ExprResult::Never,
    };
    assert_eq!(sequence.call.ty, ExprResult::Value(Type::Number));
    let bytes = Compiler::new().compile(&program).unwrap();
    Validator::new().validate_all(&bytes).unwrap();

    let mut forged = program.clone();
    returned(&mut forged).ty = Type::Number.into();
    assert!(Compiler::new().compile(&forged).is_err());

    let sequence = normalized(returned(&mut program));
    let span = sequence.bindings[2].span;
    sequence.bindings[2].value.kind = TypedExprKind::Number("invalid".into());
    assert!(
        matches!(Compiler::new().compile(&program), Err(CodegenError::InvalidNumberLiteral { span: actual, .. }) if actual == span)
    );
}

#[test]
fn final_void_source_emits_once_only_locals_and_a_direct_call_without_drop() {
    for level in LEVELS {
        let source = "fn sink(a: number, b: number = a + 1, c: number = b + 2) -> void {}
        fn main() -> void { ((11 |> sink(c: 33))); }";
        let mut expected = compiler_at(level)
            .analyze(
                "fn sink(a: number, b: number = a + 1, c: number = b + 2) -> void {}
         fn main() -> void { sink(11, c: 33); }",
            )
            .unwrap();
        let TypedStatementKind::Expression(value) = &mut expected.functions[1].body[0].kind else {
            panic!("expression")
        };
        inject(value);
        let bytes = compiler_at(level).compile(&expected).unwrap();
        Validator::new().validate_all(&bytes).unwrap();
        let body = Parser::new(0)
            .parse_all(&bytes)
            .filter_map(|payload| match payload.unwrap() {
                Payload::CodeSectionEntry(body) => Some(body),
                Payload::TableSection(_) | Payload::ElementSection(_) => {
                    panic!("no function table")
                }
                _ => None,
            })
            .nth(1)
            .unwrap();
        let locals: Vec<_> = body
            .get_locals_reader()
            .unwrap()
            .into_iter()
            .map(Result::unwrap)
            .collect();
        assert_eq!(locals, [(1, ValType::F64); 3]);
        let ops: Vec<_> = body
            .get_operators_reader()
            .unwrap()
            .into_iter()
            .map(Result::unwrap)
            .collect();
        if level == OptimizationLevel::None {
            assert!(
                matches!(ops.as_slice(), [
        Operator::F64Const { value: input }, Operator::LocalSet { local_index: 0 },
        Operator::F64Const { value: written }, Operator::LocalSet { local_index: 1 },
        Operator::LocalGet { local_index: 0 }, Operator::F64Const { value: increment },
        Operator::F64Add, Operator::LocalSet { local_index: 2 },
        Operator::LocalGet { local_index: 0 }, Operator::LocalGet { local_index: 2 },
        Operator::LocalGet { local_index: 1 }, Operator::Call { function_index: 0 }, Operator::End,
    ] if input.bits() == 11f64.to_bits() && written.bits() == 33f64.to_bits()
        && increment.bits() == 1f64.to_bits()),
                "{ops:?}"
            );
        } else {
            assert!(
                matches!(ops.as_slice(), [
        Operator::I32Const { value: input }, Operator::F64ConvertI32S, Operator::LocalSet { local_index: 0 },
        Operator::I32Const { value: written }, Operator::F64ConvertI32S, Operator::LocalSet { local_index: 1 },
        Operator::LocalGet { local_index: 0 }, Operator::I32Const { value: increment }, Operator::F64ConvertI32S,
        Operator::F64Add, Operator::LocalSet { local_index: 2 },
        Operator::LocalGet { local_index: 0 }, Operator::LocalGet { local_index: 2 },
        Operator::LocalGet { local_index: 1 }, Operator::Call { function_index: 0 }, Operator::End,
    ] if *input == 11 && *written == 33
        && *increment == 1),
                "{ops:?}"
            );
        }
        let compiler = compiler_at(level);
        assert_eq!(compiler.compile(&expected).unwrap(), bytes);
        let program = compiler.analyze(source).unwrap();
        assert_eq!(compiler.compile(&program).unwrap(), bytes);
        assert_eq!(compiler.compile_source(source).unwrap(), bytes);
    }
}

#[test]
fn final_void_discard_regions_are_empty_and_keep_direct_calls() {
    for level in LEVELS {
        let declarations = "fn sink(x: number, y: number = x + 1) -> void {}";
        for expression in [
            "{ ((1 |> sink)) }",
            "(if true { 1 |> sink } else { 2 |> sink() })",
            "{ if true { { 1 |> sink } } else { 2 |> sink } }",
            "{ match true { true => { 1 |> sink }, false => { if true { 2 |> sink } else { 3 |> sink } }, } }",
            "{ match true { true => (1 |> sink), false => 9, }; }",
        ] {
            let source = format!("{declarations} fn main() -> void {{ {expression}; }}");
            let program = compiler_at(level)
                .analyze(&source)
                .unwrap_or_else(|error| panic!("{expression}: {error}"));
            let bytes = compiler_at(level).compile(&program).unwrap();
            Validator::new().validate_all(&bytes).unwrap();
            let body = Parser::new(0)
                .parse_all(&bytes)
                .filter_map(|payload| match payload.unwrap() {
                    Payload::CodeSectionEntry(body) => Some(body),
                    _ => None,
                })
                .nth(1)
                .unwrap();
            let ops: Vec<_> = body
                .get_operators_reader()
                .unwrap()
                .into_iter()
                .map(Result::unwrap)
                .collect();
            let expected_calls = expression.matches("|>").count();
            assert_eq!(
                ops.iter()
                    .filter(|op| matches!(op, Operator::Call { function_index: 0 }))
                    .count(),
                expected_calls,
                "{expression}"
            );
            assert!(
                !ops.iter()
                    .any(|op| matches!(op, Operator::CallIndirect { .. })),
                "{expression}"
            );
            for op in &ops {
                if let Operator::Block { blockty } | Operator::If { blockty } = op {
                    assert_eq!(
                        *blockty,
                        wasmparser::BlockType::Empty,
                        "{expression}: {ops:?}"
                    );
                }
            }
            let drops = ops.iter().filter(|op| matches!(op, Operator::Drop)).count();
            assert_eq!(
                drops,
                usize::from(expression.contains("false => 9")),
                "{expression}: {ops:?}"
            );
            let compiler = compiler_at(level);
            assert_eq!(compiler.compile_source(&source).unwrap(), bytes);
        }
    }
}

#[test]
fn outer_discard_does_not_authorize_void_pipeline_values_or_nonfinal_stages() {
    for body in [
        "let x = 1 |> sink;",
        "let x: number = { 1 |> sink };",
        "take(1 |> sink);",
        "(1 |> sink) + 2;",
        "!(true |> flag);",
        "(1 |> sink) == (2 |> sink);",
        "(1 |> sink) |> sink;",
        "1 |> sink |> sink;",
        "({ return; 1 } |> sink |> sink);",
        "({ return; 1 } |> sink) + 2;",
        "take({ if true { 1 |> sink } else { 2 |> sink } });",
        "let x = match true { true => { 1 |> sink }, false => { 2 |> sink }, };",
        "let x = loop { break (1 |> sink); };",
    ] {
        let source = format!(
            "fn sink(x: number) -> void {{}} fn flag(x: bool) -> void {{}}
            fn take(x: number) -> void {{}} fn main() -> void {{ {body} }}"
        );
        assert!(
            matches!(
                Compiler::new().analyze(&source),
                Err(was_compiler::CompileError::Semantic(
                    SemanticError::InvalidPipeline { .. }
                ))
            ),
            "{body}"
        );
    }
    let source = "fn sink(x: number) -> void {} fn main() -> number { return 1 |> sink; }";
    assert!(matches!(
        Compiler::new().analyze(source),
        Err(was_compiler::CompileError::Semantic(
            SemanticError::InvalidPipeline { .. }
        ))
    ));
}

#[test]
fn forged_final_void_reconstructs_never_flow_and_checks_later_bindings() {
    for level in LEVELS {
        use was_compiler::typed_ast::{ExprResult, TypedStatement, TypedValueBlock};

        let mut program = compiler_at(level)
            .analyze(
                "fn sink(a: number, b: number, c: number = a + b) -> void {}
         fn main() -> void { sink({ return; 1 }, 2); }",
            )
            .unwrap();
        let TypedStatementKind::Expression(value) = &mut program.functions[1].body[0].kind else {
            panic!("expression")
        };
        inject(value);
        assert_eq!(value.ty, ExprResult::Never);
        assert_eq!(normalized(value).call.ty, ExprResult::Void);
        let bytes = compiler_at(level).compile(&program).unwrap();
        Validator::new().validate_all(&bytes).unwrap();
        let body = Parser::new(0)
            .parse_all(&bytes)
            .filter_map(|payload| match payload.unwrap() {
                Payload::CodeSectionEntry(body) => Some(body),
                _ => None,
            })
            .nth(1)
            .unwrap();
        let ops: Vec<_> = body
            .get_operators_reader()
            .unwrap()
            .into_iter()
            .map(Result::unwrap)
            .collect();
        assert!(ops.iter().any(|op| matches!(op, Operator::Return)));
        assert!(
            ops.iter()
                .any(|op| matches!(op, Operator::Call { function_index: 0 }))
        );
        assert!(
            !ops.iter()
                .any(|op| matches!(op, Operator::LocalSet { local_index: 0 } | Operator::Drop))
        );
        let compiler = compiler_at(level);
        assert_eq!(compiler.compile(&program).unwrap(), bytes);
        let mut forged = program.clone();
        let TypedStatementKind::Expression(value) = &mut forged.functions[1].body[0].kind else {
            panic!("expression")
        };
        value.ty = ExprResult::Void;
        assert!(
            compiler.compile(&forged).is_err(),
            "{level:?}: forged fallthrough"
        );
        let mut forged = program.clone();
        let TypedStatementKind::Expression(value) = &mut forged.functions[1].body[0].kind else {
            panic!("expression")
        };
        let sequence = normalized(value);
        sequence.bindings[1].value.kind = TypedExprKind::Number("invalid".into());
        let span = sequence.bindings[1].span;
        assert!(
            matches!(compiler.compile(&forged), Err(CodegenError::InvalidNumberLiteral { span: actual, .. }) if actual == span)
        );
        let TypedStatementKind::Expression(value) = &mut program.functions[1].body[0].kind else {
            panic!("expression")
        };
        let sequence = normalized(value);
        let span = sequence.bindings[1].span;
        sequence.bindings[1].origin = CallBindingOrigin::PipelineInput;
        assert_invalid(
            &program,
            "pipeline input must be the first and only injected binding",
            span,
        );

        // A typed Void tail needs no source-discard marker, but its category is checked.
        let mut program = compiler_at(level)
            .analyze("fn sink(a: number, b: number = a) -> void {} fn main() -> void { sink(5); }")
            .unwrap();
        let TypedStatementKind::Expression(value) = &mut program.functions[1].body[0].kind else {
            panic!("expression")
        };
        inject(value);
        let span = program.functions[1].body[0].span;
        let TypedStatementKind::Expression(value) = &mut program.functions[1].body[0].kind else {
            panic!("expression")
        };
        let tail = value.clone();
        *value = TypedExpr {
            kind: TypedExprKind::Block(TypedValueBlock {
                statements: Vec::<TypedStatement>::new(),
                tail: Some(Box::new(tail)),
                span,
            }),
            ty: ExprResult::Void,
        };
        Validator::new()
            .validate_all(&compiler_at(level).compile(&program).unwrap())
            .unwrap();
        value_category_forgery_is_rejected(&program);
    }
}

fn value_category_forgery_is_rejected(program: &TypedProgram) {
    let mut forged = program.clone();
    let TypedStatementKind::Expression(value) = &mut forged.functions[1].body[0].kind else {
        panic!("expression")
    };
    value.ty = Type::Number.into();
    assert!(Compiler::new().compile(&forged).is_err());
}

#[test]
fn forged_final_void_keeps_mapping_ownership_signature_and_default_checks() {
    use was_compiler::typed_ast::ExprResult;

    for divergent in [false, true] {
        let input = if divergent { "{ return; 5 }" } else { "5" };
        let mut baseline = Compiler::new()
            .analyze(&format!(
                "fn sink(a: number, b: number, c: number = a + b) -> void {{}}
             fn main() -> void {{ sink({input}, b: 6); }}",
            ))
            .unwrap();
        let TypedStatementKind::Expression(value) = &mut baseline.functions[1].body[0].kind else {
            panic!("expression")
        };
        inject(value);
        for case in 0..6 {
            let mut program = baseline.clone();
            let span = program.functions[1].body[0].span;
            let TypedStatementKind::Expression(value) = &mut program.functions[1].body[0].kind
            else {
                panic!("expression")
            };
            let sequence = normalized(value);
            let (reason, error_span) = match case {
                0 => {
                    sequence.formal_to_binding.swap(0, 1);
                    (
                        "pipeline input must map to formal zero",
                        sequence.bindings[0].span,
                    )
                }
                1 => {
                    sequence.call.ty = ExprResult::Never;
                    ("final call result does not match its signature", span)
                }
                2 => {
                    sequence.bindings[1].ty = Type::Bool;
                    (
                        "mapped binding and argument types must match the formal",
                        span,
                    )
                }
                3 => {
                    sequence.bindings[2].value = TypedExpr {
                        kind: TypedExprKind::Identifier {
                            id: sequence.bindings[2].id,
                            name: "self".into(),
                        },
                        ty: Type::Number.into(),
                    };

                    (
                        "defaults may only read owned earlier-formal bindings",
                        sequence.bindings[2].span,
                    )
                }
                4 => {
                    let TypedExprKind::Call { args, .. } = &mut sequence.call.kind else {
                        panic!("call")
                    };
                    args.swap(0, 1);
                    (
                        "final arguments must read owned bindings in formal order",
                        span,
                    )
                }
                5 => {
                    let TypedExprKind::Call { name, .. } = &mut sequence.call.kind else {
                        panic!("call")
                    };
                    *name = "wrong".into();
                    ("final call name does not match its target", span)
                }
                _ => unreachable!(),
            };
            assert_invalid(&program, reason, error_span);
        }
    }
}

#[test]
fn final_void_call_is_valid_but_void_cannot_be_injected() {
    use was_compiler::typed_ast::ExprResult;

    let mut program = Compiler::new()
        .analyze("fn target(a: number, b: number = a) -> void {} fn main() -> void { target(5); }")
        .unwrap();
    let TypedStatementKind::Expression(value) = &mut program.functions[1].body[0].kind else {
        panic!("expression")
    };
    inject(value);
    let void_value = value.clone();
    let bytes = Compiler::new().compile(&program).unwrap();
    Validator::new().validate_all(&bytes).unwrap();

    let mut receiving = fixture();
    normalized(returned(&mut receiving)).bindings[0].value = void_value;
    assert!(Compiler::new().compile(&receiving).is_err());

    let TypedStatementKind::Expression(value) = &mut program.functions[1].body[0].kind else {
        panic!("expression")
    };
    value.ty = ExprResult::Value(Type::Number);
    assert!(Compiler::new().compile(&program).is_err());
}

#[test]
fn skipped_and_unexported_injections_still_check_origins_and_default_reads() {
    use was_compiler::{ast::BinaryOp, typed_ast::TypedStatement};

    for skipped in [false, true] {
        for default_read in [false, true] {
            let mut program = fixture();
            let span = program.functions[1].body[0].span;
            let sequence = normalized(returned(&mut program));
            let (reason, error_span) = if default_read {
                let id = sequence.bindings[3].id;
                sequence.bindings[3].value = TypedExpr {
                    kind: TypedExprKind::Identifier {
                        id,
                        name: "self".into(),
                    },
                    ty: Type::Number.into(),
                };
                (
                    "defaults may only read owned earlier-formal bindings",
                    sequence.bindings[3].span,
                )
            } else {
                sequence.bindings[2].origin = CallBindingOrigin::PipelineInput;
                (
                    "pipeline input must be the first and only injected binding",
                    sequence.bindings[2].span,
                )
            };
            let value = returned(&mut program).clone();
            let expression = if skipped {
                TypedExpr {
                    kind: TypedExprKind::Binary {
                        left: Box::new(TypedExpr {
                            kind: TypedExprKind::Bool(false),
                            ty: Type::Bool.into(),
                        }),
                        op: BinaryOp::And,
                        right: Box::new(TypedExpr {
                            kind: TypedExprKind::Binary {
                                left: Box::new(value),
                                op: BinaryOp::Equal,
                                right: Box::new(TypedExpr {
                                    kind: TypedExprKind::Number("0".into()),
                                    ty: Type::Number.into(),
                                }),
                            },
                            ty: Type::Bool.into(),
                        }),
                    },
                    ty: Type::Bool.into(),
                }
            } else {
                value
            };
            let statement = TypedStatement {
                kind: TypedStatementKind::Expression(expression),
                span,
            };
            if skipped {
                program.functions[1].body.insert(0, statement);
            } else {
                program.functions[1].body.push(statement);
                *returned(&mut program) = TypedExpr {
                    kind: TypedExprKind::Number("0".into()),
                    ty: Type::Number.into(),
                };
            }
            // The original return must not duplicate the generated binding IDs.
            if skipped {
                let TypedStatementKind::Return(Some(value)) =
                    &mut program.functions[1].body[1].kind
                else {
                    panic!("return")
                };
                *value = TypedExpr {
                    kind: TypedExprKind::Number("0".into()),
                    ty: Type::Number.into(),
                };
            }
            assert_invalid(&program, reason, error_span);
        }
    }
}

#[test]
fn injection_retains_mapping_type_result_and_default_whitelist_checks() {
    for case in 0..8 {
        let mut program = nested_fixture();
        let outer = normalized(returned(&mut program));
        let inner = normalized(&mut outer.bindings[0].value);
        match case {
            0 => {
                inner.bindings[0].value = TypedExpr {
                    kind: TypedExprKind::Bool(true),
                    ty: Type::Bool.into(),
                }
            }
            1 => inner.bindings[0].ty = Type::Bool,
            2 => inner.call.ty = Type::Bool.into(),
            3 => inner.formal_to_binding[1] = inner.formal_to_binding[0],
            4 => inner.bindings[3].value = *inner.call.clone(),
            5 => inner.bindings[3].origin = CallBindingOrigin::Default { formal: 0 },
            6 => {
                let TypedExprKind::Call { args, .. } = &mut inner.call.kind else {
                    panic!("call")
                };
                args.swap(0, 1);
            }
            7 => outer.bindings[0].value.ty = Type::Bool.into(),
            _ => unreachable!(),
        }
        let mut compiler = Compiler::new();
        compiler.set_exports(ExportOptions::None);
        assert!(compiler.compile(&program).is_err(), "case {case}");
    }
}
