use crate::{
    ast::{BinaryOp, Type, UnaryOp},
    flow::Flow,
    tokens::Span,
    typed_ast::{ExprResult, TypedExpr, TypedExprKind, TypedValueBlock},
};
use wasm_encoder::{BlockType, Instruction, ValType};

use super::{
    CodegenError, call, control_flow, expect_operand, expect_result,
    function::{BodyEmitter, LoopKind},
    match_,
    memory::Helper,
    range,
    representation::Representation,
    values,
};

fn result(flow: Flow, ty: Type) -> ExprResult {
    if flow.can_fall_through() {
        ty.into()
    } else {
        ExprResult::Never
    }
}

fn eager_result(ty: Type, operands: &[&TypedExpr]) -> ExprResult {
    if operands.iter().any(|expr| expr.ty == ExprResult::Never) {
        ExprResult::Never
    } else {
        ty.into()
    }
}

pub(super) fn wasm_result(result: ExprResult) -> Option<ValType> {
    match result {
        ExprResult::Value(Type::Number) => Some(ValType::F64),
        ExprResult::Value(Type::Bool | Type::String | Type::Array(_) | Type::Range) => {
            Some(ValType::I32)
        }
        ExprResult::Value(Type::Void) | ExprResult::Void | ExprResult::Never => None,
    }
}

pub(super) fn block_type(result: ExprResult) -> BlockType {
    wasm_result(result).map_or(BlockType::Empty, BlockType::Result)
}

pub(super) fn emit(
    expr: &TypedExpr,
    body: &mut BodyEmitter<'_>,
    span: Span,
) -> Result<Flow, CodegenError> {
    emit_as(expr, body, span, Representation::F64)
}

pub(super) fn emit_as(
    expr: &TypedExpr,
    body: &mut BodyEmitter<'_>,
    span: Span,
    output: Representation,
) -> Result<Flow, CodegenError> {
    let function = body.name();
    let representation = body.numeric_representation(expr);

    let (flow, actual) = match &expr.kind {
        TypedExprKind::Number(literal) => {
            expect_result(function, Type::Number.into(), expr.ty, span)?;

            let value = number(literal, function, span)?;

            if representation == Representation::I32 {
                // The private proof checked parsed-value integrality and i32 bounds.
                body.instruction(&Instruction::I32Const(value as i32));
            } else {
                body.instruction(&Instruction::F64Const(value.into()));
            }

            (Flow::FALLTHROUGH, Type::Number.into())
        }

        TypedExprKind::Bool(value) => {
            expect_result(function, Type::Bool.into(), expr.ty, span)?;

            body.instruction(&Instruction::I32Const(i32::from(*value)));

            (Flow::FALLTHROUGH, Type::Bool.into())
        }

        TypedExprKind::Identifier { .. } | TypedExprKind::Captured { .. } => {
            if let Some(ty) = body.cell_address(expr, span)? {
                body.load_cell(ty);
            } else if let TypedExprKind::Identifier { id, .. } = &expr.kind {
                let index = body.resolve_expr(*id, expr.ty, span)?;
                body.local_get(index);
            }

            (Flow::FALLTHROUGH, expr.ty)
        }

        TypedExprKind::Unary { op, expr: operand } => {
            let (ty, instruction) = match op {
                UnaryOp::Negate => (Type::Number, Instruction::F64Neg),
                UnaryOp::Not => (Type::Bool, Instruction::I32Eqz),
            };

            expect_result(function, eager_result(ty, &[operand]), expr.ty, span)?;
            expect_operand(function, ty, operand.ty, span)?;

            let flow = if representation == Representation::I32 {
                body.instruction(&Instruction::I32Const(0));
                let flow = body.emit_expr_as(operand, span, Representation::I32)?;
                body.instruction(&Instruction::I32Sub);
                flow
            } else {
                let flow = body.emit_expr(operand, span)?;
                body.instruction(&instruction);
                flow
            };

            (flow, result(flow, ty))
        }

        TypedExprKind::Binary { left, op, right } => {
            let logical = matches!(op, BinaryOp::And | BinaryOp::Or);

            let (operand_type, result_type) = match op {
                BinaryOp::Add
                | BinaryOp::Subtract
                | BinaryOp::Multiply
                | BinaryOp::Divide
                | BinaryOp::Remainder => (Type::Number, Type::Number),
                BinaryOp::LessThan
                | BinaryOp::LessThanOrEqual
                | BinaryOp::GreaterThan
                | BinaryOp::GreaterThanOrEqual => (Type::Number, Type::Bool),
                BinaryOp::And | BinaryOp::Or => (Type::Bool, Type::Bool),
                BinaryOp::In => (Type::Number, Type::Bool),
                BinaryOp::Equal | BinaryOp::NotEqual => {
                    let ty = left
                        .ty
                        .value_type()
                        .or_else(|| right.ty.value_type())
                        .unwrap_or(Type::Number);
                    (ty, Type::Bool)
                }
            };

            if matches!(op, BinaryOp::Equal | BinaryOp::NotEqual) && operand_type == Type::Range {
                return Err(CodegenError::UnsupportedOperator {
                    function: function.into(),
                    operator: if *op == BinaryOp::Equal { "==" } else { "!=" },
                    span,
                });
            }

            let predicted = if logical {
                eager_result(result_type, &[left])
            } else {
                eager_result(result_type, &[left, right])
            };

            expect_result(function, predicted, expr.ty, span)?;
            // Void is not an equality operand, even when its peer is Never.
            if matches!(op, BinaryOp::Equal | BinaryOp::NotEqual) && left.ty == ExprResult::Void {
                expect_operand(function, Type::Number, left.ty, span)?;
            }
            expect_operand(function, operand_type, left.ty, span)?;
            expect_operand(
                function,
                if *op == BinaryOp::In {
                    Type::Range
                } else {
                    operand_type
                },
                right.ty,
                span,
            )?;

            // Comparison results are bool, independent of the numeric operand
            // representation. Never widen the resulting boolean as a number.
            let operands = if operand_type == Type::Number
                && matches!(
                    op,
                    BinaryOp::LessThan
                        | BinaryOp::LessThanOrEqual
                        | BinaryOp::GreaterThan
                        | BinaryOp::GreaterThanOrEqual
                        | BinaryOp::Equal
                        | BinaryOp::NotEqual
                )
                && body.numeric_representation(left) == Representation::I32
                && body.numeric_representation(right) == Representation::I32
            {
                Representation::I32
            } else {
                representation
            };
            let left_flow = body.emit_expr_as(left, span, operands)?;
            let flow = if logical {
                emit_logical(op, right, left_flow, body, span)?
            } else {
                let normalize = matches!(op, BinaryOp::Equal | BinaryOp::NotEqual)
                    && operand_type == Type::Bool;
                if normalize {
                    body.normalize_bool();
                }
                let right_flow = body.emit_expr_as(right, span, operands)?;
                if normalize {
                    body.normalize_bool();
                }
                if operands == Representation::I32 {
                    body.instruction(&match op {
                        BinaryOp::Add => Instruction::I32Add,
                        BinaryOp::Subtract => Instruction::I32Sub,
                        BinaryOp::LessThan => Instruction::I32LtS,
                        BinaryOp::LessThanOrEqual => Instruction::I32LeS,
                        BinaryOp::GreaterThan => Instruction::I32GtS,
                        BinaryOp::GreaterThanOrEqual => Instruction::I32GeS,
                        BinaryOp::Equal => Instruction::I32Eq,
                        BinaryOp::NotEqual => Instruction::I32Ne,
                        _ => {
                            unreachable!("only proven arithmetic/comparisons use integer operands")
                        }
                    });
                } else if *op == BinaryOp::In {
                    body.call(body.range_helper(range::Helper::Contains));
                } else if matches!(operand_type, Type::String | Type::Array(_)) {
                    body.call(body.helper(if operand_type == Type::String {
                        Helper::StringEqual
                    } else {
                        let Type::Array(element) = operand_type else {
                            unreachable!()
                        };
                        super::array::equality(element)
                    }));
                    if *op == BinaryOp::NotEqual {
                        body.instruction(&Instruction::I32Eqz);
                    }
                } else {
                    let instruction =
                        binary_instruction(op, operand_type, body).map_err(|operator| {
                            CodegenError::UnsupportedOperator {
                                function: function.into(),
                                operator,
                                span,
                            }
                        })?;
                    body.instruction(&instruction);
                }
                left_flow.then(right_flow)
            };
            (flow, result(flow, result_type))
        }

        TypedExprKind::Call { func, args, .. } => {
            let (flow, ty) = call::emit(*func, args, expr.ty, body, span)?;
            (flow, result(flow, ty))
        }

        TypedExprKind::NormalizedCall(sequence) => call::emit_normalized(sequence, body, span)?,

        TypedExprKind::LexicalCall {
            callable,
            args,
            span: call_span,
        } => {
            let (flow, ty) = call::emit_lexical(*callable, args, expr.ty, body, *call_span)?;
            (flow, result(flow, ty))
        }

        TypedExprKind::String(value) => {
            expect_result(function, Type::String.into(), expr.ty, span)?;
            body.instruction(&Instruction::I32Const(body.string(value) as i32));
            (Flow::FALLTHROUGH, Type::String.into())
        }

        TypedExprKind::Array(elements, element_type) => {
            let predicted = if elements
                .iter()
                .any(|element| element.ty == ExprResult::Never)
            {
                ExprResult::Never
            } else {
                Type::Array(*element_type).into()
            };

            expect_result(function, predicted, expr.ty, span)?;
            let flow = values::emit_array(expr, body, span)?;
            (flow, result(flow, Type::Array(*element_type)))
        }

        TypedExprKind::Range {
            start,
            end,
            step,
            inclusive,
        } => {
            let predicted = if [Some(start.as_ref()), Some(end.as_ref()), step.as_deref()]
                .into_iter()
                .flatten()
                .any(|operand| operand.ty == ExprResult::Never)
            {
                ExprResult::Never
            } else {
                Type::Range.into()
            };
            expect_result(function, predicted, expr.ty, span)?;
            let flow =
                range::emit_construction(start, end, step.as_deref(), *inclusive, body, span)?;
            (flow, result(flow, Type::Range))
        }

        TypedExprKind::Reserve {
            receiver,
            additional,
        } => {
            if !matches!(
                receiver.kind,
                TypedExprKind::Identifier { .. } | TypedExprKind::Captured { .. }
            ) {
                return Err(CodegenError::InvalidAssignmentTarget {
                    function: function.into(),
                    span,
                });
            }
            let element = super::array::element(receiver);
            expect_operand(function, Type::Array(element), receiver.ty, span)?;
            expect_operand(function, Type::Number, additional.ty, span)?;
            expect_result(
                function,
                eager_result(Type::Void, &[receiver, additional]),
                expr.ty,
                span,
            )?;
            let captured = body.temporary(ValType::I32);
            let receiver_flow = body.emit_expr(receiver, span)?;
            body.local_set(captured);
            body.local_get(captured);
            body.call(
                body.movable_arrays()
                    .expect("reserve planned")
                    .validate(element),
            );
            body.instruction(&Instruction::Drop);
            body.local_get(captured);
            let flow = receiver_flow.then(body.emit_expr(additional, span)?);
            body.call(
                body.movable_arrays()
                    .expect("reserve planned")
                    .reserve(element),
            );
            (flow, result(flow, Type::Void))
        }

        TypedExprKind::Push { receiver, item } => {
            if !matches!(
                receiver.kind,
                TypedExprKind::Identifier { .. } | TypedExprKind::Captured { .. }
            ) {
                return Err(CodegenError::InvalidAssignmentTarget {
                    function: function.into(),
                    span,
                });
            }
            let element = super::array::element(receiver);
            expect_operand(function, Type::Array(element), receiver.ty, span)?;
            expect_operand(function, element.value_type(), item.ty, span)?;
            expect_result(
                function,
                eager_result(Type::Void, &[receiver, item]),
                expr.ty,
                span,
            )?;
            let captured = body.temporary(ValType::I32);
            let receiver_flow = body.emit_expr(receiver, span)?;
            body.local_set(captured);
            body.local_get(captured);
            body.call(
                body.movable_arrays()
                    .expect("push planned")
                    .validate(element),
            );
            body.instruction(&Instruction::Drop);
            body.local_get(captured);
            let flow = receiver_flow.then(body.emit_expr(item, span)?);
            body.call(body.movable_arrays().expect("push planned").push(element));
            (flow, result(flow, Type::Void))
        }

        TypedExprKind::Pop { receiver } | TypedExprKind::Remove { receiver, .. } => {
            if !matches!(
                receiver.kind,
                TypedExprKind::Identifier { .. } | TypedExprKind::Captured { .. }
            ) {
                return Err(CodegenError::InvalidAssignmentTarget {
                    function: function.into(),
                    span,
                });
            }
            let element = super::array::element(receiver);
            expect_operand(function, Type::Array(element), receiver.ty, span)?;
            let index = match &expr.kind {
                TypedExprKind::Remove { index, .. } => Some(index.as_ref()),
                _ => None,
            };
            if let Some(index) = index {
                expect_operand(function, Type::Number, index.ty, span)?;
            }
            let predicted = if receiver.ty == ExprResult::Never
                || index.is_some_and(|index| index.ty == ExprResult::Never)
            {
                ExprResult::Never
            } else {
                element.value_type().into()
            };
            expect_result(function, predicted, expr.ty, span)?;
            let captured = body.temporary(ValType::I32);
            let mut flow = body.emit_expr(receiver, span)?;
            body.local_set(captured);
            body.local_get(captured);
            body.call(
                body.movable_arrays()
                    .expect("pop/remove planned")
                    .validate(element),
            );
            body.instruction(&Instruction::Drop);
            body.local_get(captured);
            let helper = if let Some(index) = index {
                flow = flow.then(body.emit_expr(index, span)?);
                body.movable_arrays()
                    .expect("remove planned")
                    .remove(element)
            } else {
                body.movable_arrays().expect("pop planned").pop(element)
            };
            body.call(helper);
            (flow, result(flow, element.value_type()))
        }

        TypedExprKind::Index { expr: base, index } => {
            values::expect_index_types(base, index, expr.ty, body, span)?;
            let flow = values::emit_address(base, index, body, span)?;
            let element = super::array::element(base);
            body.instruction(&super::array::load(element, 0));
            super::array::consume(element, body);
            (flow, result(flow, element.value_type()))
        }

        TypedExprKind::Loop { id, body: block } => {
            control_flow::emit_loop(*id, block, LoopKind::Value(expr.ty), body, span)?
        }

        TypedExprKind::Match { scrutinee, arms } => {
            match_::emit(scrutinee, arms, Some(expr.ty), body, span)?
        }

        TypedExprKind::Block(block) => emit_value_block(block, expr.ty, body)?,
        TypedExprKind::If { cond, then, else_ } => {
            expect_operand(function, Type::Bool, cond.ty, span)?;
            let cond_flow = body.emit_expr(cond, span)?;
            body.begin_if(block_type(expr.ty))?;
            let (then_flow, then_result) = emit_value_contents(then, body)?;
            if !cond_flow.can_fall_through() {
                body.instruction(&Instruction::Unreachable);
            }
            let (else_flow, else_result) = if let Some(block) = else_ {
                body.otherwise();
                let outcome = emit_value_contents(block, body)?;
                if !cond_flow.can_fall_through() {
                    body.instruction(&Instruction::Unreachable);
                }
                outcome
            } else {
                (Flow::FALLTHROUGH, ExprResult::Void)
            };
            // Joining is structural, even if the condition itself never completes.
            let joined = join_results(then_result, else_result, body, span, else_.is_some())?;
            let flow = cond_flow.then(then_flow.join(else_flow));
            body.end();
            let actual = if flow.can_fall_through() {
                joined
            } else {
                ExprResult::Never
            };
            (flow, actual)
        }
    };

    expect_result(function, actual, expr.ty, span)?;
    if representation == Representation::I32 && output == Representation::F64 {
        body.instruction(&Instruction::F64ConvertI32S);
    }
    if !flow.can_fall_through() {
        // End restores the enclosing Wasm stack's reachability. Reassert the
        // checked absence of a normal path, rather than inventing a result value.
        body.instruction(&Instruction::Unreachable);
    }
    Ok(flow)
}

fn emit_logical(
    op: &BinaryOp,
    right: &TypedExpr,
    left_flow: Flow,
    body: &mut BodyEmitter<'_>,
    span: Span,
) -> Result<Flow, CodegenError> {
    body.begin_if(block_type(result(left_flow, Type::Bool)))?;

    let then_flow = if *op == BinaryOp::And {
        let flow = body.emit_expr(right, span)?;
        body.normalize_bool();
        flow
    } else {
        body.instruction(&Instruction::I32Const(1));
        Flow::FALLTHROUGH
    };

    if !left_flow.can_fall_through() {
        body.instruction(&Instruction::Unreachable);
    }

    body.otherwise();

    let else_flow = if *op == BinaryOp::Or {
        let flow = body.emit_expr(right, span)?;
        body.normalize_bool();
        flow
    } else {
        body.instruction(&Instruction::I32Const(0));
        Flow::FALLTHROUGH
    };

    if !left_flow.can_fall_through() {
        body.instruction(&Instruction::Unreachable);
    }

    body.end();

    Ok(left_flow.then(then_flow.join(else_flow)))
}

fn join_results(
    then: ExprResult,
    else_: ExprResult,
    body: &BodyEmitter<'_>,
    span: Span,
    has_else: bool,
) -> Result<ExprResult, CodegenError> {
    if !has_else {
        return Err(CodegenError::MissingElse {
            function: body.name().into(),
            span,
        });
    }
    match (then, else_) {
        (ExprResult::Never, other) | (other, ExprResult::Never) => Ok(other),
        _ => {
            expect_result(body.name(), then, else_, span)?;
            Ok(then)
        }
    }
}

fn emit_value_block(
    block: &TypedValueBlock,
    annotation: ExprResult,
    body: &mut BodyEmitter<'_>,
) -> Result<(Flow, ExprResult), CodegenError> {
    body.begin_value_block(block_type(annotation))?;
    let outcome = emit_value_contents(block, body)?;
    body.end();
    Ok(outcome)
}

pub(super) fn emit_value_contents(
    block: &TypedValueBlock,
    body: &mut BodyEmitter<'_>,
) -> Result<(Flow, ExprResult), CodegenError> {
    body.scoped(|body| {
        let statements = body.emit_block(&block.statements)?;
        let (flow, actual) = if let Some(tail) = &block.tail {
            let flow = statements.then(body.emit_expr(tail, block.span)?);
            let actual = if flow.can_fall_through() {
                tail.ty
            } else {
                ExprResult::Never
            };
            (flow, actual)
        } else {
            (statements, result(statements, Type::Void))
        };
        if !flow.can_fall_through() {
            // Unreachable tails are checked/emitted, but cannot supply a region result.
            body.instruction(&Instruction::Unreachable);
        }
        Ok((flow, actual))
    })
}

fn binary_instruction(
    op: &BinaryOp,
    operand_type: Type,
    body: &BodyEmitter<'_>,
) -> Result<Instruction<'static>, &'static str> {
    match op {
        BinaryOp::Add
        | BinaryOp::Subtract
        | BinaryOp::Multiply
        | BinaryOp::Divide
        | BinaryOp::Remainder => arithmetic_instruction(op, body),
        BinaryOp::Equal => match operand_type {
            Type::Number => Ok(Instruction::F64Eq),
            Type::Bool => Ok(Instruction::I32Eq),
            _ => Err("=="),
        },
        BinaryOp::NotEqual => match operand_type {
            Type::Number => Ok(Instruction::F64Ne),
            Type::Bool => Ok(Instruction::I32Ne),
            _ => Err("!="),
        },
        BinaryOp::LessThan => Ok(Instruction::F64Lt),
        BinaryOp::LessThanOrEqual => Ok(Instruction::F64Le),
        BinaryOp::GreaterThan => Ok(Instruction::F64Gt),
        BinaryOp::GreaterThanOrEqual => Ok(Instruction::F64Ge),
        BinaryOp::In => Err("in"),
        BinaryOp::And => Err("&&"),
        BinaryOp::Or => Err("||"),
    }
}

pub(super) fn arithmetic_instruction(
    op: &BinaryOp,
    body: &BodyEmitter<'_>,
) -> Result<Instruction<'static>, &'static str> {
    match op {
        BinaryOp::Add => Ok(Instruction::F64Add),
        BinaryOp::Subtract => Ok(Instruction::F64Sub),
        BinaryOp::Multiply => Ok(Instruction::F64Mul),
        BinaryOp::Divide => Ok(Instruction::F64Div),
        BinaryOp::Remainder => Ok(Instruction::Call(body.remainder().raw())),
        BinaryOp::Equal => Err("=="),
        BinaryOp::NotEqual => Err("!="),
        BinaryOp::LessThan => Err("<"),
        BinaryOp::LessThanOrEqual => Err("<="),
        BinaryOp::GreaterThan => Err(">"),
        BinaryOp::GreaterThanOrEqual => Err(">="),
        BinaryOp::In => Err("in"),
        BinaryOp::And => Err("&&"),
        BinaryOp::Or => Err("||"),
    }
}

fn number(literal: &str, function: &str, span: Span) -> Result<f64, CodegenError> {
    crate::number_literal::parse(literal).map_err(|error| match error {
        crate::number_literal::LiteralError::Invalid => CodegenError::InvalidNumberLiteral {
            function: function.into(),
            literal: literal.into(),
            span,
        },
        crate::number_literal::LiteralError::OutOfRange => CodegenError::NumberLiteralOutOfRange {
            function: function.into(),
            literal: literal.into(),
            span,
        },
    })
}
