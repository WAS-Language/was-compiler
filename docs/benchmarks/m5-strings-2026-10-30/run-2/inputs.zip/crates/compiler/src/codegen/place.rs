use crate::{
    ast::{BinaryOp, Type},
    flow::Flow,
    tokens::Span,
    typed_ast::{TypedExpr, TypedExprKind},
};
use wasm_encoder::ValType;

use super::{
    CodegenError, expect_operand, expression, function::BodyEmitter, indices::LocalIndex, values,
};

enum Place<'a> {
    Local(LocalIndex),
    Cell(Type),
    Element {
        base: &'a TypedExpr,
        index: &'a TypedExpr,
    },
}

impl<'a> Place<'a> {
    fn check(
        target: &'a TypedExpr,
        body: &mut BodyEmitter<'_>,
        span: Span,
    ) -> Result<Self, CodegenError> {
        match &target.kind {
            TypedExprKind::Identifier { id, .. } => {
                let index = body.resolve_expr(*id, target.ty, span)?;
                body.check_writable(*id, span)?;

                if let Some(ty) = body.cell_address(target, span)? {
                    return Ok(Self::Cell(ty));
                }
                Ok(Self::Local(index))
            }

            TypedExprKind::Captured { owner, id, .. } => {
                body.check_capture_writable(*owner, *id, span)?;
                let ty = body
                    .cell_address(target, span)?
                    .ok_or_else(|| invalid_target(body, span))?;
                Ok(Self::Cell(ty))
            }

            TypedExprKind::Index { expr: base, index } => {
                if !matches!(
                    base.kind,
                    TypedExprKind::Identifier { .. } | TypedExprKind::Captured { .. }
                ) {
                    return Err(invalid_target(body, span));
                }

                values::expect_index_types(base, index, target.ty, body, span)?;
                if let TypedExprKind::Identifier { id, .. } = &base.kind {
                    body.resolve_expr(*id, base.ty, span)?;
                }

                Ok(Self::Element { base, index })
            }

            _ => Err(invalid_target(body, span)),
        }
    }

    fn store(&self, body: &mut BodyEmitter<'_>) {
        match self {
            Self::Local(index) => body.local_set(*index),
            Self::Cell(ty) => body.store_cell(*ty),
            Self::Element { base, .. } => {
                let element = super::array::element(base);
                super::array::consume(element, body);
                body.instruction(&super::array::store(element, 0));
            }
        }
    }
}

pub(super) fn emit_assignment(
    target: &TypedExpr,
    value: &TypedExpr,
    body: &mut BodyEmitter<'_>,
    span: Span,
) -> Result<Flow, CodegenError> {
    let place = Place::check(target, body, span)?;
    let ty = match &place {
        Place::Cell(ty) => *ty,
        Place::Local(_) => target
            .ty
            .value_type()
            .expect("checked local has a storage type"),
        Place::Element { base, .. } => super::array::element(base).value_type(),
    };
    expect_operand(body.name(), ty, value.ty, span)?;

    if let Place::Element { base, index } = &place
        && body.movable_arrays().is_some()
    {
        let pending = PendingElement::plan(body, super::array::element(base));
        let flow = pending.capture(base, index, body, span)?;
        let flow = flow.then(body.emit_expr(value, span)?);
        body.local_set(pending.value);
        pending.address(body)?;
        body.local_get(pending.value);
        place.store(body);
        return Ok(flow);
    }

    let target_flow = if let Place::Element { base, index } = &place {
        values::emit_address(base, index, body, span)?
    } else {
        Flow::FALLTHROUGH
    };

    let flow = target_flow.then(body.emit_expr(value, span)?);
    place.store(body);

    Ok(flow)
}

pub(super) fn emit_compound_assignment(
    target: &TypedExpr,
    op: &BinaryOp,
    value: &TypedExpr,
    body: &mut BodyEmitter<'_>,
    span: Span,
) -> Result<Flow, CodegenError> {
    let instruction = expression::arithmetic_instruction(op, body).map_err(|operator| {
        CodegenError::UnsupportedOperator {
            function: body.name().into(),
            operator,
            span,
        }
    })?;
    let place = Place::check(target, body, span)?;

    if let Place::Element { base, .. } = &place {
        expect_operand(
            body.name(),
            Type::Number,
            super::array::element(base).value_type().into(),
            span,
        )?;
    }
    expect_operand(body.name(), Type::Number, target.ty, span)?;
    expect_operand(body.name(), Type::Number, value.ty, span)?;

    if let Place::Element { base, index } = &place
        && body.movable_arrays().is_some()
    {
        // Keep the legacy address/old-value prefix in preorder, adding pending
        // state only in modules that can contain movable objects.
        let address = body.temporary(ValType::I32);
        let old = body.temporary(ValType::F64);
        let pending = PendingElement::with_address(body, super::array::element(base), address);
        let flow = pending.capture(base, index, body, span)?;
        body.local_get(address);
        body.instruction(&super::array::load(crate::ast::ArrayElementType::Number, 0));
        body.local_set(old);
        body.local_get(old);
        let flow = flow.then(body.emit_expr(value, span)?);
        body.instruction(&instruction);
        body.local_set(pending.value);
        pending.address(body)?;
        body.local_get(pending.value);
        place.store(body);
        return Ok(flow);
    }

    let target_flow = match &place {
        Place::Cell(ty) => {
            // Place checking left the original cell address on the stack. Load
            // through a second address before RHS effects, retaining i32/f64
            // stack prefixes without adding scratch locals to ordinary places.
            body.cell_address(target, span)?;
            body.load_cell(*ty);
            Flow::FALLTHROUGH
        }
        Place::Local(index) => {
            // Calls and nested expressions preserve this live f64 stack prefix.
            // No scratch local is needed to retain the pre-RHS value.
            body.local_get(*index);
            Flow::FALLTHROUGH
        }

        Place::Element { base, index } => {
            let address = body.temporary(ValType::I32);
            let old_value = body.temporary(ValType::F64);

            let flow = values::emit_address(base, index, body, span)?;
            body.local_set(address);
            body.local_get(address);
            body.instruction(&super::array::load(crate::ast::ArrayElementType::Number, 0));
            body.local_set(old_value);

            // Save the checked original address and old value before RHS effects,
            // including aliased element mutation and possible memory growth.
            body.local_get(address);
            body.local_get(old_value);
            flow
        }
    };

    let flow = target_flow.then(body.emit_expr(value, span)?);
    body.instruction(&instruction);
    place.store(body);

    Ok(flow)
}

struct PendingElement {
    element: crate::ast::ArrayElementType,
    saved_address: LocalIndex,
    handle: LocalIndex,
    index: LocalIndex,
    movable: LocalIndex,
    value: LocalIndex,
}

impl PendingElement {
    fn plan(body: &BodyEmitter<'_>, element: crate::ast::ArrayElementType) -> Self {
        let address = body.temporary(ValType::I32);
        Self::with_address(body, element, address)
    }

    fn with_address(
        body: &BodyEmitter<'_>,
        element: crate::ast::ArrayElementType,
        saved_address: LocalIndex,
    ) -> Self {
        Self {
            element,
            saved_address,
            handle: body.temporary(ValType::I32),
            index: body.temporary(ValType::F64),
            movable: body.temporary(ValType::I32),
            value: body.temporary(match element {
                crate::ast::ArrayElementType::Number => ValType::F64,
                crate::ast::ArrayElementType::Bool | crate::ast::ArrayElementType::String => {
                    ValType::I32
                }
            }),
        }
    }

    fn capture(
        &self,
        base: &TypedExpr,
        index: &TypedExpr,
        body: &mut BodyEmitter<'_>,
        span: Span,
    ) -> Result<Flow, CodegenError> {
        let flow = body.emit_expr(base, span)?;
        body.local_set(self.handle);
        body.local_get(self.handle);
        let flow = flow.then(body.emit_expr(index, span)?);
        body.local_set(self.index);
        body.local_get(self.index);
        body.call(body.helper(super::array::address(self.element)));
        body.local_set(self.saved_address);
        body.local_get(self.handle);
        body.call(
            body.movable_arrays()
                .expect("M4 pending place")
                .lookup(self.element),
        );
        body.local_set(self.movable);
        Ok(flow)
    }

    fn address(&self, body: &mut BodyEmitter<'_>) -> Result<(), CodegenError> {
        body.local_get(self.movable);
        body.begin_if(wasm_encoder::BlockType::Result(ValType::I32))?;
        body.local_get(self.handle);
        body.call(
            body.movable_arrays()
                .expect("M4 pending place")
                .validate(self.element),
        );
        body.instruction(&wasm_encoder::Instruction::Drop);
        body.local_get(self.handle);
        body.local_get(self.index);
        body.call(body.helper(super::array::address(self.element)));
        body.otherwise();
        body.local_get(self.saved_address);
        body.end();
        Ok(())
    }
}

fn invalid_target(body: &BodyEmitter<'_>, span: Span) -> CodegenError {
    CodegenError::InvalidAssignmentTarget {
        function: body.name().into(),
        span,
    }
}
