use std::collections::{HashMap, hash_map::Entry};

use thiserror::Error;

use crate::{
    ast::{
        BinaryOp, Block, CallArgument, Expr, Function, Lambda, LambdaBody, MatchArm, PipelineStage,
        PipelineStageTarget, Program, Statement, StatementKind, Type, UnaryOp, ValueBlock,
    },
    flow::Flow,
    host::HostFunctions,
    tokens::Span,
    typed_ast::{
        BindingOwner, BuiltinFunction, CallBindingOrigin, CallableId, CaptureMutability,
        ExprResult, FunctionId, FunctionRef, LoopId, TypedBlock, TypedCallBinding, TypedCapture,
        TypedClosure, TypedClosureBody, TypedContract, TypedExpr, TypedExprKind, TypedFunction,
        TypedMatchArm, TypedNormalizedCall, TypedParam, TypedProgram, TypedStatement,
        TypedStatementKind, TypedValueBlock, VariableId,
    },
};

mod call_binding;
mod closures;
use closures::{BindingUse, LexicalBinding};
mod defaults;
mod inference;
mod placeholders;
mod pure_expression;

#[derive(Debug, Error, PartialEq)]
pub enum SemanticError {
    #[error("Placeholder is outside a placeholder region at {span:?}")]
    InvalidPlaceholder { span: Span },

    #[error("Callable values are not supported at {span:?}")]
    InvalidCallableValueUse { span: Span },

    #[error("Cannot infer a concrete type for placeholder parameter at {span:?}")]
    CannotInferPlaceholderParameter { span: Span },

    #[error(
        "Conflicting placeholder constraints: expected {expected:?}, found {found:?} at {span:?}"
    )]
    ConflictingPlaceholderConstraints {
        expected: Type,
        found: Type,
        span: Span,
    },

    #[error("invalid closure: {reason}")]
    InvalidClosure { reason: &'static str, span: Span },

    #[error("cannot infer a concrete closure result")]
    CannotInferClosureResult { span: Span },
    #[error("Invalid pipeline: {message} at {span:?}")]
    InvalidPipeline { message: &'static str, span: Span },

    #[error("Invalid match: {message} at {span:?}")]
    InvalidMatch { message: &'static str, span: Span },

    #[error("Recursive function '{name}' requires an explicit result annotation at {span:?}")]
    RecursiveResultAnnotationRequired { name: String, span: Span },

    #[error(
        "Cannot infer result of '{name}': callee '{callee}' has an unresolved result at {span:?}"
    )]
    UnresolvedResultDependency {
        name: String,
        callee: String,
        span: Span,
    },

    #[error("Function '{name}' requires an explicit result annotation at {span:?}")]
    CannotInferFunctionResult { name: String, span: Span },

    #[error("Incompatible inferred returns: expected {expected:?}, found {found:?} at {span:?}")]
    IncompatibleInferredReturns {
        expected: Type,
        found: Type,
        span: Span,
    },

    #[error("Function '{name}' is already declared at {span:?}")]
    DuplicateFunction { name: String, span: Span },

    #[error("Variable '{name}' is already declared in this scope at {span:?}")]
    DuplicateVariable { name: String, span: Span },

    #[error("Variable '{name}' is read-only at {span:?}")]
    ReadOnlyVariable { name: String, span: Span },

    #[error("Undefined variable '{name}' at {span:?}")]
    UndefinedVariable { name: String, span: Span },

    #[error("Undefined function '{name}' at {span:?}")]
    UndefinedFunction { name: String, span: Span },

    #[error("Variable '{name}' cannot be called as a function at {span:?}")]
    NotCallable { name: String, span: Span },

    #[error("'{name}' cannot have type void at {span:?}")]
    InvalidVoidType { name: String, span: Span },

    #[error("An if expression requires an else branch at {span:?}")]
    MissingElse { span: Span },

    #[error("Cannot infer a concrete type for divergent initializer '{name}' at {span:?}")]
    CannotInferNeverType { name: String, span: Span },

    #[error("Type mismatch: expected {expected:?}, found {found:?} at {span:?}")]
    TypeMismatch {
        expected: Type,
        found: Type,
        span: Span,
    },

    #[error("Function '{name}' expects {expected} arguments, found {found} at {span:?}")]
    ArgumentCountMismatch {
        name: String,
        expected: usize,
        found: usize,
        span: Span,
    },

    #[error("Named arguments are not supported for '{name}' at {span:?}")]
    NamedArgumentsNotSupported { name: String, span: Span },

    #[error("Unknown argument '{argument}' for function '{name}' at {span:?}")]
    UnknownArgument {
        name: String,
        argument: String,
        span: Span,
    },

    #[error("Argument '{argument}' is supplied more than once to '{name}' at {span:?}")]
    DuplicateArgument {
        name: String,
        argument: String,
        span: Span,
    },

    #[error("Too many positional arguments for '{name}' at {span:?}")]
    TooManyPositionalArguments { name: String, span: Span },

    #[error("Positional argument follows a named argument for '{name}' at {span:?}")]
    PositionalAfterNamed { name: String, span: Span },

    #[error("Missing required argument '{argument}' for '{name}' at {span:?}")]
    MissingArgument {
        name: String,
        argument: String,
        span: Span,
    },

    #[error("Required parameter '{name}' follows a default parameter at {span:?}")]
    NonTrailingDefault { name: String, span: Span },

    #[error("Invalid default expression: {reason} at {span:?}")]
    InvalidDefaultExpression { reason: &'static str, span: Span },

    #[error("Invalid number literal '{literal}' in default expression at {span:?}")]
    InvalidDefaultNumberLiteral { literal: String, span: Span },

    #[error(
        "Number literal '{literal}' in default expression is outside the finite f64 range at {span:?}"
    )]
    DefaultNumberLiteralOutOfRange { literal: String, span: Span },

    #[error("Invalid contract expression: {reason} at {span:?}")]
    InvalidContractExpression { reason: &'static str, span: Span },

    #[error("Invalid number literal '{literal}' in contract expression at {span:?}")]
    InvalidContractNumberLiteral { literal: String, span: Span },

    #[error(
        "Number literal '{literal}' in contract expression is outside the finite f64 range at {span:?}"
    )]
    ContractNumberLiteralOutOfRange { literal: String, span: Span },

    #[error("Operator '{operator}' cannot be applied to {left:?} and {right:?} at {span:?}")]
    InvalidBinaryOperands {
        operator: &'static str,
        left: Type,
        right: Type,
        span: Span,
    },

    #[error("Assignment target must be a variable or array element at {span:?}")]
    InvalidAssignmentTarget { span: Span },

    #[error("Compound assignment requires an arithmetic operator, found {op:?} at {span:?}")]
    InvalidCompoundAssignmentOperator { op: BinaryOp, span: Span },

    #[error("Break is only allowed inside a loop at {span:?}")]
    BreakOutsideLoop { span: Span },

    #[error("A break value is not allowed in a statement loop at {span:?}")]
    BreakValueNotAllowed { span: Span },

    #[error("A value loop requires a break value at {span:?}")]
    MissingBreakValue { span: Span },

    #[error("A break value cannot have type void at {span:?}")]
    InvalidBreakValue { span: Span },

    #[error("Continue is only allowed inside a loop at {span:?}")]
    ContinueOutsideLoop { span: Span },

    #[error("A void function cannot return a value at {span:?}")]
    UnexpectedReturnValue { span: Span },

    #[error("Function '{name}' does not return a value on every path at {span:?}")]
    MissingReturn { name: String, span: Span },
}

impl SemanticError {
    pub fn span(&self) -> Option<Span> {
        match self {
            Self::InvalidPlaceholder { span }
            | Self::InvalidCallableValueUse { span }
            | Self::CannotInferPlaceholderParameter { span }
            | Self::ConflictingPlaceholderConstraints { span, .. }
            | Self::InvalidClosure { span, .. }
            | Self::CannotInferClosureResult { span }
            | Self::InvalidPipeline { span, .. }
            | Self::InvalidMatch { span, .. }
            | Self::RecursiveResultAnnotationRequired { span, .. }
            | Self::UnresolvedResultDependency { span, .. }
            | Self::CannotInferFunctionResult { span, .. }
            | Self::IncompatibleInferredReturns { span, .. }
            | Self::DuplicateFunction { span, .. }
            | Self::DuplicateVariable { span, .. }
            | Self::ReadOnlyVariable { span, .. }
            | Self::UndefinedVariable { span, .. }
            | Self::UndefinedFunction { span, .. }
            | Self::NotCallable { span, .. }
            | Self::InvalidVoidType { span, .. }
            | Self::MissingElse { span }
            | Self::CannotInferNeverType { span, .. }
            | Self::TypeMismatch { span, .. }
            | Self::ArgumentCountMismatch { span, .. }
            | Self::NamedArgumentsNotSupported { span, .. }
            | Self::UnknownArgument { span, .. }
            | Self::DuplicateArgument { span, .. }
            | Self::TooManyPositionalArguments { span, .. }
            | Self::PositionalAfterNamed { span, .. }
            | Self::MissingArgument { span, .. }
            | Self::NonTrailingDefault { span, .. }
            | Self::InvalidDefaultExpression { span, .. }
            | Self::InvalidDefaultNumberLiteral { span, .. }
            | Self::DefaultNumberLiteralOutOfRange { span, .. }
            | Self::InvalidContractExpression { span, .. }
            | Self::InvalidContractNumberLiteral { span, .. }
            | Self::ContractNumberLiteralOutOfRange { span, .. }
            | Self::InvalidBinaryOperands { span, .. }
            | Self::InvalidAssignmentTarget { span }
            | Self::InvalidCompoundAssignmentOperator { span, .. }
            | Self::BreakOutsideLoop { span }
            | Self::BreakValueNotAllowed { span }
            | Self::MissingBreakValue { span }
            | Self::InvalidBreakValue { span }
            | Self::ContinueOutsideLoop { span }
            | Self::UnexpectedReturnValue { span }
            | Self::MissingReturn { span, .. } => Some(*span),
        }
    }
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum ReturnContext {
    Known(Type),
    Infer,
}

struct FunctionSignature {
    reference: FunctionRef,
    params: Vec<Type>,
    param_names: Vec<String>,
    defaults: Vec<Option<defaults::CheckedDefault>>,
    contracts: Vec<TypedContract>,
    return_type: Type,
}

#[derive(Clone, Copy)]
struct VariableBinding {
    owner: Option<BindingOwner>,
    id: VariableId,
    ty: Type,
    mutability: BindingMutability,
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum BindingMutability {
    Mutable,
    ReadOnly,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum MatchContext {
    Statement,
    Value(ExprContext),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ExprContext {
    Expected(Type),
    Value,
    Discard,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum LoopKind {
    Statement,
    Value,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct LoopContext {
    id: LoopId,
    kind: LoopKind,
    expected: Option<Type>,
}

#[derive(Default)]
pub struct SemanticAnalyzer {
    host_functions: HostFunctions,
    functions: HashMap<String, FunctionSignature>,
    scopes: Vec<HashMap<String, LexicalBinding>>,
    owner: Option<BindingOwner>,
    callable_ids: HashMap<usize, CallableId>,
    closure_results: HashMap<usize, Type>,
    dependencies: Vec<(CallableId, Vec<CallableId>)>,
    capture_contexts: Vec<closures::CaptureContext>,
    placeholder_bindings: Vec<HashMap<usize, VariableBinding>>,
    next_variable_id: usize,
    loops: Vec<LoopContext>,
    next_loop_id: usize,
    result_expected: Option<Type>,
}

impl SemanticAnalyzer {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn with_host_functions(host_functions: &HostFunctions) -> Self {
        Self {
            host_functions: host_functions.clone(),
            ..Self::default()
        }
    }

    pub fn analyze(&mut self, program: &Program) -> Result<TypedProgram, SemanticError> {
        // Addresses identify borrowed raw nodes only during this analysis. Their
        // assigned IDs come from source traversal, never address or inference order.
        self.callable_ids = inference::discover_callables(program)
            .into_iter()
            .enumerate()
            .map(|(index, identity)| (identity, CallableId(index)))
            .collect();
        self.closure_results.clear();
        self.dependencies.clear();
        self.capture_contexts.clear();
        self.placeholder_bindings.clear();
        self.functions.clear();
        self.scopes.clear();
        self.next_variable_id = 0;
        self.loops.clear();
        self.next_loop_id = 0;

        self.functions.insert(
            "len".into(),
            FunctionSignature {
                reference: FunctionRef::Builtin(BuiltinFunction::Len),
                params: vec![Type::Array(crate::ast::ArrayElementType::Number)],
                param_names: vec![],
                defaults: vec![],
                contracts: vec![],
                return_type: Type::Number,
            },
        );

        self.functions.insert(
            "resizable".into(),
            FunctionSignature {
                reference: FunctionRef::Builtin(BuiltinFunction::Resizable),
                params: vec![Type::Array(crate::ast::ArrayElementType::Number)],
                param_names: vec![],
                defaults: vec![],
                contracts: vec![],
                return_type: Type::Array(crate::ast::ArrayElementType::Number),
            },
        );

        for (name, builtin, params, return_type) in [
            (
                "string_byte_len",
                BuiltinFunction::StringByteLen,
                vec![Type::String],
                Type::Number,
            ),
            (
                "string_concat",
                BuiltinFunction::StringConcat,
                vec![Type::String, Type::String],
                Type::String,
            ),
            (
                "string_slice_bytes",
                BuiltinFunction::StringSliceBytes,
                vec![Type::String, Type::Number, Type::Number],
                Type::String,
            ),
            (
                "string_replace_all",
                BuiltinFunction::StringReplaceAll,
                vec![Type::String, Type::String, Type::String],
                Type::String,
            ),
            (
                "string_join",
                BuiltinFunction::StringJoin,
                vec![
                    Type::Array(crate::ast::ArrayElementType::String),
                    Type::String,
                ],
                Type::String,
            ),
        ] {
            self.functions.insert(
                name.into(),
                FunctionSignature {
                    reference: FunctionRef::Builtin(builtin),
                    params,
                    param_names: vec![],
                    defaults: vec![],
                    contracts: vec![],
                    return_type,
                },
            );
        }

        for function in self.host_functions.functions() {
            self.functions.insert(
                function.name.clone(),
                FunctionSignature {
                    reference: FunctionRef::Host(function.id),
                    params: function.params.clone(),
                    param_names: vec![],
                    defaults: vec![],
                    contracts: vec![],
                    return_type: function.return_type,
                },
            );
        }

        let result = self.analyze_program(program);

        self.scopes.clear();
        self.loops.clear();
        self.callable_ids.clear();
        self.closure_results.clear();
        self.dependencies.clear();
        self.capture_contexts.clear();
        self.owner = None;

        result
    }

    fn analyze_program(&mut self, program: &Program) -> Result<TypedProgram, SemanticError> {
        let staged_declarations = program.functions.iter().any(|function| {
            function.return_type.is_none()
                || !function.contracts.is_empty()
                || function.params.iter().any(|param| param.default.is_some())
        });

        for (index, function) in program.functions.iter().enumerate() {
            let signature = FunctionSignature {
                reference: FunctionRef::User(FunctionId(index)),
                params: function.params.iter().map(|param| param.ty).collect(),
                param_names: function
                    .params
                    .iter()
                    .map(|param| param.name.clone())
                    .collect(),
                defaults: (0..function.params.len()).map(|_| None).collect(),
                contracts: vec![],
                return_type: function.return_type.unwrap_or(Type::Void),
            };

            if self
                .functions
                .insert(function.name.clone(), signature)
                .is_some()
            {
                return Err(SemanticError::DuplicateFunction {
                    name: function.name.clone(),
                    span: function.span,
                });
            }

            if staged_declarations {
                self.validate_declaration_expressions(function)?;
            } else {
                for param in &function.params {
                    self.check_variable_type(&param.name, param.ty, param.span)?;
                }
            }
        }

        self.infer_results(program)?;

        let mut functions = Vec::with_capacity(program.functions.len());

        for (index, function) in program.functions.iter().enumerate() {
            functions.push(self.analyze_function(function, FunctionId(index))?);
        }

        Ok(TypedProgram {
            host_functions: self.host_functions.functions().to_vec(),
            functions,
        })
    }

    fn analyze_function(
        &mut self,
        function: &Function,
        id: FunctionId,
    ) -> Result<TypedFunction, SemanticError> {
        let mut typed = self.analyze_function_with_context(
            function,
            id,
            ReturnContext::Known(self.functions[&function.name].return_type),
        )?;
        typed.contracts = std::mem::take(
            &mut self
                .functions
                .get_mut(&function.name)
                .expect("final body analysis has a declared signature")
                .contracts,
        );

        Ok(typed)
    }

    fn infer_result(&mut self, function: &Function, id: FunctionId) -> Result<Type, SemanticError> {
        self.analyze_function_with_context(function, id, ReturnContext::Infer)
            .map(|function| function.return_type)
    }

    fn analyze_function_with_context(
        &mut self,
        function: &Function,
        id: FunctionId,
        context: ReturnContext,
    ) -> Result<TypedFunction, SemanticError> {
        self.owner = Some(BindingOwner::Function(id));
        self.result_expected = function.return_type;
        self.next_variable_id = 0;
        self.next_loop_id = 0;
        self.loops.clear();
        self.scopes.push(HashMap::new());

        let result = self.analyze_function_body(function, id, context);

        self.scopes.pop();
        self.loops.clear();

        result
    }

    fn analyze_function_body(
        &mut self,
        function: &Function,
        id: FunctionId,
        context: ReturnContext,
    ) -> Result<TypedFunction, SemanticError> {
        let mut params = Vec::with_capacity(function.params.len());

        for param in &function.params {
            let id = self.declare_variable(
                &param.name,
                param.ty,
                BindingMutability::Mutable,
                param.span,
            )?;

            params.push(TypedParam {
                id,
                name: param.name.clone(),
                ty: param.ty,
                span: param.span,
            });
        }

        let (body, flow) = self.analyze_block(&function.body, context)?;
        let return_type = match context {
            ReturnContext::Known(ty) => ty,
            ReturnContext::Infer => {
                let ty = flow.return_type().map_err(|(expected, found)| {
                    SemanticError::IncompatibleInferredReturns {
                        expected,
                        found,
                        span: function.span,
                    }
                })?;
                if matches!(ty, None | Some(Type::Void)) && inference::has_value_return(function) {
                    return Err(SemanticError::CannotInferFunctionResult {
                        name: function.name.clone(),
                        span: function.span,
                    });
                }
                ty.unwrap_or(Type::Void)
            }
        };

        if return_type != Type::Void && !flow.returns_or_diverges() {
            return Err(SemanticError::MissingReturn {
                name: function.name.clone(),
                span: function.span,
            });
        }

        Ok(TypedFunction {
            id,
            name: function.name.clone(),
            params,
            return_type,
            contracts: vec![],
            body,
            span: function.span,
        })
    }

    fn analyze_block(
        &mut self,
        block: &Block,
        return_type: ReturnContext,
    ) -> Result<(TypedBlock, Flow), SemanticError> {
        let mut statements = Vec::with_capacity(block.len());
        let mut flow = Flow::FALLTHROUGH;

        for statement in block {
            let (statement, next) = self.analyze_statement(statement, return_type)?;

            statements.push(statement);

            flow = flow.then(next);
        }

        Ok((statements, flow))
    }

    fn analyze_scoped_block(
        &mut self,
        block: &Block,
        return_type: ReturnContext,
    ) -> Result<(TypedBlock, Flow), SemanticError> {
        self.scopes.push(HashMap::new());

        let result = self.analyze_block(block, return_type);

        self.scopes.pop();

        result
    }

    fn analyze_statement(
        &mut self,
        statement: &Statement,
        return_type: ReturnContext,
    ) -> Result<(TypedStatement, Flow), SemanticError> {
        let span = statement.span;
        let flow;

        let kind = match &statement.kind {
            StatementKind::Let {
                name,
                name_span,
                ty,
                value,
                value_span,
            } => {
                let owned_parameter = self.placeholder_bindings.last().is_some_and(|bindings| {
                    bindings.contains_key(&std::ptr::from_ref(value).addr())
                });
                let placeholder = !owned_parameter && placeholders::has_owned(value);
                if placeholder || matches!(value, Expr::Lambda(_)) {
                    if ty.is_some() {
                        return Err(SemanticError::InvalidClosure {
                            reason: "a local callable binding cannot have a value type annotation",
                            span: *name_span,
                        });
                    }
                    let params = if placeholder {
                        self.infer_placeholder_parameters(value, *value_span)?
                    } else {
                        Vec::new()
                    };
                    let (source, origin) = match value {
                        Expr::Lambda(lambda) => (
                            closures::ClosureSource::Explicit(lambda),
                            closures::CallableOrigin::Explicit,
                        ),
                        _ => (
                            closures::ClosureSource::Placeholder {
                                expression: value,
                                span: *value_span,
                                params: &params,
                            },
                            closures::CallableOrigin::Placeholder,
                        ),
                    };
                    let closure = self.analyze_closure(name, *name_span, source)?;
                    self.declare_callable(&closure, span, origin)?;
                    return Ok((
                        TypedStatement {
                            kind: TypedStatementKind::Closure(closure),
                            span,
                        },
                        Flow::FALLTHROUGH,
                    ));
                }
                if let Some(ty) = ty {
                    self.check_variable_type(name, *ty, span)?;
                }

                let (value, value_flow) = self.analyze_expected(value, span, return_type, *ty)?;

                flow = value_flow;

                let ty = match ty {
                    Some(ty) => {
                        self.expect_type(*ty, value.ty, span)?;

                        *ty
                    }

                    None => match value.ty {
                        ExprResult::Value(ty) => ty,
                        ExprResult::Void => {
                            return Err(SemanticError::InvalidVoidType {
                                name: name.clone(),
                                span,
                            });
                        }
                        ExprResult::Never => {
                            return Err(SemanticError::CannotInferNeverType {
                                name: name.clone(),
                                span,
                            });
                        }
                    },
                };

                let id = self.declare_variable(name, ty, BindingMutability::Mutable, span)?;

                TypedStatementKind::Let {
                    id,
                    name: name.clone(),
                    ty,
                    value,
                }
            }

            StatementKind::Assignment { target, value } => {
                let (target, target_flow) =
                    self.analyze_assignment_target(target, span, return_type)?;
                // A divergent index erases completion, not the destination's
                // element type; the replacement still needs exact checking.
                let target_type = match target.ty {
                    ExprResult::Value(ty) => ty,
                    ExprResult::Never => match &target.kind {
                        TypedExprKind::Index { expr, .. } => Self::array_element(expr).value_type(),
                        _ => Type::Number,
                    },
                    ExprResult::Void => unreachable!("checked places have a storage type"),
                };

                let (value, value_flow) =
                    self.analyze_expected(value, span, return_type, Some(target_type))?;
                self.expect_type(target_type, value.ty, span)?;
                flow = target_flow.then(value_flow);

                TypedStatementKind::Assignment { target, value }
            }

            StatementKind::CompoundAssignment { target, op, value } => {
                let (target, target_flow) =
                    self.analyze_assignment_target(target, span, return_type)?;

                if let TypedExprKind::Index { expr, .. } = &target.kind {
                    self.expect_type(
                        Type::Number,
                        Self::array_element(expr).value_type().into(),
                        span,
                    )?;
                }
                self.expect_type(Type::Number, target.ty, span)?;

                if !matches!(
                    op,
                    BinaryOp::Add
                        | BinaryOp::Subtract
                        | BinaryOp::Multiply
                        | BinaryOp::Divide
                        | BinaryOp::Remainder
                ) {
                    return Err(SemanticError::InvalidCompoundAssignmentOperator { op: *op, span });
                }

                let (value, value_flow) = self.analyze_expr(value, span, return_type)?;

                self.expect_type(Type::Number, value.ty, span)?;
                flow = target_flow.then(value_flow);

                TypedStatementKind::CompoundAssignment {
                    target,
                    op: *op,
                    value,
                }
            }

            StatementKind::If { cond, then, else_ } => {
                let (cond, cond_flow) = self.analyze_expr(cond, span, return_type)?;
                let cond = Box::new(cond);

                self.expect_type(Type::Bool, cond.ty, span)?;

                let (then, then_flow) = self.analyze_scoped_block(then, return_type)?;
                let (else_, else_flow) = match else_ {
                    Some(block) => {
                        let (block, flow) = self.analyze_scoped_block(block, return_type)?;

                        (Some(block), flow)
                    }

                    None => (None, Flow::FALLTHROUGH),
                };

                flow = cond_flow.then(then_flow.join(else_flow));

                TypedStatementKind::If { cond, then, else_ }
            }

            StatementKind::Match { scrutinee, arms } => {
                let (scrutinee, arms, _, match_flow) = self.analyze_match(
                    scrutinee,
                    arms,
                    span,
                    return_type,
                    MatchContext::Statement,
                )?;
                flow = match_flow;
                TypedStatementKind::Match {
                    scrutinee: Box::new(scrutinee),
                    arms,
                }
            }

            StatementKind::While { cond, body } => {
                let id = LoopId(self.next_loop_id);

                self.next_loop_id += 1;
                self.loops.push(LoopContext {
                    id,
                    kind: LoopKind::Statement,
                    expected: None,
                });

                let result = (|| {
                    let (cond, cond_flow) = self.analyze_expr(cond, span, return_type)?;

                    self.expect_type(Type::Bool, cond.ty, span)?;

                    let (body, body_flow) = self.analyze_scoped_block(body, return_type)?;

                    Ok((Box::new(cond), body, cond_flow, body_flow))
                })();

                self.loops.pop();

                let (cond, body, cond_flow, body_flow) = result?;

                flow = if cond_flow.can_fall_through() {
                    cond_flow.then(body_flow).while_loop()
                } else {
                    cond_flow.infinite_loop()
                };

                TypedStatementKind::While { id, cond, body }
            }

            StatementKind::For {
                name,
                iterable,
                body,
            } => {
                // Iterable transfers belong to the enclosing loop, and its names
                // resolve before the iteration binding exists.
                let (iterable, iterable_flow) = self.analyze_expr(iterable, span, return_type)?;

                let element_type = match iterable.array_element_type() {
                    Some(element) => {
                        self.expect_type(Type::Array(element), iterable.ty, span)?;
                        element.value_type()
                    }
                    _ => {
                        self.expect_type(Type::Range, iterable.ty, span)?;
                        Type::Number
                    }
                };
                self.scopes.push(HashMap::new());

                let result = (|| {
                    let variable = self.declare_variable(
                        name,
                        element_type,
                        BindingMutability::ReadOnly,
                        span,
                    )?;
                    let (id, body, body_flow) =
                        self.analyze_loop_body(body, return_type, LoopKind::Statement)?;

                    Ok((variable, id, body, body_flow))
                })();

                self.scopes.pop();

                let (variable, id, body, body_flow) = result?;

                flow = iterable_flow.then(body_flow.while_loop());

                TypedStatementKind::For {
                    id,
                    variable,
                    name: name.clone(),
                    element_type,
                    iterable: Box::new(iterable),
                    body,
                }
            }

            StatementKind::Loop { body } => {
                let (id, body, body_flow) =
                    self.analyze_loop_body(body, return_type, LoopKind::Statement)?;

                flow = body_flow.infinite_loop();

                TypedStatementKind::Loop { id, body }
            }

            StatementKind::Break => {
                let context = self
                    .loops
                    .last()
                    .copied()
                    .ok_or(SemanticError::BreakOutsideLoop { span })?;

                if context.kind == LoopKind::Value {
                    return Err(SemanticError::MissingBreakValue { span });
                }

                flow = Flow::BREAK;

                TypedStatementKind::Break { target: context.id }
            }

            StatementKind::BreakValue(value) => {
                let context = self
                    .loops
                    .last()
                    .copied()
                    .ok_or(SemanticError::BreakOutsideLoop { span })?;

                if context.kind == LoopKind::Statement {
                    return Err(SemanticError::BreakValueNotAllowed { span });
                }

                let (value, value_flow) =
                    self.analyze_expected(value, span, return_type, context.expected)?;

                flow = match value.ty {
                    ExprResult::Value(ty) => value_flow.then(Flow::value_break(ty)),
                    ExprResult::Never => value_flow,
                    ExprResult::Void => return Err(SemanticError::InvalidBreakValue { span }),
                };

                TypedStatementKind::BreakValue {
                    target: context.id,
                    value,
                }
            }

            StatementKind::Continue => {
                let target = self
                    .loops
                    .last()
                    .copied()
                    .ok_or(SemanticError::ContinueOutsideLoop { span })?;

                flow = Flow::CONTINUE;

                TypedStatementKind::Continue { target: target.id }
            }

            StatementKind::Return(value) => {
                if self
                    .placeholder_bindings
                    .last()
                    .is_none_or(HashMap::is_empty)
                    && let Some(value) = value
                    && let Some(span) = placeholders::first_owned_span(value)
                {
                    return Err(SemanticError::InvalidPlaceholder { span });
                }
                if let Some(Expr::Lambda(lambda)) = value {
                    return Err(SemanticError::InvalidClosure {
                        reason: "a closure must initialize a local callable binding",
                        span: lambda.span,
                    });
                }
                if let Some(Expr::Identifier(name)) = value {
                    self.check_value_binding(name, span, BindingUse::Read)?;
                }
                let value = match value {
                    Some(_) if return_type == ReturnContext::Known(Type::Void) => {
                        return Err(SemanticError::UnexpectedReturnValue { span });
                    }
                    Some(expr) => {
                        let (expr, expr_flow) =
                            self.analyze_expected(expr, span, return_type, self.result_expected)?;
                        let completion = match return_type {
                            ReturnContext::Known(ty) => {
                                self.expect_type(ty, expr.ty, span)?;
                                Flow::RETURN
                            }
                            ReturnContext::Infer => match expr.ty {
                                ExprResult::Value(ty) => Flow::return_value(ty),
                                ExprResult::Never => Flow::NONE,
                                ExprResult::Void => {
                                    return Err(SemanticError::UnexpectedReturnValue { span });
                                }
                            },
                        };
                        flow = expr_flow.then(completion);
                        Some(expr)
                    }
                    None => {
                        flow = match return_type {
                            ReturnContext::Known(ty) => {
                                self.expect_type(ty, Type::Void.into(), span)?;
                                Flow::RETURN
                            }
                            ReturnContext::Infer => Flow::return_value(Type::Void),
                        };
                        None
                    }
                };
                TypedStatementKind::Return(value)
            }

            StatementKind::Expression(expr) => {
                let (expr, expr_flow) =
                    self.analyze_expr_in_context(expr, span, return_type, ExprContext::Discard)?;

                flow = expr_flow;

                TypedStatementKind::Expression(expr)
            }
        };

        Ok((TypedStatement { kind, span }, flow))
    }

    fn analyze_loop_body(
        &mut self,
        body: &Block,
        return_type: ReturnContext,
        kind: LoopKind,
    ) -> Result<(LoopId, TypedBlock, Flow), SemanticError> {
        let id = LoopId(self.next_loop_id);

        self.next_loop_id += 1;
        self.loops.push(LoopContext {
            id,
            kind,
            expected: None,
        });

        let result = self.analyze_scoped_block(body, return_type);

        self.loops.pop();

        let (body, flow) = result?;

        Ok((id, body, flow))
    }

    fn analyze_value_loop_body(
        &mut self,
        body: &Block,
        return_type: ReturnContext,
        context: ExprContext,
    ) -> Result<(LoopId, TypedBlock, Flow), SemanticError> {
        let id = LoopId(self.next_loop_id);
        self.next_loop_id += 1;
        self.loops.push(LoopContext {
            id,
            kind: LoopKind::Value,
            expected: match context {
                ExprContext::Expected(ty) => Some(ty),
                _ => None,
            },
        });
        let result = self.analyze_scoped_block(body, return_type);
        self.loops.pop();
        let (body, flow) = result?;
        Ok((id, body, flow))
    }

    fn analyze_assignment_target(
        &mut self,
        target: &Expr,
        span: Span,
        return_type: ReturnContext,
    ) -> Result<(TypedExpr, Flow), SemanticError> {
        match target {
            Expr::Identifier(name) => {
                self.check_value_binding(name, span, BindingUse::Write)?;
                let binding =
                    self.lookup_variable(name)
                        .ok_or_else(|| SemanticError::UndefinedVariable {
                            name: name.clone(),
                            span,
                        })?;

                if binding.mutability == BindingMutability::ReadOnly {
                    return Err(SemanticError::ReadOnlyVariable {
                        name: name.clone(),
                        span,
                    });
                }

                Ok((
                    TypedExpr {
                        kind: self.binding_expression(binding, name),
                        ty: binding.ty.into(),
                    },
                    Flow::FALLTHROUGH,
                ))
            }
            Expr::Index { expr, .. } if matches!(**expr, Expr::Identifier(_)) => {
                self.analyze_expr(target, span, return_type)
            }

            _ => Err(SemanticError::InvalidAssignmentTarget { span }),
        }
    }

    fn analyze_value_block(
        &mut self,
        block: &ValueBlock,
        return_type: ReturnContext,
        context: ExprContext,
    ) -> Result<(TypedValueBlock, ExprResult, Flow), SemanticError> {
        self.scopes.push(HashMap::new());

        let result = (|| {
            let (statements, mut flow) = self.analyze_block(&block.statements, return_type)?;
            let (tail, ty) = match &block.tail {
                Some(expr) => {
                    let (expr, tail_flow) =
                        self.analyze_expr_in_context(expr, block.span, return_type, context)?;

                    flow = flow.then(tail_flow);

                    let ty = expr.ty;

                    (Some(Box::new(expr)), ty)
                }
                None => (None, ExprResult::Void),
            };
            let ty = Self::completion_result(ty, flow);

            Ok((
                TypedValueBlock {
                    statements,
                    tail,
                    span: block.span,
                },
                ty,
                flow,
            ))
        })();

        self.scopes.pop();

        result
    }

    fn completion_result(ty: ExprResult, flow: Flow) -> ExprResult {
        if flow.can_fall_through() {
            ty
        } else {
            ExprResult::Never
        }
    }

    fn join_results(
        &self,
        then: ExprResult,
        else_: ExprResult,
        span: Span,
    ) -> Result<ExprResult, SemanticError> {
        match (then, else_) {
            (ExprResult::Never, ty) | (ty, ExprResult::Never) => Ok(ty),
            (left, right) if left == right => Ok(left),
            (left, right) => {
                let expected = left.value_type().unwrap_or(Type::Void);

                self.expect_type(expected, right, span)?;

                Ok(left)
            }
        }
    }

    fn analyze_match(
        &mut self,
        scrutinee: &Expr,
        arms: &[MatchArm],
        span: Span,
        return_type: ReturnContext,
        context: MatchContext,
    ) -> Result<(TypedExpr, Vec<TypedMatchArm>, ExprResult, Flow), SemanticError> {
        let (scrutinee, scrutinee_flow) = self.analyze_expr(scrutinee, span, return_type)?;
        crate::match_patterns::check(scrutinee.ty, arms.iter().map(|arm| &arm.pattern)).map_err(
            |(message, pattern_span)| SemanticError::InvalidMatch {
                message,
                span: if pattern_span == Span::new(0, 0) {
                    span
                } else {
                    pattern_span
                },
            },
        )?;
        let mut typed_arms = Vec::with_capacity(arms.len());
        let mut result_type = ExprResult::Never;
        let mut arm_flow = Flow::NONE;

        for arm in arms {
            self.scopes.push(HashMap::new());
            let arm_context = match context {
                MatchContext::Statement => ExprContext::Discard,
                MatchContext::Value(context) => context,
            };
            let result =
                self.analyze_expr_in_context(&arm.body, arm.span, return_type, arm_context);
            self.scopes.pop();
            let (body, flow) = result?;
            if matches!(context, MatchContext::Value(_)) {
                result_type = self.join_results(result_type, body.ty, arm.span)?;
            }
            arm_flow = arm_flow.join(flow);
            typed_arms.push(TypedMatchArm {
                pattern: arm.pattern.clone(),
                body,
                span: arm.span,
            });
        }
        let flow = scrutinee_flow.then(arm_flow);
        let ty = Self::completion_result(
            if matches!(context, MatchContext::Value(_)) {
                result_type
            } else {
                ExprResult::Void
            },
            flow,
        );
        Ok((scrutinee, typed_arms, ty, flow))
    }

    fn array_element(expr: &TypedExpr) -> crate::ast::ArrayElementType {
        match (&expr.kind, expr.ty) {
            (_, ExprResult::Value(Type::Array(element))) => element,
            (TypedExprKind::Array(_, element), _) => *element,
            _ => crate::ast::ArrayElementType::Number,
        }
    }

    fn analyze_expected(
        &mut self,
        expr: &Expr,
        span: Span,
        return_type: ReturnContext,
        expected: Option<Type>,
    ) -> Result<(TypedExpr, Flow), SemanticError> {
        self.analyze_expr_in_context(
            expr,
            span,
            return_type,
            expected.map_or(ExprContext::Value, ExprContext::Expected),
        )
    }

    fn analyze_expr(
        &mut self,
        expr: &Expr,
        span: Span,
        return_type: ReturnContext,
    ) -> Result<(TypedExpr, Flow), SemanticError> {
        self.analyze_expr_in_context(expr, span, return_type, ExprContext::Value)
    }

    fn analyze_expr_in_context(
        &mut self,
        expr: &Expr,
        span: Span,
        return_type: ReturnContext,
        context: ExprContext,
    ) -> Result<(TypedExpr, Flow), SemanticError> {
        let mut flow = Flow::FALLTHROUGH;
        let (kind, ty) = match expr {
            Expr::Number(value) => (TypedExprKind::Number(value.clone()), Type::Number.into()),
            Expr::String(value) => (TypedExprKind::String(value.clone()), Type::String.into()),
            Expr::Bool(value) => (TypedExprKind::Bool(*value), Type::Bool.into()),
            Expr::Placeholder { span } => {
                let binding = self
                    .placeholder_bindings
                    .last()
                    .and_then(|bindings| bindings.get(&std::ptr::from_ref(expr).addr()));
                let Some(binding) = binding else {
                    return Err(SemanticError::InvalidPlaceholder { span: *span });
                };
                (
                    self.binding_expression(*binding, "<placeholder>"),
                    binding.ty.into(),
                )
            }

            Expr::Identifier(name) => {
                self.check_value_binding(name, span, BindingUse::Read)?;
                let binding =
                    self.lookup_variable(name)
                        .ok_or_else(|| SemanticError::UndefinedVariable {
                            name: name.clone(),
                            span,
                        })?;

                (self.binding_expression(binding, name), binding.ty.into())
            }

            Expr::Loop { body } => {
                let (id, body, body_flow) =
                    self.analyze_value_loop_body(body, return_type, context)?;
                let ty = body_flow.break_type().map_err(|(expected, found)| {
                    SemanticError::TypeMismatch {
                        expected,
                        found,
                        span,
                    }
                })?;

                flow = body_flow.infinite_loop();

                (
                    TypedExprKind::Loop { id, body },
                    ty.map_or(ExprResult::Never, ExprResult::Value),
                )
            }

            Expr::Block(block) => {
                let (block, ty, block_flow) =
                    self.analyze_value_block(block, return_type, context)?;

                flow = block_flow;

                (TypedExprKind::Block(block), ty)
            }

            Expr::If { cond, then, else_ } => {
                let (cond, cond_flow) = self.analyze_expr(cond, span, return_type)?;

                self.expect_type(Type::Bool, cond.ty, span)?;

                let (then, then_ty, then_flow) =
                    self.analyze_value_block(then, return_type, context)?;
                let else_ = else_.as_ref().ok_or(SemanticError::MissingElse { span })?;
                let (else_, else_ty, else_flow) =
                    self.analyze_value_block(else_, return_type, context)?;
                let ty = self.join_results(then_ty, else_ty, span)?;

                flow = cond_flow.then(then_flow.join(else_flow));

                (
                    TypedExprKind::If {
                        cond: Box::new(cond),
                        then,
                        else_: Some(else_),
                    },
                    ty,
                )
            }

            Expr::Match { scrutinee, arms } => {
                let (scrutinee, arms, ty, match_flow) = self.analyze_match(
                    scrutinee,
                    arms,
                    span,
                    return_type,
                    MatchContext::Value(context),
                )?;
                flow = match_flow;
                (
                    TypedExprKind::Match {
                        scrutinee: Box::new(scrutinee),
                        arms,
                    },
                    ty,
                )
            }

            Expr::Unary { op, expr } => {
                let (expr, expr_flow) = self.analyze_expr(expr, span, return_type)?;
                let ty = match op {
                    UnaryOp::Not => Type::Bool,
                    UnaryOp::Negate => Type::Number,
                };

                self.expect_type(ty, expr.ty, span)?;
                flow = expr_flow;

                (
                    TypedExprKind::Unary {
                        op: *op,
                        expr: Box::new(expr),
                    },
                    ty.into(),
                )
            }

            Expr::Binary { left, op, right } => {
                let (left, left_flow) = self.analyze_expr(left, span, return_type)?;
                let (right, right_flow) = self.analyze_expr(right, span, return_type)?;
                let ty = self.analyze_binary(op, left.ty, right.ty, span)?;

                flow = if matches!(op, BinaryOp::And | BinaryOp::Or) {
                    left_flow.then(Flow::FALLTHROUGH.join(right_flow.without_fallthrough()))
                } else {
                    left_flow.then(right_flow)
                };

                (
                    TypedExprKind::Binary {
                        left: Box::new(left),
                        op: *op,
                        right: Box::new(right),
                    },
                    ty.into(),
                )
            }

            Expr::Range {
                start,
                end,
                step,
                inclusive,
            } => {
                let (start, start_flow) = self.analyze_expr(start, span, return_type)?;

                self.expect_type(Type::Number, start.ty, span)?;

                let (end, end_flow) = self.analyze_expr(end, span, return_type)?;

                self.expect_type(Type::Number, end.ty, span)?;
                flow = start_flow.then(end_flow);

                let step = match step {
                    Some(step) => {
                        let (step, step_flow) = self.analyze_expr(step, span, return_type)?;

                        self.expect_type(Type::Number, step.ty, span)?;
                        flow = flow.then(step_flow);

                        Some(Box::new(step))
                    }
                    None => None,
                };

                (
                    TypedExprKind::Range {
                        start: Box::new(start),
                        end: Box::new(end),
                        step,
                        inclusive: *inclusive,
                    },
                    Type::Range.into(),
                )
            }

            Expr::Pipeline {
                input,
                input_span,
                stages,
            } => {
                return self.analyze_pipeline(input, *input_span, stages, return_type, context);
            }
            Expr::Lambda(lambda) => {
                return Err(SemanticError::InvalidClosure {
                    reason: "a closure must initialize a local callable binding",
                    span: lambda.span,
                });
            }
            Expr::Call {
                func,
                args,
                span: call_span,
            } => {
                if let Some(LexicalBinding::Callable(callable)) = self.lookup_binding(func).cloned()
                {
                    return self.analyze_lexical_call(&callable, args, *call_span, return_type);
                }
                return self.analyze_call(func, args, span, return_type, context);
            }

            Expr::Reserve {
                receiver,
                args,
                span: method_span,
            } => {
                Self::check_single_method_argument("reserve", args, *method_span)?;
                let (receiver, receiver_flow) = self.analyze_expr(receiver, span, return_type)?;
                let element = Self::array_element(&receiver);
                self.expect_type(Type::Array(element), receiver.ty, span)?;
                let (additional, additional_flow) =
                    self.analyze_expr(&args[0].value, span, return_type)?;
                self.expect_type(Type::Number, additional.ty, span)?;
                flow = receiver_flow.then(additional_flow);

                (
                    TypedExprKind::Reserve {
                        receiver: Box::new(receiver),
                        additional: Box::new(additional),
                    },
                    ExprResult::Void,
                )
            }

            Expr::Push {
                receiver,
                args,
                span: method_span,
            } => {
                Self::check_single_method_argument("push", args, *method_span)?;
                let (receiver, receiver_flow) = self.analyze_expr(receiver, span, return_type)?;
                let element = Self::array_element(&receiver);
                self.expect_type(Type::Array(element), receiver.ty, span)?;
                let expected = element.value_type();
                let (item, item_flow) =
                    self.analyze_expected(&args[0].value, span, return_type, Some(expected))?;
                self.expect_type(expected, item.ty, span)?;
                flow = receiver_flow.then(item_flow);

                (
                    TypedExprKind::Push {
                        receiver: Box::new(receiver),
                        item: Box::new(item),
                    },
                    ExprResult::Void,
                )
            }

            Expr::Pop {
                receiver,
                args,
                span: method_span,
            }
            | Expr::Remove {
                receiver,
                args,
                span: method_span,
            } => {
                let remove = matches!(expr, Expr::Remove { .. });
                Self::check_method_arguments(
                    if remove { "remove" } else { "pop" },
                    args,
                    usize::from(remove),
                    *method_span,
                )?;
                let (receiver, receiver_flow) = self.analyze_expr(receiver, span, return_type)?;
                let element = Self::array_element(&receiver);
                self.expect_type(Type::Array(element), receiver.ty, span)?;
                flow = receiver_flow;
                let kind = if remove {
                    let (index, index_flow) =
                        self.analyze_expr(&args[0].value, span, return_type)?;
                    self.expect_type(Type::Number, index.ty, span)?;
                    flow = flow.then(index_flow);
                    TypedExprKind::Remove {
                        receiver: Box::new(receiver),
                        index: Box::new(index),
                    }
                } else {
                    TypedExprKind::Pop {
                        receiver: Box::new(receiver),
                    }
                };
                (kind, element.value_type().into())
            }

            Expr::Array(elements) => {
                let mut values = Vec::with_capacity(elements.len());

                let mut element_type = match context {
                    ExprContext::Expected(Type::Array(element)) => Some(element),
                    _ => None,
                };
                for element in elements {
                    let (value, value_flow) = self.analyze_expr(element, span, return_type)?;
                    if let Some(expected) = element_type {
                        self.expect_type(expected.value_type(), value.ty, span)?;
                    } else if let ExprResult::Value(ty) = value.ty {
                        element_type = Some(match ty {
                            Type::Number => crate::ast::ArrayElementType::Number,
                            Type::Bool => crate::ast::ArrayElementType::Bool,
                            Type::String => crate::ast::ArrayElementType::String,
                            _ => {
                                self.expect_type(Type::Number, value.ty, span)?;
                                unreachable!()
                            }
                        });
                    } else {
                        self.expect_type(Type::Number, value.ty, span)?;
                    }
                    flow = flow.then(value_flow);
                    values.push(value);
                }
                let element_type = element_type.unwrap_or(crate::ast::ArrayElementType::Number);
                (
                    TypedExprKind::Array(values, element_type),
                    Type::Array(element_type).into(),
                )
            }

            Expr::Index { expr, index } => {
                let (expr, expr_flow) = self.analyze_expr(expr, span, return_type)?;

                let element_type = Self::array_element(&expr);
                self.expect_type(Type::Array(element_type), expr.ty, span)?;

                let (index, index_flow) = self.analyze_expr(index, span, return_type)?;

                self.expect_type(Type::Number, index.ty, span)?;
                flow = expr_flow.then(index_flow);

                (
                    TypedExprKind::Index {
                        expr: Box::new(expr),
                        index: Box::new(index),
                    },
                    element_type.value_type().into(),
                )
            }
        };
        let ty = Self::completion_result(ty, flow);

        Ok((TypedExpr { kind, ty }, flow))
    }

    fn check_single_method_argument(
        name: &str,
        args: &[crate::ast::CallArgument],
        span: Span,
    ) -> Result<(), SemanticError> {
        Self::check_method_arguments(name, args, 1, span)
    }

    fn check_method_arguments(
        name: &str,
        args: &[crate::ast::CallArgument],
        expected: usize,
        span: Span,
    ) -> Result<(), SemanticError> {
        if let Some(arg) = args.iter().find(|arg| arg.name.is_some()) {
            return Err(SemanticError::NamedArgumentsNotSupported {
                name: name.into(),
                span: arg.span,
            });
        }
        if args.len() != expected {
            return Err(SemanticError::ArgumentCountMismatch {
                name: name.into(),
                expected,
                found: args.len(),
                span,
            });
        }
        Ok(())
    }

    fn analyze_call(
        &mut self,
        name: &str,
        args: &[CallArgument],
        span: Span,
        return_type: ReturnContext,
        context: ExprContext,
    ) -> Result<(TypedExpr, Flow), SemanticError> {
        if self.lookup_variable(name).is_some() {
            return Err(SemanticError::NotCallable {
                name: name.into(),
                span,
            });
        }

        let signature =
            self.functions
                .get(name)
                .ok_or_else(|| SemanticError::UndefinedFunction {
                    name: name.into(),
                    span,
                })?;

        if args.iter().any(|arg| arg.name.is_some())
            || (args.len() < signature.params.len()
                && signature.defaults.iter().any(Option::is_some))
        {
            return self.analyze_bound_call(name, args, span, return_type);
        }

        if signature.params.len() != args.len() {
            return Err(SemanticError::ArgumentCountMismatch {
                name: name.into(),
                expected: signature.params.len(),
                found: args.len(),
                span,
            });
        }

        let reference = signature.reference;
        let mut result_type = signature.return_type;
        let mut arguments = Vec::with_capacity(args.len());
        let mut flow = Flow::FALLTHROUGH;

        for (index, arg) in args.iter().enumerate() {
            // Expression analysis may introduce scoped bindings, so release the
            // signature borrow before analyzing each argument.
            let expected = self.functions[name].params[index];
            let builtin_len = reference == FunctionRef::Builtin(BuiltinFunction::Len);
            let builtin_resizable = reference == FunctionRef::Builtin(BuiltinFunction::Resizable);
            let (arg, arg_flow) = self.analyze_expected(
                &arg.value,
                span,
                return_type,
                if builtin_resizable {
                    match context {
                        ExprContext::Expected(ty @ Type::Array(_)) => Some(ty),
                        _ => None,
                    }
                } else if builtin_len {
                    None
                } else {
                    Some(expected)
                },
            )?;

            if (builtin_len || builtin_resizable)
                && let ExprResult::Value(Type::Array(element)) = arg.ty
            {
                if builtin_resizable {
                    result_type = Type::Array(element);
                }
            } else {
                self.expect_type(expected, arg.ty, span)?;
            }
            flow = flow.then(arg_flow);
            arguments.push(arg);
        }

        Ok((
            TypedExpr {
                kind: TypedExprKind::Call {
                    func: reference,
                    name: name.into(),
                    args: arguments,
                },
                ty: Self::completion_result(result_type.into(), flow),
            },
            flow,
        ))
    }

    fn analyze_binary(
        &self,
        op: &BinaryOp,
        left: ExprResult,
        right: ExprResult,
        span: Span,
    ) -> Result<Type, SemanticError> {
        let (operator, operand_type, result_type) = match op {
            BinaryOp::Add => ("+", Type::Number, Type::Number),
            BinaryOp::Subtract => ("-", Type::Number, Type::Number),
            BinaryOp::Multiply => ("*", Type::Number, Type::Number),
            BinaryOp::Divide => ("/", Type::Number, Type::Number),
            BinaryOp::Remainder => ("%", Type::Number, Type::Number),

            BinaryOp::LessThan => ("<", Type::Number, Type::Bool),
            BinaryOp::LessThanOrEqual => ("<=", Type::Number, Type::Bool),
            BinaryOp::GreaterThan => (">", Type::Number, Type::Bool),
            BinaryOp::GreaterThanOrEqual => (">=", Type::Number, Type::Bool),

            BinaryOp::In => {
                if Self::accepts_operand(left, Type::Number)
                    && Self::accepts_operand(right, Type::Range)
                {
                    return Ok(Type::Bool);
                }

                return Err(SemanticError::InvalidBinaryOperands {
                    operator: "in",
                    left: Self::diagnostic_operand(left, Type::Number),
                    right: Self::diagnostic_operand(right, Type::Range),
                    span,
                });
            }

            BinaryOp::And => ("&&", Type::Bool, Type::Bool),
            BinaryOp::Or => ("||", Type::Bool, Type::Bool),

            BinaryOp::Equal | BinaryOp::NotEqual => {
                let operator = if *op == BinaryOp::Equal { "==" } else { "!=" };

                let operand_type = left
                    .value_type()
                    .or(right.value_type())
                    .unwrap_or(Type::Number);

                if matches!(
                    operand_type,
                    Type::Number | Type::Bool | Type::String | Type::Array(_)
                ) && Self::accepts_operand(left, operand_type)
                    && Self::accepts_operand(right, operand_type)
                {
                    return Ok(Type::Bool);
                }

                return Err(SemanticError::InvalidBinaryOperands {
                    operator,
                    left: Self::diagnostic_operand(left, operand_type),
                    right: Self::diagnostic_operand(right, operand_type),
                    span,
                });
            }
        };

        if !Self::accepts_operand(left, operand_type) || !Self::accepts_operand(right, operand_type)
        {
            return Err(SemanticError::InvalidBinaryOperands {
                operator,
                left: Self::diagnostic_operand(left, operand_type),
                right: Self::diagnostic_operand(right, operand_type),
                span,
            });
        }

        Ok(result_type)
    }

    fn accepts_operand(result: ExprResult, expected: Type) -> bool {
        result == ExprResult::Never || result == expected
    }

    fn diagnostic_operand(result: ExprResult, expected: Type) -> Type {
        match result {
            ExprResult::Value(ty) => ty,
            ExprResult::Void => Type::Void,
            ExprResult::Never => expected,
        }
    }

    fn lookup_variable(&self, name: &str) -> Option<VariableBinding> {
        match self.lookup_binding(name) {
            Some(LexicalBinding::Value(binding)) => Some(*binding),
            _ => None,
        }
    }

    fn declare_variable(
        &mut self,
        name: &str,
        ty: Type,
        mutability: BindingMutability,
        span: Span,
    ) -> Result<VariableId, SemanticError> {
        let scope = self
            .scopes
            .last_mut()
            .expect("declarations require a function scope");

        match scope.entry(name.into()) {
            Entry::Occupied(_) => Err(SemanticError::DuplicateVariable {
                name: name.into(),
                span,
            }),

            Entry::Vacant(entry) => {
                let id = VariableId(self.next_variable_id);

                self.next_variable_id += 1;

                entry.insert(LexicalBinding::Value(VariableBinding {
                    owner: self.owner,
                    id,
                    ty,
                    mutability,
                }));

                Ok(id)
            }
        }
    }

    fn check_variable_type(&self, name: &str, ty: Type, span: Span) -> Result<(), SemanticError> {
        if ty == Type::Void {
            return Err(SemanticError::InvalidVoidType {
                name: name.into(),
                span,
            });
        }

        Ok(())
    }

    fn expect_type(
        &self,
        expected: Type,
        found: ExprResult,
        span: Span,
    ) -> Result<(), SemanticError> {
        let found = match found {
            ExprResult::Never => return Ok(()),
            ExprResult::Void => Type::Void,
            ExprResult::Value(ty) => ty,
        };

        if expected != found {
            return Err(SemanticError::TypeMismatch {
                expected,
                found,
                span,
            });
        }

        Ok(())
    }
}

#[cfg(test)]
#[path = "semantic_tests.rs"]
mod tests;

#[cfg(test)]
#[path = "typed_ast_tests.rs"]
mod typed_tests;
