use std::{collections::HashMap, ops::ControlFlow};

use crate::{
    ast::{BinaryOp, Type},
    typed_ast::{
        BuiltinFunction, FunctionRef, TypedExpr, TypedExprKind, TypedProgram, TypedStatement,
        TypedStatementKind,
    },
};
use wasm_encoder::{BlockType, Function, Instruction, MemArg, ValType};

use super::{
    CodegenError,
    abi::{self, Signature},
    walker::{self, Visitor},
};

pub(super) const PAGE_BYTES: u64 = 65_536;
const PAGE_ALIGN_LOG2: u32 = PAGE_BYTES.trailing_zeros();
pub(super) const MAX_PAGES: u64 = 65_535;
pub(super) const MAX_BYTES: u64 = MAX_PAGES * PAGE_BYTES;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub(super) enum Helper {
    Alloc,
    ValidateString,
    ValidateArray,
    ArrayAddress,
    ArrayLen,
    StringEqual,
    ArrayEqual,
    ValidateBool,
    ValidateBoolArray,
    BoolArrayAddress,
    BoolArrayLen,
    BoolArrayEqual,
    ValidateStringArray,
    StringArrayAddress,
    StringArrayLen,
    StringArrayEqual,
    StringByteLen,
    StringConcat,
    StringSliceBytes,
    StringReplaceAll,
    StringJoin,
}

impl Helper {
    pub(super) const ALL: [Self; 7] = [
        Self::Alloc,
        Self::ValidateString,
        Self::ValidateArray,
        Self::ArrayAddress,
        Self::ArrayLen,
        Self::StringEqual,
        Self::ArrayEqual,
    ];

    const BOOLEAN_ARRAY: [Self; 5] = [
        Self::ValidateBool,
        Self::ValidateBoolArray,
        Self::BoolArrayAddress,
        Self::BoolArrayLen,
        Self::BoolArrayEqual,
    ];
    const STRING_ARRAY: [Self; 4] = [
        Self::ValidateStringArray,
        Self::StringArrayAddress,
        Self::StringArrayLen,
        Self::StringArrayEqual,
    ];

    pub(super) fn index(self) -> u32 {
        Self::ALL
            .iter()
            .position(|helper| *helper == self)
            .expect("memory helper registered in canonical order") as u32
    }

    pub(super) fn signature(self) -> Signature {
        use ValType::{F64, I32};

        let (params, result) = match self {
            Self::Alloc => (vec![I32], I32),
            Self::ValidateString => (vec![I32], I32),
            Self::ValidateArray => (vec![I32], I32),
            Self::ArrayAddress => (vec![I32, F64], I32),
            Self::ArrayLen => (vec![I32], F64),
            Self::StringEqual => (vec![I32, I32], I32),
            Self::ArrayEqual | Self::BoolArrayEqual | Self::StringArrayEqual => {
                (vec![I32, I32], I32)
            }
            Self::ValidateBool | Self::ValidateBoolArray | Self::ValidateStringArray => {
                (vec![I32], I32)
            }
            Self::BoolArrayAddress | Self::StringArrayAddress => (vec![I32, F64], I32),
            Self::BoolArrayLen | Self::StringArrayLen | Self::StringByteLen => (vec![I32], F64),
            Self::StringConcat | Self::StringJoin => (vec![I32, I32], I32),
            Self::StringSliceBytes => (vec![I32, F64, F64], I32),
            Self::StringReplaceAll => (vec![I32, I32, I32], I32),
        };

        Signature {
            params,
            results: vec![result],
        }
    }
}

#[cfg(test)]
pub(super) fn helpers() -> Vec<(Helper, Signature)> {
    Helper::ALL
        .into_iter()
        .map(|helper| (helper, helper.signature()))
        .collect()
}

pub struct MemoryPlan {
    pub data: Vec<u8>,
    pub heap_start: u32,
    strings: HashMap<String, u32>,
    boolean_arrays: bool,
    string_arrays: bool,
    string_byte_len: bool,
    string_concat: bool,
    string_slice_bytes: bool,
    string_replace_all: bool,
    string_join: bool,
}

impl MemoryPlan {
    pub fn new(program: &TypedProgram) -> Result<Option<Self>, CodegenError> {
        let mut plan = Self {
            data: vec![0; abi::MIN_ADDRESS as usize],
            heap_start: abi::MIN_ADDRESS,
            strings: HashMap::new(),
            boolean_arrays: false,
            string_arrays: false,
            string_byte_len: false,
            string_concat: false,
            string_slice_bytes: false,
            string_replace_all: false,
            string_join: false,
        };
        let mut used = false;

        for host in &program.host_functions {
            used |= memory_type(host.return_type) || host.params.iter().copied().any(memory_type);
            plan.observe_type(host.return_type);
            for ty in &host.params {
                plan.observe_type(*ty);
            }
        }

        for function in &program.functions {
            plan.observe_type(function.return_type);
            for param in &function.params {
                plan.observe_type(param.ty);
            }
            used |= memory_type(function.return_type)
                || function.params.iter().any(|param| memory_type(param.ty));

            let mut visitor = MemoryVisitor {
                plan: &mut plan,
                used: &mut used,
            };

            if let ControlFlow::Break(error) = walker::walk_function(function, &mut visitor) {
                return Err(error);
            }
        }

        if !used {
            return Ok(None);
        }

        plan.heap_start = aligned_offset(plan.data.len() as u64)?;

        Ok(Some(plan))
    }

    fn observe_type(&mut self, ty: Type) {
        self.boolean_arrays |= ty == Type::Array(crate::ast::ArrayElementType::Bool);
        self.string_arrays |= ty == Type::Array(crate::ast::ArrayElementType::String);
    }

    fn helper_order(&self) -> impl Iterator<Item = Helper> + '_ {
        Helper::ALL
            .into_iter()
            .chain(
                self.boolean_arrays
                    .then_some(Helper::BOOLEAN_ARRAY)
                    .into_iter()
                    .flatten(),
            )
            .chain(
                self.string_arrays
                    .then_some(Helper::STRING_ARRAY)
                    .into_iter()
                    .flatten(),
            )
            .chain(self.string_byte_len.then_some(Helper::StringByteLen))
            .chain(self.string_concat.then_some(Helper::StringConcat))
            .chain(self.string_slice_bytes.then_some(Helper::StringSliceBytes))
            .chain(self.string_replace_all.then_some(Helper::StringReplaceAll))
            .chain(self.string_join.then_some(Helper::StringJoin))
    }

    pub(super) fn helpers(&self) -> Vec<Helper> {
        self.helper_order().collect()
    }

    pub(super) fn helper_index(&self, helper: Helper) -> u32 {
        u32::try_from(
            self.helper_order()
                .position(|h| h == helper)
                .expect("required helper planned"),
        )
        .expect("helper count fits u32")
    }

    pub fn string(&self, value: &str) -> Option<u32> {
        self.strings.get(value).copied()
    }

    fn intern(&mut self, value: &str) -> Result<(), CodegenError> {
        if self.strings.contains_key(value) {
            return Ok(());
        }

        let length = u32::try_from(value.len()).map_err(|_| CodegenError::LimitExceeded {
            what: "string byte length",
        })?;
        let handle = aligned_offset(self.data.len() as u64)?;
        let payload = u64::from(handle) + u64::from(abi::DESCRIPTOR_SIZE);
        let end = payload + u64::from(length);

        aligned_offset(end)?;

        let end = usize::try_from(end).map_err(|_| CodegenError::LimitExceeded {
            what: "static memory data",
        })?;

        self.data
            .try_reserve(end - self.data.len())
            .map_err(|_| CodegenError::LimitExceeded {
                what: "static memory data",
            })?;
        self.data.resize(handle as usize, 0);
        self.data.extend_from_slice(&(payload as u32).to_le_bytes());
        self.data.extend_from_slice(&length.to_le_bytes());
        self.data.extend_from_slice(value.as_bytes());
        self.strings.insert(value.to_owned(), handle);

        Ok(())
    }
}

struct MemoryVisitor<'a> {
    plan: &'a mut MemoryPlan,
    used: &'a mut bool,
}

impl Visitor<'_> for MemoryVisitor<'_> {
    type Break = CodegenError;

    fn enter_closure(
        &mut self,
        closure: &crate::typed_ast::TypedClosure,
    ) -> ControlFlow<CodegenError> {
        self.plan.observe_type(closure.return_type);
        for param in &closure.params {
            self.plan.observe_type(param.ty);
        }
        *self.used |= !closure.captures.is_empty()
            || memory_type(closure.return_type)
            || closure.params.iter().any(|p| memory_type(p.ty));
        ControlFlow::Continue(())
    }

    fn enter_statement(&mut self, statement: &TypedStatement) -> ControlFlow<CodegenError> {
        match &statement.kind {
            TypedStatementKind::Let { ty, .. } => {
                self.plan.observe_type(*ty);
                *self.used |= memory_type(*ty);
            }
            TypedStatementKind::For { .. } => *self.used = true,
            _ => {}
        }

        ControlFlow::Continue(())
    }

    fn enter_call_binding(
        &mut self,
        binding: &crate::typed_ast::TypedCallBinding,
    ) -> ControlFlow<CodegenError> {
        self.plan.observe_type(binding.ty);
        *self.used |= memory_type(binding.ty);
        ControlFlow::Continue(())
    }

    fn visit_pattern(&mut self, pattern: &crate::ast::MatchPattern) -> ControlFlow<CodegenError> {
        if let crate::ast::MatchPatternKind::String(value) = &pattern.kind {
            *self.used = true;
            if let Err(error) = self.plan.intern(value) {
                return ControlFlow::Break(error);
            }
        }
        ControlFlow::Continue(())
    }

    fn enter_expression(&mut self, expr: &TypedExpr) -> ControlFlow<CodegenError> {
        if let Some(ty) = expr.ty.value_type() {
            self.plan.observe_type(ty);
        }
        if let TypedExprKind::Array(_, element) = &expr.kind {
            self.plan.observe_type(Type::Array(*element));
        }
        *self.used |= expr.ty.value_type().is_some_and(memory_type);

        match &expr.kind {
            TypedExprKind::String(value) => {
                *self.used = true;

                if let Err(error) = self.plan.intern(value) {
                    return ControlFlow::Break(error);
                }
            }

            TypedExprKind::Call { func, .. } => {
                self.plan.string_byte_len |=
                    *func == FunctionRef::Builtin(BuiltinFunction::StringByteLen);
                self.plan.string_concat |=
                    *func == FunctionRef::Builtin(BuiltinFunction::StringConcat);
                self.plan.string_slice_bytes |=
                    *func == FunctionRef::Builtin(BuiltinFunction::StringSliceBytes);
                self.plan.string_replace_all |=
                    *func == FunctionRef::Builtin(BuiltinFunction::StringReplaceAll);
                if *func == FunctionRef::Builtin(BuiltinFunction::StringJoin) {
                    self.plan.string_join = true;
                    // The fixed signature needs string-array helpers even when
                    // Never or forged annotations carry no array type.
                    self.plan.string_arrays = true;
                }
                *self.used |= matches!(
                    func,
                    FunctionRef::Builtin(
                        BuiltinFunction::Len
                            | BuiltinFunction::Resizable
                            | BuiltinFunction::StringByteLen
                            | BuiltinFunction::StringConcat
                            | BuiltinFunction::StringSliceBytes
                            | BuiltinFunction::StringReplaceAll
                            | BuiltinFunction::StringJoin
                    )
                );
            }

            TypedExprKind::Reserve { .. }
            | TypedExprKind::Push { .. }
            | TypedExprKind::Pop { .. }
            | TypedExprKind::Remove { .. }
            | TypedExprKind::Array(_, _)
            | TypedExprKind::Index { .. }
            | TypedExprKind::Range { .. }
            | TypedExprKind::Binary {
                op: BinaryOp::In, ..
            } => *self.used = true,

            _ => {}
        }

        ControlFlow::Continue(())
    }
}

fn memory_type(ty: Type) -> bool {
    matches!(ty, Type::String | Type::Array(_) | Type::Range)
}

fn aligned_offset(value: u64) -> Result<u32, CodegenError> {
    let mask = u64::from(abi::ALLOCATION_ALIGNMENT - 1);
    let aligned = value.checked_add(mask).map(|value| value & !mask);

    match aligned {
        Some(aligned) if aligned <= MAX_BYTES => Ok(aligned as u32),
        _ => Err(CodegenError::LimitExceeded {
            what: "static memory layout",
        }),
    }
}

pub(super) fn emit(helper: Helper, first_function: u32) -> Function {
    match helper {
        Helper::Alloc => emit_alloc(),
        Helper::ValidateString => emit_validate(abi::STRING_ELEMENT_SIZE),
        Helper::ValidateArray => emit_validate(abi::NUMBER_ELEMENT_SIZE),
        Helper::ArrayAddress => emit_array_address(first_function),
        Helper::ArrayLen => emit_array_len(first_function),
        Helper::StringEqual => emit_string_equal(first_function),
        Helper::ArrayEqual => emit_array_equal(first_function),
        _ => unreachable!("typed helpers require their planned indices"),
    }
}

pub(super) fn emit_planned(helper: Helper, first: u32, plan: &MemoryPlan) -> Function {
    let index = |h| first + plan.helper_index(h);
    match helper {
        Helper::StringByteLen => emit_typed_len(index(Helper::ValidateString)),
        Helper::StringConcat => {
            emit_string_concat(index(Helper::ValidateString), index(Helper::Alloc))
        }
        Helper::StringSliceBytes => {
            emit_string_slice_bytes(index(Helper::ValidateString), index(Helper::Alloc))
        }
        Helper::StringReplaceAll => emit_string_replace_all(
            index(Helper::ValidateString),
            index(Helper::StringEqual),
            index(Helper::Alloc),
        ),
        Helper::StringJoin => emit_string_join(
            index(super::array::validator(
                crate::ast::ArrayElementType::String,
            )),
            index(Helper::ValidateString),
            index(Helper::Alloc),
        ),
        Helper::ValidateBoolArray => emit_validate(abi::BOOL_ELEMENT_SIZE),
        Helper::ValidateBool => {
            use Instruction::*;
            let mut body = Function::new([]);
            instructions(&mut body, &[LocalGet(0), I32Const(1), I32GtU]);
            trap_if(&mut body);
            instructions(&mut body, &[LocalGet(0), End]);
            body
        }
        Helper::BoolArrayAddress => {
            emit_typed_address(index(Helper::ValidateBoolArray), abi::BOOL_ELEMENT_SIZE)
        }
        Helper::BoolArrayLen => emit_typed_len(index(Helper::ValidateBoolArray)),
        Helper::BoolArrayEqual => emit_typed_equal(
            crate::ast::ArrayElementType::Bool,
            index(Helper::ValidateBoolArray),
            super::array::consumer(crate::ast::ArrayElementType::Bool).map(index),
            index(Helper::StringEqual),
        ),
        Helper::ValidateStringArray => emit_validate(abi::STRING_ARRAY_ELEMENT_SIZE),
        Helper::StringArrayAddress => emit_typed_address(
            index(Helper::ValidateStringArray),
            abi::STRING_ARRAY_ELEMENT_SIZE,
        ),
        Helper::StringArrayLen => emit_typed_len(index(Helper::ValidateStringArray)),
        Helper::StringArrayEqual => emit_typed_equal(
            crate::ast::ArrayElementType::String,
            index(Helper::ValidateStringArray),
            super::array::consumer(crate::ast::ArrayElementType::String).map(index),
            index(Helper::StringEqual),
        ),
        _ => emit(helper, first),
    }
}

fn emit_typed_equal(
    element: crate::ast::ArrayElementType,
    validator: u32,
    consumer: Option<u32>,
    string_equal: u32,
) -> Function {
    use Instruction::*;
    let mut body = Function::new([(4, ValType::I32)]);
    instructions(
        &mut body,
        &[
            LocalGet(0),
            Call(validator),
            LocalSet(0),
            LocalGet(1),
            Call(validator),
            LocalSet(1),
            LocalGet(0),
            I32Load(header(abi::DESCRIPTOR_LENGTH_OFFSET)),
            LocalTee(4),
            LocalGet(1),
            I32Load(header(abi::DESCRIPTOR_LENGTH_OFFSET)),
            I32Ne,
            If(BlockType::Empty),
            I32Const(0),
            Return,
            End,
            LocalGet(0),
            I32Load(header(abi::DESCRIPTOR_DATA_OFFSET)),
            LocalSet(2),
            LocalGet(1),
            I32Load(header(abi::DESCRIPTOR_DATA_OFFSET)),
            LocalSet(3),
            Block(BlockType::Empty),
            Loop(BlockType::Empty),
            LocalGet(5),
            LocalGet(4),
            I32GeU,
            BrIf(1),
        ],
    );
    for pointer in [2, 3] {
        instructions(
            &mut body,
            &[
                LocalGet(pointer),
                LocalGet(5),
                I32Const(super::array::width(element) as i32),
                I32Mul,
                I32Add,
                super::array::load(element, 0),
            ],
        );
        if let Some(consumer) = consumer {
            body.instruction(&Call(consumer));
        }
    }
    match element {
        crate::ast::ArrayElementType::Bool => {
            body.instruction(&I32Ne);
        }
        crate::ast::ArrayElementType::String => {
            instructions(&mut body, &[Call(string_equal), I32Eqz]);
        }
        crate::ast::ArrayElementType::Number => {
            body.instruction(&F64Ne);
        }
    }
    instructions(
        &mut body,
        &[
            If(BlockType::Empty),
            I32Const(0),
            Return,
            End,
            LocalGet(5),
            I32Const(1),
            I32Add,
            LocalSet(5),
            Br(0),
            End,
            End,
            I32Const(1),
            End,
        ],
    );
    body
}

fn instructions(body: &mut Function, instructions: &[Instruction<'_>]) {
    for instruction in instructions {
        body.instruction(instruction);
    }
}

fn trap_if(body: &mut Function) {
    instructions(
        body,
        &[
            Instruction::If(BlockType::Empty),
            Instruction::Unreachable,
            Instruction::End,
        ],
    );
}

fn memory_bytes(body: &mut Function) {
    instructions(
        body,
        &[
            Instruction::MemorySize(0),
            Instruction::I64ExtendI32U,
            Instruction::I64Const(i64::from(PAGE_ALIGN_LOG2)),
            Instruction::I64Shl,
        ],
    );
}

fn header(offset: u64) -> MemArg {
    MemArg {
        offset,
        align: abi::DESCRIPTOR_FIELD_ALIGN_LOG2,
        memory_index: 0,
    }
}

fn emit_alloc() -> Function {
    use Instruction::*;

    let mut body = Function::new([(4, ValType::I64)]);

    instructions(
        &mut body,
        &[
            GlobalGet(0),
            I64ExtendI32U,
            LocalTee(1),
            I64Const(i64::from(abi::MIN_ADDRESS)),
            I64LtU,
            LocalGet(1),
            I64Const(i64::from(abi::ALLOCATION_ALIGNMENT - 1)),
            I64And,
            I64Const(0),
            I64Ne,
            I32Or,
        ],
    );
    trap_if(&mut body);

    instructions(
        &mut body,
        &[
            LocalGet(0),
            I64ExtendI32U,
            I64Const(i64::from(abi::ALLOCATION_ALIGNMENT - 1)),
            I64Add,
            I64Const(-i64::from(abi::ALLOCATION_ALIGNMENT)),
            I64And,
            LocalTee(2),
            I64Eqz,
            If(BlockType::Empty),
            I64Const(i64::from(abi::MIN_ALLOCATION_BYTES)),
            LocalSet(2),
            End,
            LocalGet(1),
            LocalGet(2),
            I64Add,
            LocalTee(3),
            I64Const(MAX_BYTES as i64),
            I64GtU,
        ],
    );
    trap_if(&mut body);

    instructions(
        &mut body,
        &[
            LocalGet(3),
            I64Const((PAGE_BYTES - 1) as i64),
            I64Add,
            I64Const(i64::from(PAGE_ALIGN_LOG2)),
            I64ShrU,
            LocalTee(4),
            MemorySize(0),
            I64ExtendI32U,
            I64GtU,
            If(BlockType::Empty),
            LocalGet(4),
            MemorySize(0),
            I64ExtendI32U,
            I64Sub,
            I32WrapI64,
            MemoryGrow(0),
            I32Const(-1),
            I32Eq,
        ],
    );
    trap_if(&mut body);

    instructions(
        &mut body,
        &[
            End,
            LocalGet(3),
            I32WrapI64,
            GlobalSet(0),
            LocalGet(1),
            I32WrapI64,
            End,
        ],
    );

    body
}

fn emit_validate(width: u32) -> Function {
    use Instruction::*;

    let mut body = Function::new([(1, ValType::I64)]);

    instructions(
        &mut body,
        &[
            LocalGet(0),
            I32Const(abi::MIN_ADDRESS as i32),
            I32LtU,
            LocalGet(0),
            I32Const((abi::DESCRIPTOR_ALIGNMENT - 1) as i32),
            I32And,
            I32Const(0),
            I32Ne,
            I32Or,
        ],
    );
    trap_if(&mut body);

    memory_bytes(&mut body);
    instructions(
        &mut body,
        &[
            LocalSet(1),
            LocalGet(0),
            I64ExtendI32U,
            I64Const(i64::from(abi::DESCRIPTOR_SIZE)),
            I64Add,
            LocalGet(1),
            I64GtU,
        ],
    );
    trap_if(&mut body);

    instructions(
        &mut body,
        &[
            LocalGet(0),
            I32Load(header(abi::DESCRIPTOR_DATA_OFFSET)),
            I32Const(abi::MIN_ADDRESS as i32),
            I32LtU,
        ],
    );
    trap_if(&mut body);

    if width > 1 {
        instructions(
            &mut body,
            &[
                LocalGet(0),
                I32Load(header(abi::DESCRIPTOR_DATA_OFFSET)),
                I32Const((width - 1) as i32),
                I32And,
                I32Const(0),
                I32Ne,
            ],
        );
        trap_if(&mut body);
    }

    instructions(
        &mut body,
        &[
            LocalGet(0),
            I32Load(header(abi::DESCRIPTOR_DATA_OFFSET)),
            I64ExtendI32U,
            LocalGet(0),
            I32Load(header(abi::DESCRIPTOR_LENGTH_OFFSET)),
            I64ExtendI32U,
            I64Const(i64::from(width)),
            I64Mul,
            I64Add,
            LocalGet(1),
            I64GtU,
        ],
    );
    trap_if(&mut body);

    instructions(&mut body, &[LocalGet(0), End]);

    body
}

fn emit_array_address(first_function: u32) -> Function {
    emit_typed_address(
        first_function + Helper::ValidateArray.index(),
        abi::NUMBER_ELEMENT_SIZE,
    )
}

fn emit_typed_address(validator: u32, width: u32) -> Function {
    use Instruction::*;

    let mut body = Function::new([]);

    instructions(
        &mut body,
        &[
            LocalGet(0),
            Call(validator),
            LocalSet(0),
            LocalGet(1),
            F64Const(0.0.into()),
            F64Ge,
            LocalGet(1),
            LocalGet(0),
            I32Load(header(abi::DESCRIPTOR_LENGTH_OFFSET)),
            F64ConvertI32U,
            F64Lt,
            I32And,
            LocalGet(1),
            LocalGet(1),
            F64Trunc,
            F64Eq,
            I32And,
            I32Eqz,
        ],
    );
    trap_if(&mut body);

    instructions(
        &mut body,
        &[
            LocalGet(0),
            I32Load(header(abi::DESCRIPTOR_DATA_OFFSET)),
            I64ExtendI32U,
            LocalGet(1),
            I64TruncF64U,
            I64Const(i64::from(width)),
            I64Mul,
            I64Add,
            I32WrapI64,
            End,
        ],
    );

    body
}

fn emit_array_len(first_function: u32) -> Function {
    emit_typed_len(first_function + Helper::ValidateArray.index())
}

fn emit_typed_len(validator: u32) -> Function {
    use Instruction::*;

    let mut body = Function::new([]);

    instructions(
        &mut body,
        &[
            LocalGet(0),
            Call(validator),
            I32Load(header(abi::DESCRIPTOR_LENGTH_OFFSET)),
            F64ConvertI32U,
            End,
        ],
    );

    body
}

fn emit_string_concat(validator: u32, alloc: u32) -> Function {
    use Instruction::*;

    // Parameters 0/1 are handles; 2/3 lengths, 4 result, 5 destination,
    // 6 source, 7 copy length, 8 byte index, and 9 widened result length.
    let mut body = Function::new([(7, ValType::I32), (1, ValType::I64)]);
    instructions(
        &mut body,
        &[
            LocalGet(0),
            Call(validator),
            Drop,
            LocalGet(1),
            Call(validator),
            Drop,
            LocalGet(0),
            I32Load(header(abi::DESCRIPTOR_LENGTH_OFFSET)),
            LocalTee(2),
            I32Eqz,
            If(BlockType::Empty),
            LocalGet(1),
            Return,
            End,
            LocalGet(1),
            I32Load(header(abi::DESCRIPTOR_LENGTH_OFFSET)),
            LocalTee(3),
            I32Eqz,
            If(BlockType::Empty),
            LocalGet(0),
            Return,
            End,
            LocalGet(2),
            I64ExtendI32U,
            LocalGet(3),
            I64ExtendI32U,
            I64Add,
            LocalTee(9),
            I64Const(i64::from(abi::DESCRIPTOR_SIZE)),
            I64Add,
            I64Const(MAX_BYTES as i64),
            I64GtU,
        ],
    );
    trap_if(&mut body);
    instructions(
        &mut body,
        &[
            LocalGet(9),
            I64Const(i64::from(abi::DESCRIPTOR_SIZE)),
            I64Add,
            I32WrapI64,
            Call(alloc),
            LocalTee(4),
            LocalGet(4),
            I32Const(abi::DESCRIPTOR_SIZE as i32),
            I32Add,
            LocalTee(5),
            I32Store(header(abi::DESCRIPTOR_DATA_OFFSET)),
            LocalGet(4),
            LocalGet(9),
            I32WrapI64,
            I32Store(header(abi::DESCRIPTOR_LENGTH_OFFSET)),
        ],
    );

    for (handle, length) in [(0, 2), (1, 3)] {
        instructions(
            &mut body,
            &[
                LocalGet(handle),
                I32Load(header(abi::DESCRIPTOR_DATA_OFFSET)),
                LocalSet(6),
                LocalGet(length),
                LocalSet(7),
                I32Const(0),
                LocalSet(8),
            ],
        );
        emit_string_copy(&mut body);
        if handle == 0 {
            instructions(&mut body, &[LocalGet(5), LocalGet(2), I32Add, LocalSet(5)]);
        }
    }
    instructions(&mut body, &[LocalGet(4), End]);
    body
}

fn emit_string_slice_bytes(validator: u32, alloc: u32) -> Function {
    use Instruction::*;

    // Keep result/destination/source/copy-length/index in slots 4..8, matching
    // the existing byte-copy emitter. Slot 3 is the validated source byte length;
    // 9/10 hold endpoints and 11 holds the widened allocation size.
    let mut body = Function::new([(8, ValType::I32), (1, ValType::I64)]);
    instructions(
        &mut body,
        &[
            LocalGet(0),
            Call(validator),
            Drop,
            LocalGet(0),
            I32Load(header(abi::DESCRIPTOR_LENGTH_OFFSET)),
            LocalSet(3),
        ],
    );

    // Ordered comparisons reject NaN/infinities before unsigned conversion.
    // Endpoint equality with length is legal, unlike ordinary array indexing.
    for endpoint in [1, 2] {
        instructions(
            &mut body,
            &[
                LocalGet(endpoint),
                F64Const(0.0.into()),
                F64Ge,
                LocalGet(endpoint),
                LocalGet(3),
                F64ConvertI32U,
                F64Le,
                I32And,
                LocalGet(endpoint),
                LocalGet(endpoint),
                F64Trunc,
                F64Eq,
                I32And,
                I32Eqz,
            ],
        );
        trap_if(&mut body);
    }
    instructions(&mut body, &[LocalGet(1), LocalGet(2), F64Gt]);
    trap_if(&mut body);
    instructions(
        &mut body,
        &[
            LocalGet(1),
            I32TruncF64U,
            LocalSet(9),
            LocalGet(2),
            I32TruncF64U,
            LocalSet(10),
            LocalGet(0),
            I32Load(header(abi::DESCRIPTOR_DATA_OFFSET)),
            LocalSet(6),
        ],
    );

    let byte = MemArg {
        offset: 0,
        align: 0,
        memory_index: 0,
    };
    // Under the valid-UTF8 host contract an interior boundary is exactly a byte
    // that is not a continuation byte. Zero/end need no payload load, including
    // empty slices; test both endpoints before any reuse.
    for endpoint in [9, 10] {
        instructions(
            &mut body,
            &[
                LocalGet(endpoint),
                I32Eqz,
                I32Eqz,
                LocalGet(endpoint),
                LocalGet(3),
                I32LtU,
                I32And,
                If(BlockType::Empty),
                LocalGet(6),
                LocalGet(endpoint),
                I32Add,
                I32Load8U(byte),
                I32Const(0xc0),
                I32And,
                I32Const(0x80),
                I32Eq,
            ],
        );
        trap_if(&mut body);
        body.instruction(&End);
    }
    instructions(
        &mut body,
        &[
            LocalGet(9),
            I32Eqz,
            LocalGet(10),
            LocalGet(3),
            I32Eq,
            I32And,
            If(BlockType::Empty),
            LocalGet(0),
            Return,
            End,
            LocalGet(10),
            LocalGet(9),
            I32Sub,
            LocalTee(7),
            I64ExtendI32U,
            I64Const(i64::from(abi::DESCRIPTOR_SIZE)),
            I64Add,
            LocalTee(11),
            I64Const(MAX_BYTES as i64),
            I64GtU,
        ],
    );
    trap_if(&mut body);
    instructions(
        &mut body,
        &[
            LocalGet(11),
            I32WrapI64,
            Call(alloc),
            LocalTee(4),
            LocalGet(4),
            I32Const(abi::DESCRIPTOR_SIZE as i32),
            I32Add,
            LocalTee(5),
            I32Store(header(abi::DESCRIPTOR_DATA_OFFSET)),
            LocalGet(4),
            LocalGet(7),
            I32Store(header(abi::DESCRIPTOR_LENGTH_OFFSET)),
            LocalGet(6),
            LocalGet(9),
            I32Add,
            LocalSet(6),
            I32Const(0),
            LocalSet(8),
        ],
    );
    emit_string_copy(&mut body);
    instructions(&mut body, &[LocalGet(4), End]);
    body
}

fn emit_string_replace_all(validator: u32, equal: u32, alloc: u32) -> Function {
    use Instruction::*;

    // 0..2: input handles; 3: source length; 4..8: existing copy scratch;
    // 9/10: needle/replacement lengths; 11..13: payload pointers;
    // 14: source cursor; 15: comparison cursor; 16: match flag; 17: match count;
    // 18: widened result length. Both passes search only the original source.
    let mut body = Function::new([(15, ValType::I32), (1, ValType::I64)]);
    let byte = MemArg {
        offset: 0,
        align: 0,
        memory_index: 0,
    };

    for handle in 0..3 {
        instructions(&mut body, &[LocalGet(handle), Call(validator), Drop]);
    }
    for (handle, length, pointer) in [(0, 3, 11), (1, 9, 12), (2, 10, 13)] {
        instructions(
            &mut body,
            &[
                LocalGet(handle),
                I32Load(header(abi::DESCRIPTOR_LENGTH_OFFSET)),
                LocalSet(length),
                LocalGet(handle),
                I32Load(header(abi::DESCRIPTOR_DATA_OFFSET)),
                LocalSet(pointer),
            ],
        );
    }
    instructions(&mut body, &[LocalGet(9), I32Eqz]);
    trap_if(&mut body);
    instructions(
        &mut body,
        &[
            LocalGet(1),
            LocalGet(2),
            Call(equal),
            If(BlockType::Empty),
            LocalGet(0),
            Return,
            End,
        ],
    );

    // Emit the same bounded-memory search for sizing and final construction.
    // The copy pass has no calls except the already-planned allocation before it,
    // so the immutable input bytes and the match decisions cannot change.
    for copying in [false, true] {
        instructions(
            &mut body,
            &[
                I32Const(0),
                LocalSet(14),
                Block(BlockType::Empty),
                Loop(BlockType::Empty),
                LocalGet(14),
                LocalGet(3),
                I32GeU,
                BrIf(1),
                I32Const(0),
                LocalSet(16),
                LocalGet(9),
                LocalGet(3),
                LocalGet(14),
                I32Sub,
                I32LeU,
                If(BlockType::Empty),
                I32Const(0),
                LocalSet(15),
                Block(BlockType::Empty),
                Loop(BlockType::Empty),
                LocalGet(15),
                LocalGet(9),
                I32GeU,
                If(BlockType::Empty),
                I32Const(1),
                LocalSet(16),
                Br(2),
                End,
                LocalGet(11),
                LocalGet(14),
                I32Add,
                LocalGet(15),
                I32Add,
                I32Load8U(byte),
                LocalGet(12),
                LocalGet(15),
                I32Add,
                I32Load8U(byte),
                I32Ne,
                BrIf(1),
                LocalGet(15),
                I32Const(1),
                I32Add,
                LocalSet(15),
                Br(0),
                End,
                End,
                End,
                LocalGet(16),
                If(BlockType::Empty),
            ],
        );
        if copying {
            instructions(
                &mut body,
                &[
                    LocalGet(13),
                    LocalSet(6),
                    LocalGet(10),
                    LocalSet(7),
                    I32Const(0),
                    LocalSet(8),
                ],
            );
            emit_string_copy(&mut body);
            instructions(&mut body, &[LocalGet(5), LocalGet(10), I32Add, LocalSet(5)]);
        } else {
            instructions(
                &mut body,
                &[
                    LocalGet(18),
                    LocalGet(10),
                    I64ExtendI32U,
                    I64Add,
                    LocalSet(18),
                    LocalGet(17),
                    I32Const(1),
                    I32Add,
                    LocalSet(17),
                ],
            );
        }
        instructions(
            &mut body,
            &[LocalGet(14), LocalGet(9), I32Add, LocalSet(14), Else],
        );
        if copying {
            instructions(
                &mut body,
                &[
                    LocalGet(5),
                    LocalGet(11),
                    LocalGet(14),
                    I32Add,
                    I32Load8U(byte),
                    I32Store8(byte),
                    LocalGet(5),
                    I32Const(1),
                    I32Add,
                    LocalSet(5),
                ],
            );
        } else {
            instructions(
                &mut body,
                &[LocalGet(18), I64Const(1), I64Add, LocalSet(18)],
            );
        }
        instructions(
            &mut body,
            &[
                LocalGet(14),
                I32Const(1),
                I32Add,
                LocalSet(14),
                End,
                Br(0),
                End,
                End,
            ],
        );
        if !copying {
            instructions(
                &mut body,
                &[
                    LocalGet(17),
                    I32Eqz,
                    If(BlockType::Empty),
                    LocalGet(0),
                    Return,
                    End,
                    // At most source_length replacements, each at most u32::MAX
                    // bytes: even the unrepresentable result plus header fits u64.
                    LocalGet(18),
                    I64Const(i64::from(abi::DESCRIPTOR_SIZE)),
                    I64Add,
                    I64Const(MAX_BYTES as i64),
                    I64GtU,
                ],
            );
            trap_if(&mut body);
            instructions(
                &mut body,
                &[
                    LocalGet(18),
                    I64Const(i64::from(abi::DESCRIPTOR_SIZE)),
                    I64Add,
                    I32WrapI64,
                    Call(alloc),
                    LocalTee(4),
                    LocalGet(4),
                    I32Const(abi::DESCRIPTOR_SIZE as i32),
                    I32Add,
                    LocalTee(5),
                    I32Store(header(abi::DESCRIPTOR_DATA_OFFSET)),
                    LocalGet(4),
                    LocalGet(18),
                    I32WrapI64,
                    I32Store(header(abi::DESCRIPTOR_LENGTH_OFFSET)),
                ],
            );
        }
    }
    instructions(&mut body, &[LocalGet(4), End]);
    body
}

fn emit_string_join(array_validator: u32, validator: u32, alloc: u32) -> Function {
    use Instruction::*;

    let element = crate::ast::ArrayElementType::String;
    // 0/1: captured parts/separator; 2: count; 3: spare; 4..8: shared
    // result/copy scratch; 9: separator length; 10: parts payload; 11: index;
    // 12: entry handle; 13: separator payload; 14: widened result length.
    let mut body = Function::new([(12, ValType::I32), (1, ValType::I64)]);
    instructions(
        &mut body,
        &[
            LocalGet(1),
            Call(validator),
            Drop,
            LocalGet(0),
            Call(array_validator),
            Drop,
            LocalGet(0),
            I32Load(header(abi::DESCRIPTOR_LENGTH_OFFSET)),
            LocalSet(2),
            LocalGet(0),
            I32Load(header(abi::DESCRIPTOR_DATA_OFFSET)),
            LocalSet(10),
            LocalGet(1),
            I32Load(header(abi::DESCRIPTOR_LENGTH_OFFSET)),
            LocalSet(9),
            LocalGet(1),
            I32Load(header(abi::DESCRIPTOR_DATA_OFFSET)),
            LocalSet(13),
            LocalGet(2),
            If(BlockType::Empty),
            LocalGet(2),
            I32Const(1),
            I32Sub,
            I64ExtendI32U,
            LocalGet(9),
            I64ExtendI32U,
            I64Mul,
            LocalSet(14),
            End,
            Block(BlockType::Empty),
            Loop(BlockType::Empty),
            LocalGet(11),
            LocalGet(2),
            I32GeU,
            BrIf(1),
            LocalGet(10),
            LocalGet(11),
            I32Const(super::array::width(element) as i32),
            I32Mul,
            I32Add,
            super::array::load(element, 0),
            Call(validator),
            LocalTee(12),
            I32Load(header(abi::DESCRIPTOR_LENGTH_OFFSET)),
            I64ExtendI32U,
            LocalGet(14),
            I64Add,
            LocalSet(14),
            LocalGet(11),
            I32Const(1),
            I32Add,
            LocalSet(11),
            Br(0),
            End,
            End,
            LocalGet(2),
            I32Const(1),
            I32Eq,
            If(BlockType::Empty),
            LocalGet(12),
            Return,
            End,
            // Outer validation bounds count by MAX_BYTES / 4; each string
            // length is at most MAX_BYTES. Both sums plus header fit u64.
            LocalGet(14),
            I64Const(i64::from(abi::DESCRIPTOR_SIZE)),
            I64Add,
            I64Const(MAX_BYTES as i64),
            I64GtU,
        ],
    );
    trap_if(&mut body);
    instructions(
        &mut body,
        &[
            LocalGet(14),
            I64Const(i64::from(abi::DESCRIPTOR_SIZE)),
            I64Add,
            I32WrapI64,
            Call(alloc),
            LocalTee(4),
            LocalGet(4),
            I32Const(abi::DESCRIPTOR_SIZE as i32),
            I32Add,
            LocalTee(5),
            I32Store(header(abi::DESCRIPTOR_DATA_OFFSET)),
            LocalGet(4),
            LocalGet(14),
            I32WrapI64,
            I32Store(header(abi::DESCRIPTOR_LENGTH_OFFSET)),
            I32Const(0),
            LocalSet(11),
            Block(BlockType::Empty),
            Loop(BlockType::Empty),
            LocalGet(11),
            LocalGet(2),
            I32GeU,
            BrIf(1),
            LocalGet(10),
            LocalGet(11),
            I32Const(super::array::width(element) as i32),
            I32Mul,
            I32Add,
            super::array::load(element, 0),
            LocalTee(12),
            I32Load(header(abi::DESCRIPTOR_DATA_OFFSET)),
            LocalSet(6),
            LocalGet(12),
            I32Load(header(abi::DESCRIPTOR_LENGTH_OFFSET)),
            LocalSet(7),
            I32Const(0),
            LocalSet(8),
        ],
    );
    // No callbacks or writes to the inputs occur between the validation and
    // copying passes. Numeric offsets remain valid even if allocation grows memory.
    emit_string_copy(&mut body);
    instructions(
        &mut body,
        &[
            LocalGet(5),
            LocalGet(7),
            I32Add,
            LocalSet(5),
            LocalGet(11),
            I32Const(1),
            I32Add,
            LocalTee(11),
            LocalGet(2),
            I32LtU,
            If(BlockType::Empty),
            LocalGet(13),
            LocalSet(6),
            LocalGet(9),
            LocalSet(7),
            I32Const(0),
            LocalSet(8),
        ],
    );
    emit_string_copy(&mut body);
    instructions(
        &mut body,
        &[
            LocalGet(5),
            LocalGet(7),
            I32Add,
            LocalSet(5),
            End,
            Br(0),
            End,
            End,
            LocalGet(4),
            End,
        ],
    );
    body
}

fn emit_string_copy(body: &mut Function) {
    use Instruction::*;

    let byte = MemArg {
        offset: 0,
        align: 0,
        memory_index: 0,
    };
    instructions(
        body,
        &[
            Block(BlockType::Empty),
            Loop(BlockType::Empty),
            LocalGet(8),
            LocalGet(7),
            I32GeU,
            BrIf(1),
            LocalGet(5),
            LocalGet(8),
            I32Add,
            LocalGet(6),
            LocalGet(8),
            I32Add,
            I32Load8U(byte),
            I32Store8(byte),
            LocalGet(8),
            I32Const(1),
            I32Add,
            LocalSet(8),
            Br(0),
            End,
            End,
        ],
    );
}

fn emit_string_equal(first_function: u32) -> Function {
    use Instruction::*;

    let byte = MemArg {
        offset: 0,
        align: 0,
        memory_index: 0,
    };
    let mut body = Function::new([(4, ValType::I32)]);

    instructions(
        &mut body,
        &[
            LocalGet(0),
            Call(first_function + Helper::ValidateString.index()),
            LocalSet(0),
            LocalGet(1),
            Call(first_function + Helper::ValidateString.index()),
            LocalSet(1),
            LocalGet(0),
            I32Load(header(abi::DESCRIPTOR_LENGTH_OFFSET)),
            LocalTee(4),
            LocalGet(1),
            I32Load(header(abi::DESCRIPTOR_LENGTH_OFFSET)),
            I32Ne,
            If(BlockType::Empty),
            I32Const(0),
            Return,
            End,
            LocalGet(0),
            I32Load(header(abi::DESCRIPTOR_DATA_OFFSET)),
            LocalSet(2),
            LocalGet(1),
            I32Load(header(abi::DESCRIPTOR_DATA_OFFSET)),
            LocalSet(3),
            Block(BlockType::Empty),
            Loop(BlockType::Empty),
            LocalGet(5),
            LocalGet(4),
            I32GeU,
            BrIf(1),
            LocalGet(2),
            LocalGet(5),
            I32Add,
            I32Load8U(byte),
            LocalGet(3),
            LocalGet(5),
            I32Add,
            I32Load8U(byte),
            I32Ne,
            If(BlockType::Empty),
            I32Const(0),
            Return,
            End,
            LocalGet(5),
            I32Const(1),
            I32Add,
            LocalSet(5),
            Br(0),
            End,
            End,
            I32Const(1),
            End,
        ],
    );

    body
}

fn emit_array_equal(first_function: u32) -> Function {
    emit_typed_equal(
        crate::ast::ArrayElementType::Number,
        first_function + Helper::ValidateArray.index(),
        None,
        first_function + Helper::StringEqual.index(),
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{
        host::{HostFunction, HostFunctionId},
        tokens::Span,
        typed_ast::{FunctionId, TypedBlock, TypedFunction, TypedStatement, VariableId},
    };
    use wasm_encoder::{
        CodeSection, ConstExpr, FunctionSection, GlobalSection, GlobalType, ImportSection,
        MemorySection, MemoryType, Module, TypeSection,
    };

    fn expr(kind: TypedExprKind, ty: Type) -> TypedExpr {
        TypedExpr {
            kind,
            ty: ty.into(),
        }
    }

    fn string(value: &str) -> TypedExpr {
        expr(TypedExprKind::String(value.to_owned()), Type::String)
    }

    fn statement(kind: TypedStatementKind) -> TypedStatement {
        TypedStatement {
            kind,
            span: Span::new(0, 0),
        }
    }

    fn program(body: TypedBlock) -> TypedProgram {
        TypedProgram {
            host_functions: vec![],
            functions: vec![TypedFunction {
                id: FunctionId(0),
                name: "test".to_owned(),
                params: vec![],
                return_type: Type::Void,
                contracts: vec![],
                body,
                span: Span::new(0, 0),
            }],
        }
    }

    #[test]
    fn scalar_only_program_has_no_memory_plan() {
        let program = program(vec![statement(TypedStatementKind::Expression(expr(
            TypedExprKind::Number("1".to_owned()),
            Type::Number,
        )))]);

        assert!(MemoryPlan::new(&program).unwrap().is_none());
    }

    #[test]
    fn strings_are_interned_in_preorder_with_byte_lengths() {
        let program = program(vec![statement(TypedStatementKind::While {
            id: crate::typed_ast::LoopId(0),
            cond: Box::new(string("é")),
            body: vec![statement(TypedStatementKind::If {
                cond: Box::new(string("")),
                then: vec![statement(TypedStatementKind::Return(Some(string("é"))))],
                else_: Some(vec![statement(TypedStatementKind::Expression(string(
                    "last",
                )))]),
            })],
        })]);
        let plan = MemoryPlan::new(&program).unwrap().unwrap();

        assert_eq!(plan.string("é"), Some(8));
        assert_eq!(plan.string(""), Some(24));
        assert_eq!(plan.string("last"), Some(32));
        assert_eq!(plan.string("missing"), None);
        assert_eq!(&plan.data[..8], &[0; 8]);
        assert_eq!(&plan.data[8..12], &16_u32.to_le_bytes());
        assert_eq!(&plan.data[12..16], &2_u32.to_le_bytes());
        assert_eq!(&plan.data[16..18], "é".as_bytes());
        assert_eq!(&plan.data[18..24], &[0; 6]);
        assert_eq!(&plan.data[24..28], &32_u32.to_le_bytes());
        assert_eq!(&plan.data[28..32], &0_u32.to_le_bytes());
        assert_eq!(plan.data.len(), 44);
        assert_eq!(plan.heap_start, 48);
    }

    #[test]
    fn signatures_locals_expression_types_and_kinds_require_memory() {
        let mut host_program = program(vec![]);
        host_program.host_functions.push(HostFunction {
            id: HostFunctionId(0),
            name: "host".to_owned(),
            module: "env".to_owned(),
            field: "host".to_owned(),
            params: vec![Type::String],
            return_type: Type::Void,
        });

        assert!(MemoryPlan::new(&host_program).unwrap().is_some());

        let mut return_program = program(vec![]);
        return_program.functions[0].return_type = Type::Array(crate::ast::ArrayElementType::Number);

        assert!(MemoryPlan::new(&return_program).unwrap().is_some());

        let local_program = program(vec![statement(TypedStatementKind::Let {
            id: VariableId(0),
            name: "local".to_owned(),
            ty: Type::String,
            value: expr(TypedExprKind::Bool(false), Type::Bool),
        })]);

        assert!(MemoryPlan::new(&local_program).unwrap().is_some());

        for value in [
            expr(
                TypedExprKind::Bool(false),
                Type::Array(crate::ast::ArrayElementType::Number),
            ),
            expr(
                TypedExprKind::Array(vec![], crate::ast::ArrayElementType::Number),
                Type::Number,
            ),
            expr(
                TypedExprKind::Index {
                    expr: Box::new(expr(TypedExprKind::Bool(false), Type::Bool)),
                    index: Box::new(expr(TypedExprKind::Bool(false), Type::Bool)),
                },
                Type::Number,
            ),
            expr(
                TypedExprKind::Call {
                    func: FunctionRef::Builtin(BuiltinFunction::Len),
                    name: "len".to_owned(),
                    args: vec![],
                },
                Type::Number,
            ),
        ] {
            let program = program(vec![statement(TypedStatementKind::Expression(value))]);
            let plan = MemoryPlan::new(&program).unwrap().unwrap();

            assert_eq!(plan.data, vec![0; 8]);
            assert_eq!(plan.heap_start, 8);
        }
    }

    #[test]
    fn static_layout_limits_are_checked_before_narrowing() {
        assert_eq!(aligned_offset(MAX_BYTES).unwrap(), MAX_BYTES as u32);
        assert_eq!(aligned_offset(MAX_BYTES - 7).unwrap(), MAX_BYTES as u32);
        assert!(aligned_offset(MAX_BYTES + 1).is_err());
        assert!(aligned_offset(u64::MAX).is_err());
    }

    #[test]
    fn helper_indices_and_signatures_are_fixed() {
        use ValType::{F64, I32};

        let expected = [
            (Helper::Alloc, 0, vec![I32], I32),
            (Helper::ValidateString, 1, vec![I32], I32),
            (Helper::ValidateArray, 2, vec![I32], I32),
            (Helper::ArrayAddress, 3, vec![I32, F64], I32),
            (Helper::ArrayLen, 4, vec![I32], F64),
            (Helper::StringEqual, 5, vec![I32, I32], I32),
            (Helper::ArrayEqual, 6, vec![I32, I32], I32),
        ];
        let actual = helpers();

        assert_eq!(actual.len(), 7);

        for ((actual_helper, actual_signature), (helper, index, params, result)) in
            actual.into_iter().zip(expected)
        {
            let signature = Signature {
                params,
                results: vec![result],
            };

            assert_eq!(actual_helper, helper);
            assert_eq!(helper.index(), index);
            assert_eq!(helper.signature(), signature);
            assert_eq!(actual_signature, signature);
        }
    }

    #[test]
    fn descriptor_layout_and_constants_are_fixed() {
        assert_eq!(abi::DESCRIPTOR_SIZE, 8);
        assert_eq!(abi::DESCRIPTOR_DATA_OFFSET, 0);
        assert_eq!(abi::DESCRIPTOR_LENGTH_OFFSET, 4);
        assert_eq!(abi::DESCRIPTOR_ALIGNMENT, 8);
        assert_eq!(abi::DESCRIPTOR_FIELD_ALIGN_LOG2, 2);
        assert_eq!(abi::NUMBER_ELEMENT_SIZE, 8);
        assert_eq!(abi::NUMBER_ELEMENT_ALIGNMENT, 8);
        assert_eq!(abi::NUMBER_ELEMENT_ALIGN_LOG2, 3);
        assert_eq!(abi::STRING_ELEMENT_SIZE, 1);
        assert_eq!(abi::MIN_ADDRESS, 8);
        assert_eq!(abi::ALLOCATION_ALIGNMENT, 8);
        assert_eq!(abi::MIN_ALLOCATION_BYTES, 8);
        assert_eq!(PAGE_BYTES, 65_536);
        assert_eq!(PAGE_ALIGN_LOG2, 16);

        let program = program(vec![statement(TypedStatementKind::Expression(string("é")))]);
        let plan = MemoryPlan::new(&program).unwrap().unwrap();

        assert_eq!(plan.string("é"), Some(8));
        assert_eq!(plan.heap_start, 24);
        assert_eq!(
            plan.data,
            vec![0, 0, 0, 0, 0, 0, 0, 0, 16, 0, 0, 0, 2, 0, 0, 0, 0xc3, 0xa9]
        );
    }

    #[test]
    fn helper_signatures_and_bodies_validate_with_a_function_offset() {
        let helpers = helpers();
        let mut module = Module::new();
        let mut types = TypeSection::new();
        let mut imports = ImportSection::new();
        let mut functions = FunctionSection::new();
        let mut memory = MemorySection::new();
        let mut globals = GlobalSection::new();
        let mut code = CodeSection::new();
        let expected = [
            (vec![ValType::I32], ValType::I32),
            (vec![ValType::I32], ValType::I32),
            (vec![ValType::I32], ValType::I32),
            (vec![ValType::I32, ValType::F64], ValType::I32),
            (vec![ValType::I32], ValType::F64),
            (vec![ValType::I32, ValType::I32], ValType::I32),
            (vec![ValType::I32, ValType::I32], ValType::I32),
        ];

        assert_eq!(helpers.len(), expected.len());

        for (index, ((helper, signature), (params, result))) in
            helpers.iter().zip(expected).enumerate()
        {
            assert_eq!(helper.index(), index as u32);
            assert_eq!(signature.params, params);
            assert_eq!(signature.results, vec![result]);

            types.ty().function(
                signature.params.iter().copied(),
                signature.results.iter().copied(),
            );
            functions.function(index as u32);
            code.function(&emit(*helper, 1));
        }

        imports.import("env", "unused", wasm_encoder::EntityType::Function(0));
        memory.memory(MemoryType {
            minimum: 1,
            maximum: Some(MAX_PAGES),
            memory64: false,
            shared: false,
            page_size_log2: None,
        });
        globals.global(
            GlobalType {
                val_type: ValType::I32,
                mutable: true,
                shared: false,
            },
            &ConstExpr::i32_const(8),
        );
        module.section(&types);
        module.section(&imports);
        module.section(&functions);
        module.section(&memory);
        module.section(&globals);
        module.section(&code);

        wasmparser::Validator::new()
            .validate_all(&module.finish())
            .unwrap();
    }
}
